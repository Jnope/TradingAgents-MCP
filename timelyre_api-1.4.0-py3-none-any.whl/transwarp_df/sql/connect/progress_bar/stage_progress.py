import sys

from transwarp_df.sql.connect.leopard_conf import LEOPARD_USE_TQDM_AUTO, get_bool_conf


class StageProgress:

    @staticmethod
    def from_string(s):
        ss = s.split(",")
        return int(ss[0]), int(ss[1]), int(ss[2]), int(ss[3])

    def __init__(self, job_id, stage_id, finished_tasks, total_tasks):
        self.process_bar = None
        self.job_id = job_id
        self.stage_id = stage_id
        self.total_tasks = total_tasks
        self.is_refreshed = False
        self.finished_tasks = 0
        self.update_num(finished_tasks)

    def finish(self):
        num = self.total_tasks - self.finished_tasks
        self.update_num(num)

    def update_num(self, num):
        self.finished_tasks += num
        if self.process_bar is None:
            self.process_bar = self.get_process_bar()
        if num > 0:
            self.process_bar.update(num)
            self.process_bar.refresh()

    def finished(self):
        return self.finished_tasks >= self.total_tasks

    def get_process_bar(self):
        if get_bool_conf(LEOPARD_USE_TQDM_AUTO):
            from tqdm.auto import tqdm
        else:
            from tqdm import tqdm
        return tqdm(total=self.total_tasks, desc=f"Job {self.job_id} Stage {self.stage_id}", unit="task",
                    bar_format="{desc}: {percentage:3.0f}%|{bar}|{n}/{total} [{elapsed}<{remaining}]", leave=True,
                    file=sys.stdout)
