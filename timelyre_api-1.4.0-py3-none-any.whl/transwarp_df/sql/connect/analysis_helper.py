
import transwarp_df.sql.connect.plan as plan
from transwarp_df.sql.connect.expressions import Expression


def missing_plan(p: plan.LogicalPlan):
    return None

def missing_expr(e: Expression):
    return None
