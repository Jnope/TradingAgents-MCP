from transwarp_iframe import show, init_notebook_mode


def show_itables(df):
    init_notebook_mode()
    show(df)
