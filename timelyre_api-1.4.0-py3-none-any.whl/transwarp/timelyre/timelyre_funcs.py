
from .dataframe import ColEval

sum = ColEval.sum
count = ColEval.count
mean = ColEval.mean
min = ColEval.min
max = ColEval.max
std = ColEval.std
first = ColEval.first
last = ColEval.last
var = ColEval.var
value_counts = ColEval.value_counts
kurt = ColEval.kurt
skew = ColEval.skew
mad = ColEval.mad
nunique = ColEval.nunique
any = ColEval.any
all = ColEval.all
argmax = ColEval.argmax
cov = ColEval.cov
prod = ColEval.prod
average = ColEval.average

corr = ColEval.corr_selector