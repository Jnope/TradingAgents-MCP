import sys
import subprocess
import traceback
from datetime import datetime, timedelta


def is_get_conf_command(sql: str):
    return sql.startswith("set") and ("=" not in sql)


def get_tbl_name_from_sql(sql: str) -> (str, int, int):
    length = len(sql)
    index = sql.lower().find("from ")
    start_index = index + 4
    while start_index < length:
        if sql[start_index] != ' ':
            break
        start_index += 1

    end_index = start_index
    while end_index < length:
        if sql[end_index] == ' ':
            break
        end_index += 1
    return sql[start_index: end_index], start_index, end_index


def get_utc_time(original_time: str):
    dt = datetime.strptime(original_time, '%Y-%m-%d %H:%M:%S') - timedelta(hours=8)

    # 将datetime对象转换为ISO 8601格式的字符串
    iso_time = dt.isoformat()

    # 添加'Z'表示UTC时间
    utc_time = f"'{iso_time}Z'"
    return utc_time


def get_normal_time(original_time: str):
    dt = datetime.strptime(original_time, '%Y-%m-%dT%H:%M:%SZ') + timedelta(hours=8)

    new_time = dt.strftime('%Y-%m-%d %H:%M:%S')
    return new_time


def get_ip_address():
    try:
        output = subprocess.check_output(["hostname", "-I"], stderr=subprocess.STDOUT).decode("utf-8").strip()
        ip_addresses = output.split(" ")
        for ip in ip_addresses:
            if not ip.startswith('127.'):
                return ip
    except subprocess.CalledProcessError or Exception:
        pass
    except Exception:
        pass
    return None


def get_file_by_pid(pid):
    try:
        if "win" in sys.platform:
            return None
        output = subprocess.check_output(f"ps -ef | grep {pid}", shell=True, universal_newlines=True)
        res = output.split("\n")
        for r in res:
            if r[-3:] == ".py":
                file = r.rsplit(" ", 1)[1]
                return file

    except subprocess.CalledProcessError or Exception:
        pass
    except Exception:
        pass
    return None


# 尽可能地将list平均分成n个list
def split_list(lst, n):
    length = len(lst)
    avg = length // n  # 平均每个子列表的长度
    remain = length % n  # 剩余的元素个数
    result = []
    start = 0
    for i in range(n):
        sublist_length = avg + 1 if i < remain else avg
        sublist = lst[start:start + sublist_length]
        result.append(sublist)
        start += sublist_length
    return result


def list_non_empty(input: list):
    return input is not None and len(input) > 0


def generate_asof_join_str(left_table: str, right_table: str, left_select_cols: list, right_select_cols: list,
                           left_join_keys: list, right_join_keys: list, code_filter: list,
                           low_ts_filter: str, high_ts_filter: str, code_col: str, ts_col: str):
    if (not list_non_empty(left_select_cols)) and (not list_non_empty(right_select_cols)):
        raise Exception("no select cols found")
    real_left_select_cols = ", ".join(["t1." + f"`{s}`" + f" as t1_{s}" for s in left_select_cols])
    real_right_select_cols = ", ".join(["t2." + f"`{s}`" + f" as t2_{s}" for s in right_select_cols])
    real_left_join_keys = ["t1." + s for s in left_join_keys]
    real_right_join_keys = ["t2." + s for s in right_join_keys]
    join_conditions = " and ".join(
        f"{left} = {right}" for left, right in zip(real_left_join_keys, real_right_join_keys))
    filter_str_list = []

    if code_filter is not None and len(code_filter) > 0:
        code_filter2 = [f"'{s}'" for s in code_filter]
        filter_str_list.append(f"t1.{code_col} in ({', '.join(code_filter2)})")
    if low_ts_filter is not None and len(low_ts_filter) > 0:
        filter_str_list.append(f" t1.{ts_col} >= '{low_ts_filter}'")
    if high_ts_filter is not None and len(high_ts_filter) > 0:
        filter_str_list.append(f" t1.{ts_col} <= '{high_ts_filter}'")
    if len(filter_str_list) > 0:
        filter_str = "where "
        filter_str += " and ".join(filter_str_list)
    else:
        filter_str = ""
    final_sql = (f"select {real_left_select_cols}, {real_right_select_cols} from "
                 f"{left_table} as t1 join {right_table} as t2 "
                 f"on {join_conditions} "
                 f"{filter_str}")
    return final_sql


def generate_window_join_str(left_table: str, right_table: str, left_select_cols: list, right_select_cols: list,
                             left_join_keys: list, right_join_keys: list, code_filter: list,
                             low_ts_filter: str, high_ts_filter: str, code_col: str, ts_col: str,
                             left_aggregation: list, right_aggregation: list):
    if (list_non_empty(left_select_cols) or list_non_empty(right_select_cols)) and (
            list_non_empty(left_aggregation) or list_non_empty(right_aggregation)):
        raise Exception("can not have select cols and aggregations at same time")
    real_left_join_keys = ["t1." + s for s in left_join_keys]
    real_right_join_keys = ["t2." + s for s in right_join_keys]
    join_conditions = " and ".join(
        f"{left} = {right}" for left, right in zip(real_left_join_keys, real_right_join_keys))
    filter_str_list = []

    if code_filter is not None and len(code_filter) > 0:
        code_filter2 = [f"'{s}'" for s in code_filter]
        filter_str_list.append(f"t1.{code_col} in ({', '.join(code_filter2)})")
    if low_ts_filter is not None and len(low_ts_filter) > 0:
        filter_str_list.append(f" t1.{ts_col} >= '{low_ts_filter}'")
    if high_ts_filter is not None and len(high_ts_filter) > 0:
        filter_str_list.append(f" t1.{ts_col} <= '{high_ts_filter}'")
    if len(filter_str_list) > 0:
        filter_str = "where "
        filter_str += " and ".join(filter_str_list)
    else:
        filter_str = ""
    if list_non_empty(left_aggregation) or list_non_empty(right_aggregation):
        real_left_aggrs = ", ".join(
            [f"{agg_list[0]}(t1.`{agg_list[1]}`)" for agg_list in left_aggregation])
        real_right_aggrs = ", ".join(
            [f"{agg_list[0]}(t2.`{agg_list[1]}`)" for agg_list in right_aggregation])
        group_by_keys = ','.join(real_left_join_keys)
        final_sql = (f"select {group_by_keys}, {real_left_aggrs}, {real_right_aggrs} from "
                     f"{left_table} as t1 join {right_table} as t2 "
                     f"on {join_conditions} "
                     f"{filter_str} "
                     f"group by {group_by_keys} "
                     f"order by {group_by_keys} ")
    else:
        if (not list_non_empty(left_select_cols)) and (not list_non_empty(right_select_cols)):
            raise Exception("no select columns or aggregations found")
        real_left_select_cols = ", ".join(["t1." + f"`{s}`" + f" as t1_{s}" for s in left_select_cols])
        real_right_select_cols = ", ".join(["t2." + f"`{s}`" + f" as t2_{s}" for s in right_select_cols])
        final_sql = (f"select {real_left_select_cols}, {real_right_select_cols} from "
                     f"{left_table} as t1 join {right_table} as t2 "
                     f"on {join_conditions} "
                     f"{filter_str}")
    return final_sql


def print_call_stack():
    stack = traceback.format_stack()
    print('Current call stack:')
    print(''.join(stack))


def refineHdfsLoc(input_string: str) -> str:
    if input_string.startswith("file:/"):
        return input_string.replace("file:/", "file:///", 1)
    return input_string


if __name__ == "__main__":
    left_table = "test.table1"
    right_table = "test.table2"
    left_select_cols = ["ts", "code", "price"]
    right_select_cols = ["datetime", "code", "high"]
    left_join_keys = ["code", "ts"]
    right_join_keys = ["code", "datetime"]
    code_filter = ["0.CN", "1.SH"]
    low_ts_filter = "2020-01-01 08:00:00.123456789"
    high_ts_filter = "2020-01-02 18:01:01.987654321"
    sql = generate_asof_join_str(left_table, right_table, left_select_cols, right_select_cols,
                                 left_join_keys, right_join_keys, code_filter,
                                 low_ts_filter, high_ts_filter, "code", "ts")
    print(sql)
    left_aggregation = [['count', 'price'], ['max', 'high'], ['min', 'close']]
    right_aggregation = [['sum', 'high']]
    sql = generate_window_join_str(left_table, right_table, None, None,
                                   left_join_keys, right_join_keys, code_filter,
                                   low_ts_filter, high_ts_filter, "code", "ts",
                                   left_aggregation=left_aggregation, right_aggregation=right_aggregation)
    print(sql)
