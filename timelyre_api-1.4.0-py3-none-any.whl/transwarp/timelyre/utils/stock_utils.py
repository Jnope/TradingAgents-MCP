import time

import pandas as pd
import random
import datetime

__r = random.Random()

__st1 = datetime.datetime.strptime("20220101", "%Y%m%d") + datetime.timedelta(hours=9, minutes=30)
__nd1 = datetime.datetime.strptime("20220101", "%Y%m%d") + datetime.timedelta(hours=11, minutes=30)
__st2 = datetime.datetime.strptime("20220101", "%Y%m%d") + datetime.timedelta(hours=13, minutes=00)
__nd2 = datetime.datetime.strptime("20220101", "%Y%m%d") + datetime.timedelta(hours=15, minutes=00)

def is_trade_time(t):
    return __st1.time() <= t.time() <= __nd1.time() or __st2.time() <= t.time() <= __nd2.time()

def __gen_ask_bid(price: float, n: int) -> list:
    askBasePrice = price + __r.random()
    bidBasePrice = price - __r.random()
    ret = []

    curA = askBasePrice
    for i in range(n):
        ret.append(curA)
        curA += __r.random()
        ret.append(__r.randint(1, 1000) * 100)

    curB = bidBasePrice
    for i in range(n):
        ret.append(curB)
        curB -= __r.random()
        ret.append(__r.randint(1, 1000) * 100)
    return ret

def gen_data(stock_num: int, start_time: str, end_time: str, max_rows_per_stock: int,
             frequencySecs: int, ask_bid_num: int = 0, code_suffix: str = '.CN'):
    assert(ask_bid_num <= 50)
    sttime = datetime.datetime.strptime(start_time, "%Y%m%d")
    ndtime = datetime.datetime.strptime(end_time, "%Y%m%d")
    retList = []
    for code_num in range(stock_num):
        basePrice = __r.randint(3, 100) + __r.random()
        price = basePrice
        i = 0
        real_i = 0
        while i < max_rows_per_stock:
            curDateTime = sttime + datetime.timedelta(seconds=frequencySecs * real_i)
            while not is_trade_time(curDateTime):
                real_i += 1
                curDateTime = sttime + datetime.timedelta(seconds=frequencySecs * real_i)
            real_i += 1

            i += 1

            if curDateTime >= ndtime:
                break
            price = price + __r.random() - 0.5
            volume = __r.randint(1, 1000)
            cpt = [str(code_num) + code_suffix, price, str(curDateTime), volume]
            cpt.extend(__gen_ask_bid(price, ask_bid_num))
            retList.append(cpt)

    return retList

def setBeautifulPandasOptions():
    pd.set_option('display.max_columns', None)
    pd.set_option('display.max_colwidth', 3000)
    pd.set_option("display.min_rows", 5000)
    pd.set_option("display.max_rows", 10000)
    pd.set_option('display.width', None)

if __name__ == "__main__":
    data = gen_data(1, "20120101", "20120103", 10000, 60, 0)
    print(data)