from enum import Enum, auto

from typing import List


class TimeLyreSchema:
    def __init__(self,
                 column_names: List[str],
                 column_types: List[str]):
        self.column_names = column_names
        self.column_types = list(map(DataType.str_to_enum, column_types))
        self.tag_keys = list()
        self.tag_index = list()
        self.timestamp_key = ""
        self.timestamp_index = -1
        for i in range(0, len(self.column_names)):
            if self.column_types[i] == DataType.TAG:
                self.tag_keys.append(self.column_names[i])
                self.tag_index.append(i)
            elif self.column_types[i] == DataType.TIMESTAMP:
                if self.timestamp_index >= 0:
                    raise ValueError("Schema can not have two timestamp column")
                self.timestamp_key = self.column_names[i]
                self.timestamp_index = i

    @staticmethod
    def from_shiva_prop(prop_list: List):
        for prop in prop_list:
            if prop["key"] == "schema":
                name_list = prop["value"].split(",")
            elif prop["key"] == "data.types":
                type_list = prop["value"].split(",")
        return TimeLyreSchema(name_list, type_list)

    def get_tag_keys(self):
        return self.tag_keys

    def get_tag_index(self):
        return self.tag_index

    def get_column_names(self):
        return self.column_names

    def get_column_types(self):
        return self.column_types

    def get_timestamp_key(self):
        return self.timestamp_key

    def get_timestamp_index(self):
        return self.timestamp_index


class DataType(Enum):
    FLOAT = auto()
    INTEGER = auto()
    UINTEGER = auto()
    STRING = auto()
    DATETIME = auto()
    BOOLEAN = auto()
    TAG = auto()
    TIMESTAMP = auto()
    UNSIGNED =  auto()

    @classmethod
    def str_to_enum(cls, value):
        for enum_value in cls:
            if enum_value.name.lower() == value.lower():
                return enum_value
        raise ValueError(f"Invalid data type: {value}")
