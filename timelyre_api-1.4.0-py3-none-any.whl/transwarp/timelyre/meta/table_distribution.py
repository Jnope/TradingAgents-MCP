class TableDistribution:
    def __init__(self, table_id, table_name, tablets):
        self.__table_id = table_id
        self.__table_name = table_name
        self.__tablets = tablets

    @staticmethod
    def from_json(json_dict, is_timelyre2=False):
        table_id = json_dict['table_id']
        table_name = json_dict['table_name']
        tablets = []
        for x in json_dict['buckets']:
            tablets.append(TabletInfo.from_json(x, is_timelyre2))
        sorted(tablets, key=lambda y: y.tablet_id)
        return TableDistribution(table_id, table_name, tablets)

    def get_tablet(self, idx):
        return self.__tablets[idx]

    def get_all_tablets(self):
        return self.__tablets


class TabletInfo:
    def __init__(self, tablet_id, buckets):
        self.tablet_id = tablet_id
        self.buckets = buckets
        self.current_index = 0

    @staticmethod
    def from_json(json_dict, is_timelyre2=False):
        tablet_id = json_dict['tablet_id']
        talkers = json_dict['talkers']
        buckets = []
        for x in talkers:
            if is_timelyre2:
                buckets.append(TimeLyre2BucketInfo.from_json(x))
            else:
                buckets.append(BucketInfo.from_json(x))
        return TabletInfo(tablet_id, buckets)

    def get_bucket_info(self, index=0):
        return self.buckets[index]

    # 如果有下一个bucket，就使用下一个，如果没有，就返回None
    def get_next_bucket_info(self):
        if self.current_index >= len(self.buckets):
            return None
        bucket = self.buckets[self.current_index]
        self.current_index += 1
        return bucket


class BucketInfo:
    def __init__(self, bucket_name, http_addr, is_leader=True):
        self.bucket_name = bucket_name
        self.http_addr = http_addr
        self.is_leader = is_leader

    def __str__(self):
        return f"BucketInfo(bucket_name={self.bucket_name}, http_addr={self.http_addr}, is_leader={self.is_leader})"

    def __repr__(self):
        return f"BucketInfo(bucket_name={self.bucket_name}, http_addr={self.http_addr}, is_leader={self.is_leader})"

    def __hash__(self):
        return hash(self.bucket_name)

    def __eq__(self, other):
        if isinstance(other, BucketInfo):
            return self.bucket_name == other.bucket_name and \
                self.http_addr == other.http_addr and \
                self.is_leader == other.is_leader
        return False

    @staticmethod
    def from_json(json_dict):
        is_leader = json_dict['role'] == 'kLeader'
        bucket_name = json_dict['bucket_name']
        http_addr = f"{json_dict['talker_state']['host']}:{json_dict['talker_state']['port']}"
        return BucketInfo(bucket_name, http_addr, is_leader)


class TimeLyre2BucketInfo:
    def __init__(self, bucket_name, host, http_port, tcp_port=-1, is_leader=True):
        self.bucket_name = bucket_name
        self.host = host
        self.http_port = http_port
        self.tcp_port = tcp_port
        self.is_leader = is_leader

    def __str__(self):
        return f"TimeLyre2BucketInfo(bucket_name={self.bucket_name}, host={self.host}, http_port={self.http_port}, tcp_port={self.tcp_port}, is_leader={self.is_leader})"

    def __repr__(self):
        return f"TimeLyre2BucketInfo(bucket_name={self.bucket_name}, host={self.host}, http_port={self.http_port}, tcp_port={self.tcp_port}, is_leader={self.is_leader})"

    def __hash__(self):
        return hash(self.bucket_name)

    def __eq__(self, other):
        if isinstance(other, TimeLyre2BucketInfo):
            return (self.bucket_name == other.bucket_name and \
                    self.host == other.host and \
                    self.http_port == other.http_port and \
                    self.tcp_port == other.tcp_port and \
                    self.is_leader == other.is_leader)
        return False

    @staticmethod
    def from_json(json_dict):
        is_leader = json_dict['role'] == 'kLeader'
        bucket_name = json_dict['bucket_name']
        host = json_dict['talker_state']['host']
        http_port = json_dict['talker_state']['http_port']
        tcp_port = json_dict['talker_state']['tcp_port']
        return TimeLyre2BucketInfo(bucket_name, host, http_port, tcp_port, is_leader)
