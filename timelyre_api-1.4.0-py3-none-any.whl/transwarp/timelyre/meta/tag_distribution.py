from transwarp.timelyre.transport.read_request_builder import ReadRequestBuilder


class TagDistribution:
    def __init__(self, schema, tag_value_map, pk_map, table_distribution):
        self.__schema = schema
        self.__tag_value_map = tag_value_map
        self.__pk_map = pk_map
        self.__table_distribution = table_distribution

    '''输入一个tag_value，返回对应的host:port
    '''
    def get_tag_value_location(self, tag_value):
        if tag_value not in self.__tag_value_map:
            raise ValueError("no tag value was found in distribution")

        pk = self.__tag_value_map[tag_value]
        tablet_id = self.__pk_map[pk]
        tablet = self.__table_distribution.get_tablet(tablet_id)
        bucket = tablet.buckets[0]
        return bucket

    ''' 返回一个dict, 
        key是hostname, value是也是一个dict, 
        key是bucket info，value是一个tag value的list
    '''

    def get_host_map(self):
        # 先构造一个tag_value -> (host, bucket) 的映射
        map1 = {}
        for tag_value in self.__tag_value_map:
            bucket = self.get_tag_value_location(tag_value)
            host = bucket.http_addr.split(":")[0]
            map1[tag_value] = (host, bucket)

        res_map = {}
        for tag_value, v in map1.items():
            host = v[0]
            bucket = v[1]
            if host not in res_map:
                res_map[host] = {}
            inner_map = res_map[host]
            if bucket not in inner_map:
                inner_map[bucket] = []
            v_list = inner_map[bucket]
            v_list.append(tag_value)
        return res_map

    ''' 返回一个dict,
        key是hostname, value是一个ReadRequest的list
    '''
    def get_host_read_request_map(self, timestamp_filter=None, cols=None):
        host_map = self.get_host_map()
        new_map = {}
        for host, v in host_map.items():
            request_list = []
            for bucket, tag_list in v.items():
                # print(f"tag: {tag_list}, {bucket.bucket_name}, {bucket.http_addr}")
                request = (ReadRequestBuilder(bucket)
                           .with_tag_value_list(tag_list)
                           .with_schema(self.__schema)
                           .with_time_filter(timestamp_filter)
                           .with_cols(cols)
                           .build())
                request_list.append(request)
            new_map[host] = request_list
        return new_map

    def get_schema(self):
        return self.__schema
