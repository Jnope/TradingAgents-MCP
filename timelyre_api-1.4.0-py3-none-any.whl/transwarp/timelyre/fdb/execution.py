import shutil
from dataclasses import dataclass
from io import BytesIO
from pathlib import Path
from typing import Union

from transwarp.time_utils import str_to_datetime
from transwarp.timelyre.dfs.DFSClient import DFSClient
from transwarp.timelyre.fdb.db_utils import get_table_schema_and_range
from transwarp.timelyre.fdb.hdfs_utils import get_hdfs_files, get_hdfs_files_into_memory, hdfs_path_normalize_to_client, \
    get_hdfs_single_file_into_memory
from transwarp.timelyre.fdb.pq_utils import read_parquet_into_df_ext, read_parquet_bytes_into_df_ext, \
    anystr_encode_to_filename
from transwarp.timelyre.fdb.timelyre_fdb import SimpleConnInfo, FileDBClient
from transwarp.timelyre.quark import read_parquet_dir_multi_df, normalize_df
from transwarp.timelyre.timelyre_logger import getLogger

import datetime
import time
import os
import concurrent.futures
import re
import pandas as pd
from transwarp.timelyre.timelyre_public import DatabaseConn
import functools

BASE_DATE = datetime.date(year=2000, month=1, day=1)
RANGE_NAME_PATTERN = re.compile("(.*_lt_)(\d{4,10}_\d+_\d+)")


@dataclass
class TimeTableSpec:
    db: str
    tbl: str
    schema: list[tuple[str, str]]
    timestamp_col: str
    tag_cols: list[str]

    def full_tbl_name(self) -> str:
        return self.db + "." + self.tbl

    def copy_with(self, n_db, n_tbl):
        return TimeTableSpec(n_db, n_tbl, self.schema[:], self.timestamp_col, self.tag_cols[:])

    def copy(self):
        return TimeTableSpec(self.db, self.tbl, self.schema[:], self.timestamp_col, self.tag_cols[:])

    def is_single_tag_col(self) -> bool:
        return len(self.tag_cols) == 1

    def tag_cols_type(self) -> list[str]:
        return [self.find_col_schema(tc) for tc in self.tag_cols]

    def find_col_schema(self, col_name: str) -> str:
        return [x[1] for x in self.schema if x[0] == col_name][0]


def convert_to_datetime(date_obj):
    if isinstance(date_obj, datetime.datetime):
        d = date_obj
        return datetime.datetime(year=d.year, month=d.month, day=d.day)
    elif isinstance(date_obj, str):
        for date_format in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d'):
            try:
                # 如果解析成功，返回datetime对象
                d = datetime.datetime.strptime(date_obj, date_format)
                return datetime.datetime(year=d.year, month=d.month, day=d.day)
            except ValueError:
                # 如果解析失败，继续尝试下一个格式
                continue
        # 如果两种格式都失败，抛出异常
        raise ValueError(f"无法将字符串 '{date_obj}' 解析为datetime对象")
    else:
        raise ValueError(f"无法对象 '{date_obj}' 解析为datetime对象")


def datetime_to_str(date_obj):
    if isinstance(date_obj, datetime.datetime):
        return date_obj.strftime("%Y-%m-%d %H:%M:%S")
    elif isinstance(date_obj, datetime.date):
        return date_obj.strftime("%Y-%m-%d %H:%M:%S")
    else:
        raise ValueError(f"无法对象 '{date_obj}' 解析为string对象")


def _normalize_date_time(dt) -> datetime.datetime:
    if type(dt) == datetime.date:
        return datetime.datetime(year=dt.year, month=dt.month, day=dt.day)
    elif type(dt) == datetime.datetime:
        return dt
    else:
        raise ValueError("only support datetime and date")


def _normalize_range(user_st, user_nd) -> tuple:
    # 左边界的日期时间，变成日期
    user_st_dt = _normalize_date_time(user_st)
    st = user_st_dt.date()

    # 右边界的日期时间，变成日期。 注意： 如果不是当天的0点，那么右边界要往外一天，确保从内部取数据时不会少。
    user_nd_dt = _normalize_date_time(user_nd)
    if user_nd_dt.time() == datetime.time(0):
        nd = user_nd_dt.date()
    else:
        nd = user_nd_dt.date() + datetime.timedelta(days=1)
    return st, nd

def _time_range(st: datetime.date, nd: datetime.date, period_days=90, base_date=BASE_DATE):
    assert period_days >= 1 and period_days <= 100, "period days should in range [10, 100]"
    ret = []
    if st >= base_date:
        xx = (st - base_date).days // period_days
        yy = (nd - base_date).days // period_days + 1
        for i in range(xx, yy, 1):
            cur_st = base_date + datetime.timedelta(days=period_days * i)
            cur_nd = base_date + datetime.timedelta(days=period_days * (i + 1))
            if cur_nd < st or cur_st >= nd:
                pass
            else:
                # print(f"index {i} valid")
                ret.append((cur_st, cur_nd))
    return ret


def _post_dataframe_process(df):
    """
    对获取到的dataframe进行一些额外的处理，包括：
        1. 把时间列修正为local timezone的表示
    :param df:
    :return:
    """
    lz = datetime.datetime.now(datetime.timezone.utc).astimezone().tzinfo
    for (a, b) in df.select_dtypes('datetime64').items():
        if b.dt.tz is None:
            df[a] = b.dt.tz_localize(datetime.timezone.utc).dt.tz_convert(lz)


def MakeDatabaseConn(conn_info: SimpleConnInfo) -> DatabaseConn:
    conn = DatabaseConn(conn_info.tc_addr, conn_info.jdbc_addr, conn_info.db, auth_type="ldap",
                        username=conn_info.user, password=conn_info.pwd, token=conn_info.token, real_ui_host_port=conn_info.real_ui_host_port)
    return conn


class FileTableUtils:
    def __init__(self, dbconn_info: SimpleConnInfo, fetch_file_concurrency=10):
        self.conn_info = dbconn_info
        self.fetch_file_concurrency = fetch_file_concurrency

        hdfs_nn_addrs = dbconn_info.hdfs_nn_addrs
        if hdfs_nn_addrs is None:
            hdfs_nn_addrs = os.environ.get("HDFS_NN_ADDR", None)
        if hdfs_nn_addrs is None:
            raise ValueError("HDFS NN address is not specified.")

        self.hdfs_nn_addrs = hdfs_nn_addrs
        self.hdfs_client = DFSClient(hdfs_nn_addrs, dbconn_info.realm is not None, realm=dbconn_info.realm, keytab=dbconn_info.keytab_path)
        self.conn_info = dbconn_info
        self.conn = self._make_conn()
        pass

    def clone(self):
        return FileTableUtils(self.conn_info, self.fetch_file_concurrency)

    def _get_table_schema(self, table: str):
        db_name, tbl_name = table.split(".")
        data = self._conn().query_raw_data(
            sql=f"select column_id, column_name, column_type from system.columns_v where database_name=\"{db_name}\" and table_name=\"{tbl_name}\"")
        data = sorted(data, key=lambda x: int(x[0]))
        schema = [(x[1], x[2]) for x in data]
        if len(schema) == 0:
            raise RuntimeError(f"table {db_name}.{tbl_name} has no columns, and it may not be existed.")
        return schema

    def get_time_table_from_timelyre_table(self, db: str, tbl: str) -> TimeTableSpec:
        props = self._get_table_paras(db, tbl)
        assert "timelyre.timestamp.col" in props, f"{db}.{tbl} is not a timelyre table."
        time_col = props['timelyre.timestamp.col']
        tag_cols = [x.strip() for x in str(props["timelyre.tag.cols"]).split(",")]
        schema = self._get_table_schema(f"{db}.{tbl}")
        tts = TimeTableSpec(db, tbl, schema, time_col, tag_cols)
        return tts

    def _make_conn(self) -> DatabaseConn:
        conn = DatabaseConn(self.conn_info.tc_addr, self.conn_info.jdbc_addr, self.conn_info.db, auth_type="ldap",
                            username=self.conn_info.user, password=self.conn_info.pwd, token=self.conn_info.token, real_ui_host_port=self.conn_info.real_ui_host_port)
        return conn

    def _make_part_name(self, col, dt):
        if type(dt) == datetime.datetime:
            return col + "_LT_" + str(dt.date()).replace("-", "_")
        elif type(dt) == datetime.date:
            return col + "_LT_" + str(dt).replace("-", "_")

    def _get_table_paras(self, db_name, tbl_name) -> dict:
        paras = self._conn().query_raw_data(sql=f"select parameter_key, parameter_value from system.table_parameters_v "
                                                f"where database_name=\"{db_name}\" "
                                                f"and table_name=\"{tbl_name}\"")
        tbl_props = {}
        for x in paras:
            tbl_props[x[0]] = x[1]

        return tbl_props

    def _get_file_table_paras(self, db_name, tbl_name) -> dict:
        paras = self._conn().query_raw_data(sql=f"select parameter_key, parameter_value from system.table_parameters_v "
                                                f"where database_name=\"{db_name}\" "
                                                f"and table_name=\"{tbl_name}\"")
        tbl_props = {}
        for x in paras:
            tbl_props[x[0]] = x[1]

        assert tbl_props.get("is_timelyre_filetable", "false") == "true", f"{db_name}.{tbl_name} is not a fdb table."
        return tbl_props

    def __make_create_table_sql(self, tbl_name: str, schema: list, range_col: str, ranges: list,
                                format: str = "parquet", props: dict[str, str] = {}):

        schema_spec = ",".join([f"`{x[0]}` {x[1]}" for x in schema])
        range_col_spec = ""
        for x in schema:
            if x[0] == range_col:
                assert x[1].lower() == "date" or x[
                    1].lower() == "timestamp", f"{range_col} should be TIMESTAMP or DATE type."
                range_col_spec = f"{x[0]} {x[1]}"
                break
        rr = ranges[:]
        rr.append((rr[-1][1], None))
        range_spec = ",".join(
            [f"PARTITION {self._make_part_name(range_col, x[0])} VALUES LESS THAN ('{x[0]}')" for x in rr])

        extra_props = ""
        for k, v in props.items():
            extra_props += f""", \"{k}\"=\"{v}\""""

        base_stmt = f"CREATE TABLE {tbl_name}({schema_spec}) PARTITIONED BY RANGE({range_col}) ({range_spec}) STORED AS {format} " \
                    f"tblproperties(\"is_timelyre_filetable\"=\"true\" {extra_props})"
        return base_stmt

    def _conn(self):
        return self.conn

    def create_file_table(
            self,
            target_tbl: TimeTableSpec,
            time_range: tuple,
            segment_days: int,
            file_separate_by_target: bool
    ):
        x, y = _normalize_range(convert_to_datetime(time_range[0]), convert_to_datetime(time_range[1]))
        range_list = _time_range(x, y, period_days=segment_days)
        target_fdb_full_name = target_tbl.full_tbl_name()
        props = {
            "segment_days": segment_days,
            "file_separate_by_target": str(file_separate_by_target).lower(),
        }
        ct = self.__make_create_table_sql(tbl_name=target_fdb_full_name, schema=target_tbl.schema,
                                          range_col=target_tbl.timestamp_col, ranges=range_list, props=props)
        # 创建缓存表，range分区
        print(ct)
        getLogger().info(f"[Create File Table] {target_fdb_full_name}")
        self._conn().set_quark_mode()
        self._conn().run_simple_command(ct)
        pass

    def add_file_table_partitions(self):
        pass

    def _get_partitions(self, db_name: str, tbl_name: str, time_range: tuple):
        info = get_table_schema_and_range(self._conn(), db_name + "." + tbl_name)
        return info

    def add_partitions(self, target_tbl: TimeTableSpec, parts: list[tuple[datetime.date, datetime.date]]):
        self._conn().set_quark_mode()
        for x in parts:
            sql = f"alter table {target_tbl.db}.{target_tbl.tbl} add if not exists " + f"PARTITION {self._make_part_name(target_tbl.timestamp_col, x[1])} VALUES LESS THAN ('{x[1]}')"
            self._conn().run_simple_command(sql)

    def _check_partitions(self, time_range: tuple, segment_days: int, target_table: TimeTableSpec):
        x, y = _normalize_range(convert_to_datetime(time_range[0]), convert_to_datetime(time_range[1]))
        range_list = _time_range(x, y, period_days=segment_days)

        self._conn().set_quark_mode()

        target_meta = self._get_partitions(target_table.db, target_table.tbl, None)

        non_exists_parts = []
        for x in range_list:
            if x[1] in target_meta.parts:
                pass
            else:
                non_exists_parts.append((x[0], x[1]))
        return range_list, non_exists_parts

    def load_time_into_file_table(
            self,
            src_table: TimeTableSpec,
            time_range: tuple,
            target_table: TimeTableSpec,
            # target_combine: bool = True
    ):
        paras = self._get_file_table_paras(target_table.db, target_table.tbl)
        segment_days = int(paras["segment_days"])
        is_file_separate_by_target = paras["file_separate_by_target"] == 'true'
        assert not is_file_separate_by_target, 'Please use  load_target_time_into_file_table (but not load_target_time_into_file_table) for normal time file table.'

        range_list, non_exists_parts = self._check_partitions(time_range, segment_days, target_table)

        if len(non_exists_parts) != 0:
            getLogger().info(f"Add non-existent partitions {non_exists_parts}")
            self.add_partitions(target_table, non_exists_parts)

        self._conn().run_simple_command("set mapred.reduce.tasks=1")

        for x in range_list:
            part_name = self._make_part_name(target_table.timestamp_col, x[1])
            print(f"to truncate {target_table.full_tbl_name()} partitino {part_name}...")
            self._conn().run_simple_command(f"truncate table {target_table.full_tbl_name()} partition {part_name}")

            st = datetime_to_str(x[0])
            nd = datetime_to_str(x[1])

            # TODO(LTY): 合并成一个文件
            insert_stmt = f"insert into {target_table.full_tbl_name()} partition {part_name} " \
                          f"select * from {src_table.full_tbl_name()} where {src_table.timestamp_col} >= \"{st}\" and " \
                          f"{src_table.timestamp_col} < \"{nd}\" order by {','.join(target_table.tag_cols)}, {target_table.timestamp_col}"
            print(insert_stmt)
            self._conn().run_simple_command(insert_stmt)
        self._conn().run_simple_command("set mapred.reduce.tasks=-1")
        pass

    def _get_single_tag_value_file_name(self, tag_col_name: str, tag_value: str) -> str:
        raw = f"{tag_col_name}={tag_value}"
        return anystr_encode_to_filename(raw) + ".parquet"

    def load_target_time_into_file_table(
            self,
            src_table: TimeTableSpec,
            target: list,
            time_range: tuple,
            target_table: TimeTableSpec,
            convert_decimal_to_float64: bool
    ):
        paras = self._get_file_table_paras(target_table.db, target_table.tbl)
        segment_days = int(paras["segment_days"])
        is_file_separate_by_target = paras["file_separate_by_target"] == 'true'
        assert is_file_separate_by_target, 'Please use load_time_into_file_table (but not load_target_time_into_file_table) for target separated file table.'
        assert src_table.is_single_tag_col() and src_table.tag_cols_type()[0] == "string", "Currently only support tags with one column and its type is string"

        range_list, non_exists_parts = self._check_partitions(time_range, segment_days, target_table)

        if len(non_exists_parts) != 0:
            getLogger().info(f"Add non-existent partitions {non_exists_parts}")
            self.add_partitions(target_table, non_exists_parts)

        part_table = get_table_schema_and_range(self._conn(), f"{target_table.db}.{target_table.tbl}")

        for x in range_list:
            # part_name = self._make_part_name(target_table.timestamp_col, x[1])

            dfs_part_location = part_table.parts[x[1]].loc

            target_real_filename = self._get_single_tag_value_file_name(target_table.tag_cols[0], target[0][0])
            dfs_file_location = f"{dfs_part_location}/{target_real_filename}"
            #
            # self._conn().run_simple_command(f"dfs -rm {dfs_file_location}")

            st = datetime_to_str(x[0])
            nd = datetime_to_str(x[1])

            query_data_stmt = \
                f"select * from {src_table.full_tbl_name()} where {src_table.timestamp_col} >= \"{st}\" and " \
                f"{src_table.timestamp_col} < \"{nd}\" and {src_table.tag_cols[0]} = \"{target[0]}\" order by {','.join(target_table.tag_cols)}, {target_table.timestamp_col}"

            df = self._conn().direct_query_as_df(table_name=src_table.full_tbl_name(),
                                                 tag_value_list=[target[0]],
                                                 time_filter=[st, nd])
            # df = self._conn().query_as_df(query = query_data_stmt)

            df: pd.DataFrame

            normalize_df(df, src_table.schema, convert_decimal_to_float64)
            bytes = df.to_parquet(engine='pyarrow', use_deprecated_int96_timestamps=True)

            norm_location = hdfs_path_normalize_to_client(dfs_file_location)

            self.hdfs_client._client.write(norm_location, bytes, overwrite=True)
        pass
    def load_targets_time_into_file_table(self):
        pass

    def _get_table_schema(self, table: str):
        db_name, tbl_name = table.split(".")
        data = self._conn().query_raw_data(
            sql=f"select column_id, column_name, column_type from system.columns_v where database_name=\"{db_name}\" and table_name=\"{tbl_name}\"")
        data = sorted(data, key=lambda x: int(x[0]))
        schema = [(x[1], x[2]) for x in data]
        if len(schema) == 0:
            raise RuntimeError(f"table {db_name}.{tbl_name} has no columns, and it may not be existed.")
        return schema

    def _query(self, db_name, tbl_name, tcol: str, time_range: tuple[str, str], tag_cols: list, tag_values: list,
               sel_cols: list, use_tag_values_file: bool = False):
        assert tag_values is None or len(tag_cols) == 1, "当前只支持单列表"

        orig_sel_cols = sel_cols[:]

        # 需要时间列做排序（部分情况也需要做计算引擎层的过滤）
        if tcol not in sel_cols:
            sel_cols.append(tcol)

        time_range = (str_to_datetime(time_range[0]), str_to_datetime(time_range[1]))

        if tag_values is None:
            read_parquet_func = functools.partial(read_parquet_into_df_ext,
                                                  single_tag_col_name=None,
                                                  tag_values=None,
                                                  time_col=tcol,
                                                  time_range=time_range, sel_cols=sel_cols)
            read_all_func = functools.partial(read_parquet_bytes_into_df_ext,
                                                  single_tag_col_name=None,
                                                  tag_values=None,
                                                  time_col=tcol,
                                                  time_range=time_range, sel_cols=sel_cols)
        else:
            read_parquet_func = functools.partial(read_parquet_into_df_ext,
                                                  single_tag_col_name=tag_cols[0],
                                                  tag_values=tag_values,
                                                  time_col=tcol,
                                                  time_range=time_range, sel_cols=sel_cols)
            read_all_func = functools.partial(read_parquet_bytes_into_df_ext,
                                                  single_tag_col_name=tag_cols[0],
                                                  tag_values=tag_values,
                                                  time_col=tcol,
                                                  time_range=time_range, sel_cols=sel_cols)

        schema = self._get_table_schema(f"{db_name}.{tbl_name}")
        t11 = time.time()
        data = self._conn().query_raw_data(
            sql=f"select partition_name, location from system.range_partitions_v where database_name=\"{db_name}\" and table_name=\"{tbl_name}\"")
        t21 = time.time()
        print(f"fetch partition info cost {t21 - t11}")
        user_st, user_nd = time_range
        print(time.time())

        st, nd = _normalize_range(convert_to_datetime(user_st), convert_to_datetime(user_nd))

        part_locs = {}
        for xx in data:
            part_locs[xx[0]] = xx[1]

        prefix = ""
        all_ranges = []
        for x in data:
            m = re.match(RANGE_NAME_PATTERN, x[0])
            if m:
                prefix = m.group(1)
                dt_str = m.group(2)
                year_str, month_str, day_str = dt_str.split("_")
                dt = datetime.date(year=int(year_str), month=int(month_str), day=int(day_str))
                all_ranges.append(dt)

        selected_ranges = []
        if len(all_ranges) == 0:
            return pd.DataFrame(columns=[x[0] for x in schema])

        all_ranges.sort()
        if all_ranges[0] > st:
            selected_ranges.append(all_ranges[0])

        last = all_ranges[0]
        for x in all_ranges[1:]:
            cur_st, cur_nd = last, x
            if cur_st >= nd or cur_nd <= st:
                pass
            else:
                selected_ranges.append(x)
            last = x

        def _fetch_one_range_part_file_into_memory(range_part_loc):
            t1 = time.time()
            data_bytes = get_hdfs_files_into_memory(range_part_loc, self.conn_info.realm, self.conn_info.keytab_path,
                                                    nn_addr=self._fdb_client.hdfs_client.http_active_nn)
            t2 = time.time()
            getLogger().info(f"fetch_file {t2 - t1}")
            if data_bytes:
                print(f"fetch_file {t2 - t1}, len: {len(data_bytes)}")
            else:
                print(f"fetch_file {t2 - t1}, No data")
            return data_bytes

        def _fetch_one_range_tag_value_file_into_memory(file_loc):
            t1 = time.time()
            data_bytes = get_hdfs_single_file_into_memory(file_loc, self.conn_info.realm, self.conn_info.keytab_path,
                                                    nn_addr=self.hdfs_client.http_active_nn)
            t2 = time.time()
            getLogger().info(f"fetch_file {t2 - t1}")
            if data_bytes:
                print(f"fetch_file {t2 - t1}, len: {len(data_bytes)}")
            else:
                print(f"fetch_file {t2 - t1}, No data")
            return data_bytes

        dfs = []
        all_fetch_part_locs = []
        for x in selected_ranges:
            part_name = prefix + str(x).replace("-", "_")
            part_loc = part_locs[part_name]
            all_fetch_part_locs.append(part_loc)
        print(f"Fetch from locs ({len(all_fetch_part_locs)})")
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.fetch_file_concurrency) as executor:
            dfs = []
            # 并行下载文件
            x0 = time.time()
            if not use_tag_values_file:
                datas = list(executor.map(_fetch_one_range_part_file_into_memory, all_fetch_part_locs))
                bytes_list = [x for d in datas if d for x in d if x]
            else:
                locs = []
                for tv in tag_values:
                    for x in all_fetch_part_locs:
                        locs.append(x + "/" + self._get_single_tag_value_file_name(tag_cols[0], tv[0]))
                datas = list(executor.map(_fetch_one_range_tag_value_file_into_memory, locs))
                bytes_list = datas
            x1 = time.time()
            if False:
                for data_byetes in datas:
                    if data_byetes is not None:
                        this_range_dfs = []
                        for bytes in data_byetes:
                            if bytes is not None:
                                data = BytesIO(bytes)
                                df = read_parquet_func(data)
                                this_range_dfs.append(df)
                        dfs.append(this_range_dfs)
            else:
                df = read_all_func(bytes_list)
                dfs.append([df])
            x2 = time.time()
            print(f"get data {x1 - x0} big df load cost {x2 - x1}")
        dfs = [element for row in dfs for element in row]
        tt1 = time.time()
        if len(dfs) > 1:
            ret_df = pd.concat(dfs, ignore_index=True)
        else:
            ret_df = dfs[0]
        tt2 = time.time()
        print(time.time())
        print(f"Combine final df cost {tt2 - tt1}")
        _post_dataframe_process(ret_df)
        print(time.time())
        if len(ret_df) == 0:
            return pd.DataFrame(columns=[x[0] for x in schema])

        # 时间过滤已经下推，无需进一步过滤
        # ret_df = slice_timed_df(ret_df,  tcol, time_range[0], time_range[1], ignore_index=True)

        # ret_df = ret_df.loc[:, orig_sel_cols]
        if len(sel_cols) > len(orig_sel_cols):
            ret_df.drop(columns=[tcol], inplace=True)

        print(time.time())
        return ret_df

    def read_targets_time_from_table(self, tbl: TimeTableSpec, time_range: tuple, tag_values: list, sel_cols: list,
                                     separate_df_by_tag_values: bool = False) -> Union[pd.DataFrame, dict[object, pd.DataFrame]]:
        print(time.time())
        t1 = time.time()
        paras = self._get_file_table_paras(tbl.db, tbl.tbl)
        t2 = time.time()
        is_file_separate_by_target = paras['file_separate_by_target'].lower() == "true"
        if is_file_separate_by_target:
            values_dfs = {}
            for tv in tag_values:
                df = self._query(tbl.db, tbl.tbl, tbl.timestamp_col, time_range, tbl.tag_cols, [tv], sel_cols, use_tag_values_file=True)
                values_dfs[tv] = df
            if separate_df_by_tag_values:
                return values_dfs
            else:
                df = pd.concat(values_dfs.values(), ignore_index=True)
                return df
        else:
            assert not separate_df_by_tag_values, "Todo"
            df = self._query(tbl.db, tbl.tbl, tbl.timestamp_col, time_range, tbl.tag_cols, tag_values, sel_cols)
            t3 = time.time()
            print(f"read local df cost {t2 - t1} {t3 - t2}")
            print(time.time())
            return df


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1:
        realm = sys.argv[1]
        keytab = sys.argv[2]
    else:
        realm = None
        keytab = None

    if len(sys.argv) >= 4:
        trange = sys.argv[3]
        xx = trange.split(",")
        a = xx[0]
        b = xx[1]
    else:
        a = "2024-02-26"
        b = "2024-04-04"

    print(f"Read range {a} {b}")

    IDC_1 = {
        "JDBC": "jdbc:hive2://172.18.20.13:10000",
        "TIMECHORD": "172.18.20.13:9998",
        "HDFS": "idc13:50070;idc14:50070",
    }
    TQ_DEV_NODE_1 = {
        "JDBC": "jdbc:hive2://172.18.192.79:10000",
        "TIMECHORD": "172.18.192.78:9999",
        "HDFS": "tq-dev-node4:50070;tq-dev-node5:5007",
        "UI_HOST_PORT": "172.18.192.79:8388",
    }

    print(f"Realm: {realm}, Keytab: {keytab}")
    env = TQ_DEV_NODE_1
    JDBC_HEEP_PROXY = env["TIMECHORD"]
    REAL_CONN = env["JDBC"]
    HDFS_ADDRS = env["HDFS"]
    conn_info = SimpleConnInfo(
        tc_addr=JDBC_HEEP_PROXY,
        jdbc_addr=REAL_CONN,
        hdfs_nn_addrs=HDFS_ADDRS,
        user="admin",
        pwd="admin",
        token="wOAseBo1stuRYlvjtZDR-TDH",
        db="default",
        realm=realm,
        keytab_path=keytab,
        real_ui_host_port=env['UI_HOST_PORT'],
    )

    xx = time.time()
    ftu = FileTableUtils(conn_info)

    x = ftu.get_time_table_from_timelyre_table("meta_data", "future_bar_1min")
    yy = time.time()
    print(f"init cost {yy - xx} seconds")

    if False:
        conn = DatabaseConn(conn_info.tc_addr, conn_info.jdbc_addr, conn_info.db, auth_type="ldap",
                            username=conn_info.user, password=conn_info.pwd, real_ui_host_port="172.18.192.79:8388",
                            token="wOAseBo1stuRYlvjtZDR-TDH")
        t1 = time.time()
        df = conn.direct_query_as_df("meta_data.future_bar_1min", ["code", "series", "datetime", "close"],
                                     ["A2501.DCE"],
                                     [a, b])
        t2 = time.time()
        print(f"direct costs {t2 - t1} seconds")
        print(df)

    src_tbl = x
    dst_tbl = x.copy_with("ray_test", "future_bar_1min_code")

    # ftu.create_file_table(
    #     dst_tbl,
    #     ("2024-01-01", "2024-04-01", ),
    #     7,
    #     True
    # )

    # ftu.load_target_time_into_file_table(
    #     src_table=src_tbl,
    #     time_range=("2024-03-01", "2024-04-01", ),
    #     target=["A2501.DCE"],
    #     target_table=dst_tbl,
    # )

    print("finish load")

    t1 = time.time()
    df = ftu.read_targets_time_from_table(dst_tbl, (a, b,), tag_values=["A2501.DCE"],
                                          sel_cols=["code", "series", "datetime", "close"])
    t2 = time.time()
    print(df)
    print(f"costxx {t2 - t1} seconds")