import datetime
import re
import time
from dataclasses import dataclass

from transwarp.timelyre import DatabaseConn
from transwarp.timelyre.connection import SimpleConnInfo
from transwarp.timelyre.timelyre_logger import getLogger


RANGE_NAME_PATTERN = re.compile("(.*_lt_)(\d{4,10}_\d+_\d+)")
BASE_DATE = datetime.date(year=2000, month=1, day=1)

@dataclass
class PartInfo:
    st: datetime.date
    nd: datetime.date
    # must_full: bool
    part_name: str
    loc: str

@dataclass
class PartTable:
    db: str
    tbl: str
    schema: list
    parts: dict[datetime.date, PartInfo]
    period_days: int
    min_date: datetime.date
    max_date: datetime.date

    def find_base_date(self):
        if len(self.parts) == 0:
            return BASE_DATE
        else:
            #可能有一些已经存在的表的base date跟代码中不一致，那得以已经存储的表的base date为准。
            #此处采用的方法是，把存在的表的最早一个对齐时间，往前推，推到当前base date之前即可。
            xx = list(self.parts.keys())
            xx.sort()
            first_key_date = xx[0]
            cur_base_date: datetime.date = first_key_date
            if first_key_date > BASE_DATE:
                xx = int((first_key_date - BASE_DATE).days / self.period_days)
                cur_base_date -= datetime.timedelta(days=self.period_days * xx)
                while cur_base_date > BASE_DATE:
                    cur_base_date -= datetime.timedelta(days=self.period_days)
            else:
                cur_base_date = first_key_date
            return cur_base_date



def make_conn(conn_info: SimpleConnInfo) -> DatabaseConn:
    conn = DatabaseConn(conn_info.tc_addr, conn_info.jdbc_addr, conn_info.db, auth_type="ldap",
                        username=conn_info.user, password=conn_info.pwd, token=conn_info.token,
                        real_ui_host_port=conn_info.real_ui_host_port)
    return conn

def get_table_schema(conn: DatabaseConn, table: str):
    db_name, tbl_name = table.split(".")
    data = conn.query_raw_data(
        sql=f"select column_id, column_name, column_type from system.columns_v where database_name=\"{db_name}\" and table_name=\"{tbl_name}\"")
    data = sorted(data, key=lambda x: int(x[0]))
    schema = [(x[1], x[2]) for x in data]
    if len(schema) == 0:
        raise RuntimeError(f"table {db_name}.{tbl_name} has no columns, and it may not be existed.")
    return schema


def get_table_schema_and_range(conn: DatabaseConn, table: str):
        db_name, tbl_name = table.split(".")
        schema = get_table_schema(conn, table)

        t11 = time.time()
        data = conn.query_raw_data(
            sql=f"select partition_name, location from system.range_partitions_v where database_name=\"{db_name}\" and table_name=\"{tbl_name}\"")
        t21 = time.time()
        getLogger().info(f"fetch partition info cost {t21 - t11}")

        prefix = ""
        all_ranges = []
        for x in data:
            m = re.match(RANGE_NAME_PATTERN, x[0])
            if m:
                dt_str = m.group(2)
                year_str, month_str, day_str = dt_str.split("_")
                dt = datetime.date(year=int(year_str), month=int(month_str), day=int(day_str))
                all_ranges.append((dt, x[0], x[1]))

        all_ranges = sorted(all_ranges, key=lambda x: x[0])

        all_part_infos = []
        for idx, x in enumerate(all_ranges):

            #第一个是 MINVALUE-nd的段，我们并不使用
            if idx == 0:
                continue

            st = all_ranges[idx - 1][0]
            nd = x[0]
            # must_full = idx != 0 and idx != len(all_ranges) - 2
            pi = PartInfo(st, nd, x[1], x[2])
            all_part_infos.append(pi)

        part_infos = {}
        for x in all_part_infos:
            part_infos[x.nd] = x

        pd = 0
        if True:
            pinfos = list(part_infos.items())
            assert len(pinfos) > 0, "This is not a valid filedb table."
            pd = (pinfos[0][1].nd - pinfos[0][1].st).days

        assert pd >= 1 and pd <= 100, "period days should in range [1, 100]"
        return PartTable(db_name, tbl_name, schema, part_infos, pd, min_date=all_part_infos[0].st, max_date=all_part_infos[-1].nd)