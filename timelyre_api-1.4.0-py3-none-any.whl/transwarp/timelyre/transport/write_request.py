from pandas import DataFrame

from transwarp.timelyre.meta.table_distribution import BucketInfo


class WriteRequest:
    def __init__(self,
                 bucket: BucketInfo,
                 df: DataFrame):
        self.bucket = bucket
        self.df = df

    def make_url(self):
        url = f"/writeBinary?db={self.bucket.bucket_name}"


    def make_bytes(self):
        pass