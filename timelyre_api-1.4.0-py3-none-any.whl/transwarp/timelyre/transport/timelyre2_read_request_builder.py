from transwarp.timelyre.meta.table_distribution import TimeLyre2BucketInfo, TabletInfo
from transwarp.timelyre.transport.timelyre2_read_request import TimeLyre2ReadRequest
from typing import List


class TimeLyre2ReadRequestBuilder:
    def __init__(self, bucket: TimeLyre2BucketInfo, tablet: TabletInfo = None):
        self.tablet = tablet
        self.bucket = bucket
        self.cols = None
        self.tag_key = None
        self.ts_col = None
        self.tag_value_list = []
        self.time_filter = []
        self.limit = None
        self.query = None
        self.fmt = "parquet"
        self.compression = "none"
        self.use_final = True
        self.username = "default"
        self.password = ""

    def build(self):
        if self.bucket is None:
            raise Exception("no bucket info was provided")
        if self.cols is None:
            raise Exception("no cols was provided")
        if self.tag_value_list is not None and len(self.tag_value_list) > 0 and self.tag_key is None:
            raise Exception("provide tag value list, but no tag_key was provided")
        return TimeLyre2ReadRequest(bucket=self.bucket,
                                    tablet=self.tablet,
                                    query=self.query,
                                    cols=self.cols,
                                    tag_key=self.tag_key,
                                    tag_value_list=self.tag_value_list,
                                    ts_col_name=self.ts_col,
                                    time_filter=self.time_filter,
                                    limit=self.limit,
                                    fmt=self.fmt,
                                    compression=self.compression,
                                    use_final=self.use_final,
                                    username=self.username,
                                    password=self.password)

    def with_bucket(self, bucket: TimeLyre2BucketInfo):
        self.bucket = bucket
        return self

    def with_query(self, query: str):
        self.query = query
        return self

    def with_cols(self, cols: List[str]):
        if cols is not None and len(cols) > 0:
            self.cols = cols
        return self

    def with_ts_col(self, ts_col):
        self.ts_col = ts_col
        return self

    def with_tag_key(self, tag_key):
        self.tag_key = tag_key
        return self

    def with_tag_value_list(self, tag_value_list: list):
        self.tag_value_list = tag_value_list
        return self

    def with_time_filter(self, time_filter: list):
        self.time_filter = time_filter
        return self

    def with_limit(self, limit: int):
        self.limit = limit
        return self

    def with_fmt(self, fmt: str):
        self.fmt = fmt
        return self

    def with_compression(self, compression: str):
        self.compression = compression
        return self

    def with_use_final(self, use_final: bool):
        self.use_final = use_final
        return self

    def with_username(self, username: str):
        self.username = username
        return self

    def with_password(self, password: str):
        self.password = password
        return self
