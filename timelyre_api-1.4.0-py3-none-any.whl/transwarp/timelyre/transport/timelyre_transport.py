import http.client
import json
import time

import pandas as pd
from uuid import uuid4

from transwarp.timelyre.meta.table_distribution import BucketInfo
from transwarp.timelyre.timelyre_logger import getLogger
from transwarp.timelyre.transport.read_request import ReadRequest
from transwarp.timelyre.transport.read_request_builder import ReadRequestBuilder
from transwarp.timelyre.transport.transport_util import process_response, dataframe_timestamp_transform


class TimeLyreTransporter:
    """ 对timelyre单talker的访问接口
    """

    @staticmethod
    def read_dataframe(read_request: ReadRequest):
        uuid = uuid4()
        simple_query = read_request.make_simple_query()
        conn = http.client.HTTPConnection(f"{read_request.http_addr}")
        url = read_request.make_url()
        t1 = time.time_ns()
        count = 0
        getLogger().info(f"[{uuid}] start read dataframe, simple_query: {simple_query}, url: {url} ")
        try:
            conn.request("POST", url, simple_query)
            response = conn.getresponse()
            df_array = []
            schema = None
            if response.status == http.client.OK:
                while True:
                    ret = process_response(response, read_request.arrow_transfer, read_request.compress)
                    if ret[0] is not None:
                        schema = ret[0]
                    df = ret[1]
                    if df is None:
                        break
                    # 处理当前块的数据
                    count += 1
                    getLogger().info(f"[{uuid}] read one chunk, size: {len(df)}")
                    df_array.append(df)
            else:
                error_bytes = response.read()
                error_msg = ""
                if len(error_bytes) > 0:
                    error_body = error_bytes.decode('utf-8')
                    error_json = json.loads(error_body)
                    if isinstance(error_json, str):
                        error_msg = error_json
                    else:
                        error_msg = error_json['message']
                raise ValueError(f"[{uuid}] http response not ok, status: {response.status}, msg: {error_msg}")
            if len(df_array) > 0:
                df = pd.concat(df_array, ignore_index=True)
                dataframe_timestamp_transform(df, schema['types'])
                df.columns = read_request.cols
                t2 = time.time_ns()
                getLogger().info(
                    f"[{uuid}] finish read dataframe, shape: {df.shape}, chunk count: {count}, cost {(t2 - t1) / 1000000} ms")
            else:
                return None
            return df
        except Exception as e:
            # 尝试下一个分片的读取
            next_read_request = read_request.make_next_bucket_read_request()
            if next_read_request is None:
                raise RuntimeError(f"read_dataframe failed, http_addr: {read_request.http_addr} url: {url}, "
                                   f"simple_query: {simple_query}") from e
            else:
                getLogger().info(f"[{uuid}] read dataframe failed, retry for next bucket")
                return TimeLyreTransporter.read_dataframe(next_read_request)
        finally:
            # 关闭连接
            conn.close()


    @staticmethod
    def read_bytes(read_request: ReadRequest):
        uuid = uuid4()
        simple_query = read_request.make_simple_query()
        conn = http.client.HTTPConnection(f"{read_request.http_addr}")
        url = read_request.make_url()
        t1 = time.time_ns()
        getLogger().info(f"[{uuid}] start read dataframe, simple_query: {simple_query}, url: {url} ")
        try:
            conn.request("POST", url, simple_query)
            response = conn.getresponse()
            df_array = []
            schema = None
            if response.status == http.client.OK:
                while True:
                    schema_obj, data = process_response(response, read_request.arrow_transfer, ret_raw_bytes=True)
                    if data is None:
                        break
                    yield schema_obj, data
            else:
                error_bytes = response.read()
                error_msg = ""
                if len(error_bytes) > 0:
                    error_body = error_bytes.decode('utf-8')
                    error_json = json.loads(error_body)
                    if isinstance(error_json, str):
                        error_msg = error_json
                    else:
                        error_msg = error_json['message']
                raise ValueError(f"[{uuid}] http response not ok, status: {response.status}, msg: {error_msg}")
        except Exception as e:
            # 尝试下一个分片的读取
            next_read_request = read_request.make_next_bucket_read_request()
            if next_read_request is None:
                raise RuntimeError(f"read_dataframe failed, http_addr: {read_request.http_addr} url: {url}, "
                                   f"simple_query: {simple_query}") from e
            else:
                getLogger().info(f"[{uuid}] read dataframe failed, retry for next bucket")
                return TimeLyreTransporter.read_dataframe(next_read_request)
        finally:
            # 关闭连接
            conn.close()

    def write_dataframe(self, write_request):
        conn = http.client.HTTPConnection(f"{write_request.http_addr}")
        url = write_request.make_url()
        bytes = write_request.make_bytes()
        try:
            conn.request("POST", url, bytes)
        finally:
            # 关闭连接
            conn.close()


def all_cases(bucket: BucketInfo,
              compress: str):
    cols = ['code', 'datetime', 'ask_price_1', 'ask_volume_1']
    tag_list = ["CF2405.ZCE"]
    tag_key = "code"
    time_range = ["2023-11-01 08:30:00", "2023-11-01 09:30:00"]

    # no filter
    # req1 = (ReadRequestBuilder(bucket)
    #         .with_cols(cols)
    #         .with_compress(compress)
    #         .build())
    # df = TimeLyreTransporter.read_dataframe(read_request=req1)
    # print(f"\n[{compress}] no filter: {df.shape}")

    # with timerange filter
    req2 = (ReadRequestBuilder(bucket)
            .with_cols(cols)
            .with_compress(compress)
            .with_time_filter(time_range)
            .build())
    df = TimeLyreTransporter.read_dataframe(read_request=req2)
    print(f"[{compress}] time filter: {df.shape}")

    # with tag and timerange filter
    req3 = (ReadRequestBuilder(bucket)
            .with_cols(cols)
            .with_compress(compress)
            .with_time_filter(time_range)
            .with_tag_key(tag_key)
            .with_tag_value_list(tag_list)
            .build())
    df = TimeLyreTransporter.read_dataframe(read_request=req3)
    print(f"[{compress}] tag and time filter: {df.shape}")

    # change chunk size
    req4 = (ReadRequestBuilder(bucket)
            .with_cols(cols)
            .with_compress(compress)
            .with_time_filter(time_range)
            .with_tag_key(tag_key)
            .with_tag_value_list(tag_list)
            .with_chunk_size(6000)
            .build())
    df = TimeLyreTransporter.read_dataframe(read_request=req4)
    print(f"[{compress}] tag and time filter, chunk size 6000: {df.shape}")


def test_local():
    http_addr = "idc15:40716"
    bucket_name = "4738b1a09cef4e67bcc37901855c58fd-1-3072415"
    bucket = BucketInfo(bucket_name, http_addr)
    compress_libs = ["none", "snappy", "gzip", "zstd", "zip"]
    for compress in compress_libs:
        all_cases(bucket, compress)
