import io
import os
import time

from clickhouse_connect.driver import httputil

from transwarp.timelyre.meta.table_distribution import TimeLyre2BucketInfo
from transwarp.timelyre.timelyre_logger import getLogger
from transwarp.timelyre.transport.timelyre2_read_request import TimeLyre2ReadRequest
from transwarp.timelyre.transport.timelyre2_read_request_builder import TimeLyre2ReadRequestBuilder
import pyarrow.parquet as pq

pool_max_size = int(os.getenv("POOL_MAX_SIZE", 10))
num_pool = int(os.getenv("NUM_POOLS", 20))
default_pool_mgr = httputil.get_pool_manager(maxsize=pool_max_size, num_pools=num_pool)


class TimeLyre2Transporter:

    @staticmethod
    def read_dataframe(read_request: TimeLyre2ReadRequest):
        from clickhouse_connect import get_client
        perf_list = [time.perf_counter_ns()]  # 0
        if read_request.compression == "none":
            client = get_client(host=read_request.host, username=read_request.username, password=read_request.password,
                                port=read_request.http_port, pool_mgr=default_pool_mgr)
        else:
            client = get_client(host=read_request.host, username=read_request.username, password=read_request.password,
                                port=read_request.http_port, pool_mgr=default_pool_mgr,
                                compression=read_request.compression)
        perf_list.append(time.perf_counter_ns())  # 1
        sql = read_request.make_query()
        getLogger().info(f"[TimeLyre2Transporter] start read_dataframe, {read_request.host}:{read_request.http_port}, "
                         f"fmt: {read_request.fmt}, sql: {sql}")
        if read_request.fmt == "arrow":
            perf_list.append(time.perf_counter_ns())  # 2
            arrow_table = client.query_arrow(sql)
            perf_list.append(time.perf_counter_ns())  # 3
            df = arrow_table.to_pandas()
            perf_list.append(time.perf_counter_ns())  # 4
        elif read_request.fmt == "parquet":
            perf_list.append(time.perf_counter_ns())  # 2
            parquet_bytes = client.raw_query(sql, fmt="parquet")
            parquet_bytes_len = len(parquet_bytes)
            perf_list.append(time.perf_counter_ns())  # 3
            pq_table = pq.read_table(io.BytesIO(parquet_bytes))
            perf_list.append(time.perf_counter_ns())  # 4
            df = pq_table.to_pandas()
            perf_list.append(time.perf_counter_ns())  # 5
        else:
            perf_list.append(time.perf_counter_ns())  # 2
            df = client.query_df(sql)
            perf_list.append(time.perf_counter_ns())  # 3
        from transwarp.timelyre.timelyre2 import timelyre2_helper
        df = timelyre2_helper.dataframe_timestamp_transform(df)
        perf_list.append(time.perf_counter_ns())  #

        def toMs(t):
            return t / 1000000

        # 日志输出
        if read_request.fmt == "arrow":
            getLogger().info(
                f"[TimeLyre2Transporter] finish read_dataframe, fmt: arrow, df size: {len(df)}, "
                f"{read_request.host}:{read_request.http_port}, "
                f"compression: {read_request.compression}, "
                f"total_cost: {toMs(perf_list[5] - perf_list[0])} ms, "
                f"get_client: {toMs(perf_list[1] - perf_list[0])} ms, "
                f"query_arrow: {toMs(perf_list[3] - perf_list[2])} ms, "
                f"to_pandas: {toMs(perf_list[4] - perf_list[3])} ms, "
                f"adjust tz: {toMs(perf_list[5] - perf_list[4])} ms")
        elif read_request.fmt == "parquet":
            getLogger().info(
                f"[TimeLyre2Transporter] finish read_dataframe, fmt: parquet, df size: {len(df)}, "
                f"{read_request.host}:{read_request.http_port}, "
                f"compression: {read_request.compression}, "
                f"parquet_bytes_len: {parquet_bytes_len}, "
                f"total_cost: {toMs(perf_list[6] - perf_list[0])} ms, "
                f"get_client: {toMs(perf_list[1] - perf_list[0])} ms, "
                f"query_pq_bytes: {toMs(perf_list[3] - perf_list[2])} ms, "
                f"pq_read_table: {toMs(perf_list[4] - perf_list[3])} ms, "
                f"to_pandas: {toMs(perf_list[5] - perf_list[4])} ms, "
                f"adjust tz: {toMs(perf_list[6] - perf_list[5])} ms")
        else:
            getLogger().info(
                f"[TimeLyre2Transporter] finish read_dataframe, fmt: none, df size: {len(df)}, "
                f"{read_request.host}:{read_request.http_port}, "
                f"compression: {read_request.compression}, "
                f"total_cost {toMs(perf_list[4] - perf_list[0])} ms, "
                f"get_client: {toMs(perf_list[1] - perf_list[0])} ms, "
                f"query_df: {toMs(perf_list[3] - perf_list[2])} ms, "
                f"adjust tz: {toMs(perf_list[4] - perf_list[3])} ms")
        return df


def test_local():
    host = "idc12"
    http_port = 8224
    bucket_name = "166a2a10b5134e5680a38c86cff2948c_0_45"
    bucket = TimeLyre2BucketInfo(bucket_name, host, http_port)
    cols = ['code', 'ts', 'high', 'open', 'low', 'close', 'volume']
    tag_list = ["198.CN", "199.CN"]
    tag_key = "code"
    ts_col = "ts"
    time_range = ["2024-01-01 09:30:00", "2024-01-02 09:30:00"]
    limit = 10

    # with timerange filter
    req = (TimeLyre2ReadRequestBuilder(bucket)
           .with_cols(cols)
           .with_tag_key(tag_key)
           .with_tag_value_list(tag_list)
           .with_ts_col(ts_col)
           .with_time_filter(time_range)
           .with_limit(limit)
           .with_password("timelyre")
           .build())
    df = TimeLyre2Transporter.read_dataframe(read_request=req)
    print(df)
