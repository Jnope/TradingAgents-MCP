from typing import List

from transwarp.timelyre.meta.table_distribution import BucketInfo, TabletInfo
from transwarp.timelyre.meta.timelyre_schema import TimeLyreSchema
from transwarp.timelyre.transport.read_request import ReadRequest


class ReadRequestBuilder:
    def __init__(self, bucket: BucketInfo, tablet: TabletInfo = None):
        self.tablet = tablet
        self.bucket = bucket
        self.cols = None
        self.tag_key = None
        self.tag_value_list = []
        self.time_filter = []
        self.chunk_size = 100000
        self.vec_read = True
        self.arrow_transfer = True
        self.compress = "none"

    def build(self):
        if self.bucket is None:
            raise Exception("no bucket info was provided")
        if self.cols is None:
            raise Exception("no cols was provided")
        if len(self.tag_value_list) > 0 and self.tag_key is None:
            raise Exception("provide tag value list, but no tag_key was provided")
        return ReadRequest(bucket=self.bucket,
                           tablet=self.tablet,
                           cols=self.cols,
                           tag_key=self.tag_key,
                           tag_value_list=self.tag_value_list,
                           time_filter=self.time_filter,
                           chunk_size=self.chunk_size,
                           vec_read=self.vec_read,
                           use_arrow_transfer=self.arrow_transfer,
                           compress=self.compress)

    def with_schema(self, schema: TimeLyreSchema):
        if self.cols is None or len(self.cols) == 0:
            self.cols = schema.get_column_names()
        self.tag_key = ','.join(schema.get_tag_keys())
        return self

    def with_bucket(self, bucket: BucketInfo):
        self.bucket = bucket
        return self

    def with_cols(self, cols: List[str]):
        if cols is not None and len(cols) > 0:
            self.cols = cols
        return self

    def with_tag_key(self, tag_key):
        self.tag_key = tag_key
        return self

    def with_tag_value_list(self, tag_value_list: list):
        self.tag_value_list = tag_value_list
        return self

    def with_time_filter(self, time_filter: list):
        self.time_filter = time_filter
        return self

    def with_chunk_size(self, chunk_size: int):
        self.chunk_size = chunk_size
        return self

    def with_vec_read(self, vec_read: bool):
        self.vec_read = vec_read
        return self

    def with_arrow_transfer(self, arrow_transfer: bool):
        self.arrow_transfer = arrow_transfer
        return self

    def with_compress(self, compress: str):
        self.compress = compress
        return self
