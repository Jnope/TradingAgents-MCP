import io
import time


def handle_decompress(input_bytes, compress):
    if compress == "snappy":
        import snappy
        output_bytes = snappy.uncompress(input_bytes)
    elif compress == "gzip":
        import gzip
        with gzip.GzipFile(fileobj=io.BytesIO(input_bytes), mode='rb') as f:
            output_bytes = f.read()
    elif compress == "zstd":
        import zstd
        output_bytes = zstd.decompress(input_bytes)
    elif compress == "lz4":
        import lz4.frame
        output_bytes = lz4.frame.decompress(input_bytes)
    elif compress == "zip":
        import zlib
        output_bytes = zlib.decompress(input_bytes)
    else:
        output_bytes = input_bytes

    return output_bytes
