import datetime
import io
import os
import random
import sys
from pathlib import Path

import pandas as pd
import pytz
import requests


class QuarkTempDirMgr:
    def __init__(self, host_port: str, token: str = None):
        self.host_port = host_port
        self.guardian_token = None
        if token is not None:
            self.guardian_token = f"&guardian_access_token={token}"
        else:
            self.guardian_token = ""

    def prepareNewTempDir(self) -> tuple:
        url = f"http://{self.host_port}/api/tmpdirs?optype=require&tmptype=timelyre{self.guardian_token}"
        resp = requests.get(url)
        try:
            js = resp.json()
        except Exception as e:
            raise RuntimeError(f"resp: {resp.text}, error: {e}")
        dirId = js["id"]
        dirPath = js["dir"]
        return dirId, dirPath

    def releaseTempDir(self, id):
        url = f"http://{self.host_port}/api/tmpdirs?optype=release&id={id}{self.guardian_token}"
        resp = requests.get(url)
        return

    def getFileInTempDir(self, id, fn: str):
        url = f"http://{self.host_port}/api/getfile?optype=get&dirid={id}&filename={fn}{self.guardian_token}"
        resp = requests.get(url)
        return len(resp.content)

    def makeGetFileInTempDir(self, id, fn: str):
        return f"http://{self.host_port}/api/getfile?optype=get&dirid={id}&filename={fn}{self.guardian_token}"

    def listFilesInTempDir(self, id) -> list:
        url = f"http://{self.host_port}/api/getfile?optype=list&dirid={id}{self.guardian_token}"
        resp = requests.get(url)
        try:
            js = resp.json()
        except Exception as e:
            raise RuntimeError(f"resp: {resp.text}, error: {e}")
        retFiles = js.get("files")
        if retFiles is None:
            return []
        else:
            return retFiles

    def putFileInTempDir(self, id, fn: str):
        p = Path(fn)
        if not p.is_file():
            raise RuntimeError(f"{fn} is not a file")
        file_name = p.name
        url = f"http://{self.host_port}/api/getfile?optype=put&dirid={id}&filename={file_name}{self.guardian_token}"
        with open(fn, 'rb') as fobj:
            files = {"file_obj": fobj}
            requests.post(url, files=files)

    '''传入一段bytes，而不是一个文件名
    '''
    def putFileBytesInTempDir(self, id, file_name: str, file_bytes: bytes):
        # 创建一个 BytesIO 对象来处理内存中的字节数据
        file_obj = io.BytesIO(file_bytes)
        url = f"http://{self.host_port}/api/getfile?optype=put&dirid={id}&filename={file_name}{self.guardian_token}"
        files = {"file_obj": file_obj}
        return requests.post(url, files=files)

    def makePutFileInTempDir(self, id, fn: str):
        return f"http://{self.host_port}/api/getfile?optype=put&dirid={id}&filename={fn}{self.guardian_token}"


def __create_non_empty_file(dir, fn):
    f = open(dir + "/" + fn, "wb")
    f.fileno()
    r = random.Random()
    if sys.version_info >= (3, 9):
        randData = r.randbytes(r.randint(a=10, b=1000))
    else:
        randData = bytearray(random.getrandbits(8) for _ in range(r.randint(a=10, b=1000)))
    f.write(randData)
    f.close()
    return len(randData)


def normalize_df(df: pd.DataFrame, schema: list, convert_decimal_to_float64: bool):
    """归一化dataframe，只有upload_df会使用这个函数，因为要处理时区信息"""

    if len(df) == 0:
        return
    df.columns = list(list(zip(*schema))[0])
    now = datetime.datetime.now()
    local_time_zone = now.astimezone().tzinfo
    utc_now = now.astimezone(pytz.utc)

    # 计算当前时区与UTC时区的差值
    time_difference = local_time_zone.utcoffset(now) - pytz.utc.utcoffset(utc_now)
    for x in schema:
        if x[1] == "string":
            df[x[0]] = df[x[0]].astype(dtype="string")
        elif x[1] == "float":
            df[x[0]] = df[x[0]].astype(dtype="float32")
        elif x[1] == "double":
            df[x[0]] = df[x[0]].astype(dtype="float64")
        elif x[1].startswith("decimal"):
            if convert_decimal_to_float64:
                df[x[0]] = df[x[0]].astype(dtype="float64")
        elif x[1] == "int":
            df[x[0]] = df[x[0]].astype(dtype="Int32")
        elif x[1] == "long" or x[1] == "bigint":
            df[x[0]] = df[x[0]].astype(dtype="Int64")
        elif x[1] == "smallint":
            df[x[0]] = df[x[0]].astype(dtype="Int16")
        elif x[1] == "tinyint":
            df[x[0]] = df[x[0]].astype(dtype="Int8")
        elif x[1] == "timestamp":
            # 如果时间戳不带时区，那么就认为是本地时区的时间
            if not hasattr(df[x[0]], 'dt'):
                df[x[0]] = df[x[0]].astype(dtype="datetime64[ns]")
                df[x[0]] = df[x[0]].dt.tz_localize(local_time_zone)
            elif df[x[0]].dt.tz is None:
                df[x[0]] = df[x[0]].dt.tz_localize(local_time_zone)
            df[x[0]] = df[x[0]].dt.tz_convert(datetime.timezone.utc)
            df[x[0]] = df[x[0]] + time_difference
        elif x[1] == "date":
            pass
        elif x[1] == "bool" or x[1] == "boolean":
            # 注意不能是bool，因为会把非True、False的string值和None值转成bool值
            df[x[0]] = df[x[0]].astype('boolean')
        elif x[1].startswith('char') or x[1].startswith('varchar'):
            df[x[0]] = df[x[0]].astype(dtype="string")
        else:
            raise ValueError(f"cannot determine type {x[1]}")


if __name__ == "__main__":
    x = QuarkTempDirMgr("localhost:4340")
    (id, dir) = x.prepareNewTempDir()
    print(f"got {id} {dir}")

    #print(__create_non_empty_file(dir, "aa"))
    #print(__create_non_empty_file(dir, "bb"))

    b = b"your file bytes here"
    n = "example.txt"

    files = x.putFileBytesInTempDir(id, n, b)

    files = x.listFilesInTempDir(id)
    print(files)
    for i in files:
        print(x.getFileInTempDir(id, i))

    #x.releaseTempDir(id)

    pos = dir.rfind("/")
    pdir = dir[:pos]
    dirname = dir[pos + 1:]
    print(dirname in os.listdir(pdir))
