import asyncio
import json
import time
from typing import Dict, Any, List, Tuple

import requests
from aiohttp import ClientSession
from concurrent.futures import ThreadPoolExecutor
from itertools import repeat

from transwarp.timelyre.timelyre_logger import getLogger
from .read_par import *
from .quark_utils import QuarkTempDirMgr

async def http_get_with_aiohttp(session: ClientSession, url: str, headers: Dict = {}, proxy: str = None, timeout: int = 10) -> (int, Dict[str, Any], bytes):
    response = await session.get(url=url, headers=headers, proxy=proxy, timeout=timeout)

    response_json = None
    try:
        response_json = await response.json(content_type=None)
    except json.decoder.JSONDecodeError as e:
        pass

    response_content = None
    try:
        response_content = await response.read()
    except:
        pass

    return (response.status, response_json, response_content)

async def http_get_file_with_aiohttp(session: ClientSession, url: str, headers: Dict = {}, proxy: str = None, timeout: int = 10) -> (int, Dict[str, Any], bytes):
    response = await session.get(url=url, headers=headers, proxy=proxy, timeout=timeout)

    response_content = None
    try:
        response_content = await response.read()
    except:
        pass

    return (response.status, None, response_content)

def http_get_with_requests(url: str, headers: Dict = {}, proxies: Dict = {}, timeout: int = 10) -> (str, int, bytes):
    response = requests.get(url, headers=headers, proxies=proxies, timeout=timeout)

    response_content = None
    try:
        response_content = response.content
    except:
        pass
    return url, response.status_code, response_content

def http_get_file_with_requests(url: str, operation: str, headers: Dict = {}, proxies: Dict = {}, timeout: int = 10000):
    response = requests.get(url, headers=headers, proxies=proxies, timeout=timeout)
    response_data = None
    try:
        if response.status_code == 200:
            if operation == "list":
                response_data = response.content.decode("utf-8").split(",")
            elif operation == "get":
                x = io.BytesIO(response.content)
                response_data = pd.read_parquet(x)
            elif operation == "delete":
                pass
            else:
                pass
    except:
        pass

    return response_data

def http_list_file_with_request(url: str, headers: Dict = {}, proxies: Dict = {}, timeout: int = 10000):
    response = requests.get(url, headers=headers, proxies=proxies, timeout=timeout)
    response_data = None
    try:
        if response.status_code == 200:
            response_data = response.content.decode("utf-8").split(",")
    except:
        pass

    return response.status_code, response_data

def http_get_file_with_request(url: str, host: str, tbl: str, file: str, headers: Dict = {}, proxies: Dict = {}, timeout: int = 1000):
    response = requests.get(url, headers=headers, proxies=proxies, timeout=timeout)
    response_data = None
    try:
        if response.status_code == 200:
            x = io.BytesIO(response.content)
            response_data = pd.read_parquet(x)
            # print(f"{host} {tbl} {file}")
            # print(response_data)
    except:
        pass

    return response.status_code, response_data, f"{host}_{tbl}_{file}"

def http_delete_file_with_request(url: str, headers: Dict = {}, proxies: Dict = {}, timeout: int = 10000):
    response = requests.get(url, headers=headers, proxies=proxies, timeout=timeout)
    return response.content
async def http_get_with_aiohttp_parallel(session: ClientSession, list_of_urls: List[str], headers: Dict = {}, proxy: str = None, timeout: int = 10) -> (List[Tuple[int, Dict[str, Any], bytes]], float):
    t1 = time.time()
    results = await asyncio.gather(*[http_get_file_with_aiohttp(session, url, headers, proxy, timeout) for url in list_of_urls])
    t2 = time.time()
    t = t2 - t1
    return results, t

def http_get_with_requests_parallel(list_of_urls: List[str], headers: Dict = {}, proxies: Dict = {}, timeout: int = 30):
    t1 = time.time()
    results = {}
    executor = ThreadPoolExecutor(max_workers=30)
    for result in executor.map(http_get_with_requests, list_of_urls, repeat(headers), repeat(proxies), repeat(timeout)):
        tmp_res = []
        tmp_res.append(result[1])
        tmp_res.append(result[2])
        results[result[0]] = tmp_res
    t2 = time.time()
    t = t2 - t1
    return results, t

def sync_read_quark_remote_files(host_port: str, token: str, remote_dir_id, combine_ignore_index, local_dir: str = None):
    # URL list
    t1 = time.perf_counter()

    mgr = QuarkTempDirMgr(host_port, token)
    fileArr = mgr.listFilesInTempDir(remote_dir_id)
    fileArr = [f for f in fileArr if f[-4:] != ".crc"]
    urls = [mgr.makeGetFileInTempDir(remote_dir_id, f) for f in fileArr]
    t2 = time.perf_counter()

    results, t = http_get_with_requests_parallel(urls)

    t3 = time.perf_counter()

    read_to_local_dir = local_dir is not None
    urls.sort()
    data_array: list[bytes] = []
    for i in range(len(urls)):
        x = results[urls[i]]
        if x[0] == 200:
            if len(x[1]) == 0:
                raise RuntimeError(f"url: {urls[i]} get file size is 0...")
            if read_to_local_dir:
                fileName = local_dir + "/" + str(i) + ".par"
                with open(fileName, 'wb') as file:
                    file.write(x[1])
            else:
                data_array.append(x[1])
        else:
            raise ValueError(f"Error get data from split {i}, code {x[0]}")

    if read_to_local_dir:
        t4 = time.perf_counter()
        getLogger().info(f"write query result to local dir: {local_dir}, file num: {len(fileArr)}")
        getLogger().info(f"quark file read time stat: get files info {t2 - t1} parallel get files {t3 - t2} write local parquet file {t4 - t3}, file num: {len(fileArr)}")
        return None
    if len(data_array) > 0:
        df = read_parquet_bytes(data_array, combine_ignore_index)
    else:
        df = pd.DataFrame()
    t4 = time.perf_counter()
    getLogger().info(f"quark file read time stat: get files info {t2 - t1} parallel get files {t3 - t2} read parquet {t4 - t3}, file num: {len(fileArr)}")
    return df

async def async_read_quark_remote_files(host_port: str, token: str, remote_dir_id, combine_ignore_index, local_dir: str = None):
    # URL list
    t1 = time.perf_counter()

    mgr = QuarkTempDirMgr(host_port, token)
    fileArr = mgr.listFilesInTempDir(remote_dir_id)
    urls = [mgr.makeGetFileInTempDir(remote_dir_id, f) for f in fileArr]

    t2 = time.perf_counter()
    # Benchmark aiohttp
    session = ClientSession()
    speeds_aiohttp = []
    for i in range(0, 1):
        results, t = await http_get_with_aiohttp_parallel(session, urls)
        v = len(urls) / t
        speeds_aiohttp.append(v)
    await session.close()
    t3 = time.perf_counter()

    read_to_local_dir = local_dir is not None

    data_array: list[bytes] = []
    for i, x in enumerate(results):
        if x[0] == 200:
            if read_to_local_dir:
                fileName = local_dir + "/" + str(i) + ".par"
                with open(fileName, 'wb') as file:
                    file.write(x[2])
            else:
                data_array.append(x[2])
        else:
            raise ValueError(f"Error get data from split {i}, code {x[0]}")

    if read_to_local_dir:
        return None

    df = read_parquet_bytes(data_array, combine_ignore_index)
    t4 = time.perf_counter()
    getLogger().info(f"quark file read time stat: get files info {t2 - t1} parallel get files {t3 - t2} read parquet {t4 - t3}, file num: {len(fileArr)}")
    return df


async def async_read_quark_remote_files(host_port: str, token, str, remote_dir_id, combine_ignore_index, local_dir: str = None):
    # URL list
    t1 = time.perf_counter()

    mgr = QuarkTempDirMgr(host_port, token)
    fileArr = mgr.listFilesInTempDir(remote_dir_id)
    urls = [mgr.makeGetFileInTempDir(remote_dir_id, f) for f in fileArr]

    t2 = time.perf_counter()
    # Benchmark aiohttp
    session = ClientSession()
    speeds_aiohttp = []
    for i in range(0, 1):
        results, t = await http_get_with_aiohttp_parallel(session, urls)
        v = len(urls) / t
        speeds_aiohttp.append(v)
    await session.close()
    t3 = time.perf_counter()

    read_to_local_dir = local_dir is not None

    data_array: list[bytes] = []
    for i, x in enumerate(results):
        if x[0] == 200:
            if read_to_local_dir:
                fileName = local_dir + "/" + str(i) + ".par"
                with open(fileName, 'wb') as file:
                    file.write(x[2])
            else:
                data_array.append(x[2])
        else:
            raise ValueError(f"Error get data from split {i}, code {x[0]}")

    if read_to_local_dir:
        return None

    df = read_parquet_bytes(data_array, combine_ignore_index)
    t4 = time.perf_counter()
    getLogger().info(f"quark file read time stat: get files info {t2 - t1} parallel get files {t3 - t2} read parquet {t4 - t3}, file num: {len(fileArr)}")
    return df

def get_remote_dataframe(host_port: str, token: str, remote_dir: str, combine_ignore_index: bool, local_dir: str = None):
    return sync_read_quark_remote_files(host_port, token, remote_dir, combine_ignore_index, local_dir)
    # if asyncio.get_event_loop() is not None and asyncio.get_event_loop().is_running():
    #     return sync_read_quark_remote_files(host_port, remote_dir, combine_ignore_index, local_dir)
    # else:
    #     return asyncio.run(async_read_quark_remote_files(host_port, remote_dir, combine_ignore_index, local_dir))


def get_remote_dataframe_from_storage(bucketUrl:list,queryid: str, combine_ignore_index: bool, local_dir: str = None):
    return sync_read_storage_remote_files(bucketUrl, queryid, combine_ignore_index, local_dir)

def sync_read_storage_remote_files(bucket_urls:list, queryid: str, combine_ignore_index: bool = True, local_dir: str = None):
    t1 = time.time()
    list_results = []
    list_urls = [f"{line}&query_id={queryid}&operation=list" for line in bucket_urls]
    executor = ThreadPoolExecutor(max_workers=30)
    for result in executor.map(http_list_file_with_request, list_urls):
        if result[0] == 200:
            list_results.append(result[1])

    t2 = time.time()

    file_urls = []
    hosts = []
    tbls = []
    files = []
    for result in list_results:
        if result[1].__len__() > 2:
            url = result[0]
            tablename = result[1]
            for i in range(2, result.__len__()):
                file_urls.append(f"http://{url}/api/timelyre/tables/getpqfile?bucketname={tablename}&query_id={queryid}&operation=get&file={result[i]}")
                files.append(result[i])
                hosts.append(url)
                tbls.append(tablename)

    file_results = {}
    file_infos = []
    for result in executor.map(http_get_file_with_request, file_urls, hosts, tbls, files):
        if result[0] == 200:
            file_infos.append(result[2])
            file_results[result[2]] = result[1]
    file_infos.sort()
    file_list = []
    for info in file_infos:
        file_list.append(file_results.get(info))
    t3 = time.time()
    df = pd.concat(file_list, ignore_index=combine_ignore_index)
    t4 = time.time()
    getLogger().info(f"quark file read time stat: list files info {t2 - t1} parallel get files {t3 - t2} concat {t4 -t3}")

    delete_urls = [f"{line}&query_id={queryid}&operation=delete" for line in bucket_urls]

    for result in executor.map(http_delete_file_with_request, delete_urls):
        pass

    return df


def put_remote_dataframe(host_port: str, token: str, remote_dir: str, files: list, max_worker_num: int = 30):
    return sync_put_quark_remote_files(host_port, token, remote_dir, files, max_worker_num)


def sync_put_quark_remote_files(host_port: str, token: str, remote_dir_id: str, files: list, max_worker_num: int = 30):
    t1 = time.perf_counter()
    mgr = QuarkTempDirMgr(host_port, token)
    results = []
    executor = ThreadPoolExecutor(max_workers=max_worker_num)
    for result in executor.map(mgr.putFileInTempDir, repeat(remote_dir_id), files):
        results.append(result)
    t2 = time.time()
    t = t2 - t1
    return results, t