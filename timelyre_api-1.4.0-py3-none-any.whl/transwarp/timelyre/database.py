import warnings

import base64
import itertools
import json
import os
import sys
import uuid
import datetime
from json import JSONDecodeError
from .base_db_class import BaseDBClass
from .direct_query_util import DirectQueryUtil
from .meta.quark_schema import QuarkSchema
from .quark.fast_meta_manager import QuarkFastMetaMgr
from .transport.read_request_builder import ReadRequestBuilder
from .transport.timelyre_client import TimeLyreClient
from .transport.timelyre_transport import TimeLyreTransporter
from .utils import parquet_utils
from .utils.df_utils import df_localize_time
from .util import get_tbl_name_from_sql, get_ip_address, get_file_by_pid, split_list, \
    generate_asof_join_str, generate_window_join_str, is_get_conf_command, refineHdfsLoc
from typing import Union, List, Optional
from enum import Enum

import pandas as pd
import numpy as np
import requests
from concurrent.futures import ThreadPoolExecutor
import zlib

from .constants import CruxMode, QuarkMode, DataType, type_value_to_type_int, TagType, TimestampType, CastTSType, \
    CastMinuteType, CastDateType
from .quark.http_download import get_remote_dataframe, put_remote_dataframe, get_remote_dataframe_from_storage
from .quark.quark_utils import QuarkTempDirMgr, normalize_df
from .query_cache_control import *


def db_cacheable(func):
    """
    对于一个database里开销较大，每次开销在参数不变的情况下结果不变的调用可以缓存住
    """

    def wrapper(*args, **kwargs):
        db: Database = args[0]
        use_cacheable = kwargs.pop('use_cacheable', False)
        if use_cacheable is True:
            fname = func.__name__
            k = (fname, db.db(), args[1:])
            if k in db._some_cache:
                res = db._some_cache[k]
            else:
                res = func(*args, **kwargs)
                db._some_cache[k] = res
        else:
            res = func(*args, **kwargs)
        return res

    return wrapper


def with_database(func):
    from functools import wraps

    @wraps(func)
    def wrapper(self, *args, **kwargs):
        original_db = self.db()
        # 提取database参数
        db = kwargs.get('database', None)
        self.internal_set_quark_mode()
        if db:
            # 切换到新db
            self._switch_database(db)
        else:
            self._switch_database(original_db)
        return func(self, *args, **kwargs)

    return wrapper


def post_process_result_df(func):
    """
    装饰器，装饰的函数：返回值是dataframe，且对dataframe进行统一处理
    """

    def wrapper(*args, **kwargs):
        try:
            df: pd.DataFrame = func(*args, **kwargs)
            table = kwargs.get('tbl', None)  # query_as_df
            db = kwargs.get('database', None)
            if table is None:  table = kwargs.get('table_name', None)  # direct_query_as_df
            if table is not None:
                args[0]._process_result_df(df, db, table)
            # print(f'===> in post_process_result_df, df:\n{df}')
            return df
        except Exception as e:
            raise e
        finally:
            if hasattr(args[0], 'close_connection') and hasattr(args[0], 'auto_close'):
                if args[0].auto_close:
                    args[0].close_connection()

    return wrapper


def is_null(value):
    pdna = pd.isna(value)
    if pdna:
        return pdna
    if isinstance(value, str):
        if value == "":
            return True
        else:
            lowerval = value.lower()
            if lowerval == "" or lowerval == "na" or lowerval == "none" or lowerval == "nan" or lowerval == "null":
                return True
            else:
                return False
    else:
        return False


class Database(metaclass=BaseDBClass):
    @staticmethod
    def newSessionId() -> str:
        return str(uuid.uuid4()) + "_" + str(os.getpid())

    @staticmethod
    def newSymbolId() -> str:
        return str(uuid.uuid1()).replace('-', '_')

    # 第三列存comment
    @staticmethod
    def get_comment_str(x: list):
        if len(x) <= 2 or x[2] == "":
            return ""
        return f"COMMENT '{x[2]}'"

    # 第四列存额外的信息，比如NOT NULL之类的约束
    @staticmethod
    def get_extra_info(x: list):
        if len(x) <= 3 or x[3] == "":
            return ""
        return x[3]

    @staticmethod
    def __check_value_lower(tbl: str):
        if tbl.islower() or not tbl.isascii():
            return False
        else:
            return True

    @staticmethod
    def __do_parallel_multiple_inserts(conn, values, db, tbl, segs, run_mode):
        for xx in segs:
            (st, nd) = xx
            if isinstance(values, list):
                l = values[st: nd + 1]  # list：左闭右开
            elif isinstance(values, pd.DataFrame):
                l = values.loc[st: nd].values.tolist()  # pd.loc：左闭右闭
            t1 = time.time()
            if run_mode is QuarkMode:
                conn.__insert2(db, tbl, l)
            else:
                conn.__insert(db, tbl, l)
            t2 = time.time()
            # print(f"single insert cost {t2 - t1} s", flush=True)
        conn.close_session(False)
        return True

    db_reuse_conn = True

    def __init__(self,
                 jdbc_http_proxy: str,
                 real_conn: str,
                 db: str,
                 auth_type: str,
                 run_mode: str,
                 compressCommand: bool = False,
                 kafka_servers: str = "",
                 kafka_zk_address: str = "",
                 run_tdc: bool = False,
                 tdc_quark_ui_port: str = None,
                 session_timeout: int = 5 * 60 * 1000,
                 login_timeout: int = 5 * 60 * 1000,
                 session_name: str = None,
                 auto_close: bool = True,
                 disable_cancel: bool = False,
                 real_ui_host_port: str = None,
                 real_leopard_url: str = None,
                 **kwargs):

        # 配合do_cacheable使用
        self._some_cache = {}
        self.__internal_execute_command_count = 0
        self.__auto_close = auto_close
        self.__basic_info = None
        self.__session_name = session_name
        self.__session_timeout = session_timeout
        self.__login_timeout = login_timeout
        self.__lastSessionId = Database.newSessionId()
        # print(f'New database with id {self.__lastSessionId}')
        self.__jdbc_http = jdbc_http_proxy
        self.__conn = real_conn
        if db.islower() or not db.isascii():
            self.__db = db
        else:
            raise ValueError(f"db only support lowercase string, but {db}")
        self.__run_mode = run_mode
        self.__auth_type = auth_type
        (self.__auth_info, self.__token, self.__username) = self.__get_auth_info(kwargs)
        tmp = real_conn.rsplit(":", 2)
        self.__server_ip = tmp[1][2:]
        self.__server_port = tmp[-1]
        self.__use_http_transfer_data = True
        self.__compress = compressCommand
        self.__core_url = None  # 与连接管理相关的核心url，不允许带空格
        self.__run_tdc = run_tdc
        self.__tdc_quark_ui_port = tdc_quark_ui_port
        self.__real_ui_host_port = real_ui_host_port
        self.direct_query_enabled = False
        if real_ui_host_port is not None:
            self.__fast_meta_mgr = QuarkFastMetaMgr(real_ui_host_port, self.__token)
            # 检测一下是否支持fast_meta
            if self.check_direct_query_enabled():
                self.direct_query_enabled = True
            else:
                self.__fast_meta_mgr = None
        else:
            self.__fast_meta_mgr = None
        self.__tmp_mgr = QuarkTempDirMgr(self.__rest_host_port, self.__token)
        if real_ui_host_port is None:
            if run_mode == QuarkMode:
                self.internal_set_quark_mode()
            elif run_mode == CruxMode:
                self.internal_set_crux_mode()
            else:
                raise ConnectionError(f"unkonwn run mode {run_mode}")
        self.__kafka_servers = kafka_servers
        self.__kafka_zk_address = kafka_zk_address
        self.__default_cache_db = "timelyre_cache"
        self.__shiva_web_addr = self.__get_shiva_web_addr()
        self.__shiva_master_addr = self.__get_shiva_master_addr()
        self.__timelyre_client = TimeLyreClient(self.__shiva_web_addr)
        self.__leopard_master_addr = self.__get_leopard_master_addr()
        self.__leopard_connector_addr = self.__get_leopard_connector_addr(real_leopard_url)
        os.environ.setdefault("SPARK_REMOTE", f'sc://{self.__leopard_connector_addr}')
        self.__leopard_session = None
        self.__kwargs = kwargs
        if not disable_cancel:
            self.register_sig_handler()

        self.__convert_decimal_to_float64 = False
        self.__process_result_null_dtype = False

    def _switch_database(self, database):
        self.run_simple_command(f"use {database}")

    def set_convert_decimal_to_float64(self, flag: bool):
        self.__convert_decimal_to_float64 = flag

    def set_process_result_null_dtype(self, flag: bool):
        self.__process_result_null_dtype = flag

    def get_convert_decimal_to_float64(self):
        return self.__convert_decimal_to_float64

    def get_process_result_null_dtype(self):
        return self.__process_result_null_dtype

    def get_leopard_session(self):
        return self.__leopard_session

    def register_sig_handler(self):
        try:
            import signal
            if sys.platform == "win32":
                # WARP-107978: windows操作系统中只有这两个信号
                signals = [signal.SIGINT, signal.SIGBREAK]
            else:
                signals = [signal.SIGINT, signal.SIGTERM, signal.SIGTSTP]
            for sig in signals:
                signal.signal(sig, self.sig_int_handler)
        except Exception:
            warnings.warn("disable auto cancel because signal only works in main thread of the main interpreter")

    def sig_int_handler(self, signal, frame):
        getLogger().info(f"catch sig {signal}, frame: {frame}, url: {self.__core_url}")
        self.__close_session(False, force_close=True)
        if self.__leopard_session is not None:
            print(f"catch signal {signal}, do leopard resource cleaning")
            self.__leopard_session.stop()
        getLogger().info(f"finish cleaning session")

    @property
    def __rest_host_port(self):
        if self.__real_ui_host_port is not None:
            return self.__real_ui_host_port
        # 重新获取真实的rest host，gateway可能重新连接新server
        if self.__run_tdc and self.__tdc_quark_ui_port is not None:
            # TODO: TDC支持gateway
            real_host = self.__server_ip
            __rest_port = int(self.__tdc_quark_ui_port)
        else:
            # 重新获取真实的rest port，gateway可能重新连接新server
            real_host = self.__get_restapi_host()
            __rest_port = self.__get_restapi_port()
        return f"{real_host}:{__rest_port}"

    def get_rest_host_port(self):
        return self.__rest_host_port

    def get_current_session_id(self):
        return self.__lastSessionId

    def get_current_session_name(self):
        return self.__session_name

    def __get_basic_info(self):
        """
        获取当前进程的基础信息。包含：session使用的username，当前ip，进程id，是否开启auto_close，运行的python脚本的绝对路径
        :return: __basic_info
        """
        if self.__basic_info is not None:
            return self.__basic_info
        infos = [f"[USER]:{self.__username}"]
        ip = get_ip_address()
        pid = os.getpid()
        if ip is not None:
            infos.append(f"[IP]:{ip}")
        infos.append(f"[PID]:{pid}")
        infos.append(f"[AC]:{self.__auto_close}")
        file = get_file_by_pid(pid)
        if file is not None:
            infos.append(f"[FILE]:{file}")

        self.__basic_info = f"{','.join(infos)}"
        return self.__basic_info

    def set_session_name(self, sn: str, basic: bool = False):
        """
        设置当前session的session name
        :param sn: session名称
        :return:
        """
        old_name = self.__session_name
        if basic:
            self.__session_name = f"{sn},{self.__get_basic_info()}"
        else:
            self.__session_name = sn

        try:
            self.run_set_command(f"set ngmr.session.name={self.__session_name}")
            getLogger().info(f"set sn success. new: {self.__session_name}, old: {old_name}")

        except Exception as e:
            msg = f"faile to set sn. new: {self.__session_name}, old: {old_name}, error: {e}"
            getLogger().error(msg)
            raise RuntimeError(msg)

    def __get_restapi_port(self):
        if self.__real_ui_host_port is not None:
            return self.__real_ui_host_port.split(":")[1]
        ret = self.run_simple_command("config global port ui")
        return int(ret[0][0])

    # 当使用gateway时，用户设置的jdbc的host并不是restapi的host，需要重新获取
    def __get_restapi_host(self):
        if self.__real_ui_host_port is not None:
            return self.__real_ui_host_port.split(":")[0]
        ret = self.run_simple_command("set transwarp.docker.inceptor")
        host_port = str(ret[0][0])
        host = host_port.split("=")[1].split(":")[0]
        return host

    def __get_shiva_web_addr(self):
        try:
            ret = self.run_simple_command("set shiva.web.url")
            http_addr = str(ret[0][0]).split("=")[1]
            clean_url = http_addr.replace("http://", "")
        except Exception:
            clean_url = ""
        return clean_url

    def __get_shiva_master_addr(self):
        try:
            ret = self.run_simple_command("set timelyre.shiva.master.group")
            addr = str(ret[0][0]).split("=")[1]
        except Exception:
            addr = ""
        return addr

    def __get_leopard_master_addr(self):
        try:
            ret = self.run_simple_command("set leopard.master.url")
            url = str(ret[0][0]).split("=")[1]
        except Exception:
            url = ""
        return url

    def __get_leopard_connector_addr(self, real_leopard_url=None):
        if real_leopard_url is not None and real_leopard_url != "":
            return real_leopard_url
        if os.getenv("LOCAL_CONNECTOR_URL", "") != "":
            return os.getenv("LOCAL_CONNECTOR_URL")
        try:
            ret = self.run_simple_command("set leopard.connector.url")
            url = str(ret[0][0]).split("=")[1]
        except Exception:
            url = ""
        return url

    def __get_auth_info(self, kwargs) -> (str, str):
        username = "anonymous"
        if self.__auth_type == "simple":
            return "", None, username
        elif self.__auth_type == "ldap":
            username = None
            password = None
            token = None
            if "username" in kwargs.keys():
                username = kwargs['username']
            if "password" in kwargs.keys():
                password = kwargs['password']
            if "token" in kwargs.keys():
                token = kwargs['token']
            if username is None or password is None or token is None:
                raise ConnectionError("username,password,token can not be null when using ldap auth")
            else:
                return f" -n{username} -p{password} ", token, username
        elif self.__auth_type == "kerberos":
            raise ConnectionError("kerberos auth type not support yet")
        elif self.__auth_type == "guardian":
            # raise ConnectionError("guardian auth type not support yet")
            token = kwargs['token']
            if token is None:
                raise ConnectionError("token can not be null when using guardian auth")
            else:
                return f";guardianToken={token};", token, username
        else:
            raise ConnectionError(f"unkonwn auth type {self.__auth_type}")

    def internal_set_crux_mode(self):
        self.__internal_execute_command("set query.lang=crux.sql")
        self.__internal_execute_command("set timelyre.sql.enabled=true")
        self.__run_mode = CruxMode

    def internal_set_quark_mode(self):
        self.__internal_execute_command("set query.lang=sql")
        self.__internal_execute_command("set timelyre.sql.enabled=false")
        self.__run_mode = QuarkMode

    def __set_mode(self, mode: str):
        if mode == CruxMode:
            self.internal_set_crux_mode()
        if mode == QuarkMode:
            self.internal_set_quark_mode()

    def get_run_mode(self):
        return self.__run_mode

    def run_set_command(self, cmd: str):
        self.__internal_execute_command(cmd)

    def getLocation(self, tblName):
        desc_data = self.__quark_query_raw(f'desc formatted {tblName}')
        hdfsloc = None
        for row in desc_data:
            if row[0].startswith('Location:'):
                hdfsloc = row[1]
        assert hdfsloc is not None, f"Cannot find location for table {tblName}"
        return hdfsloc

    def get_internal_execute_command_count(self):
        return self.__internal_execute_command_count

    def __internal_execute_command(self, cmd: str, reuse_conn: bool = True):
        self.__internal_execute_command_count += 1
        this_reuse_conn = self.db_reuse_conn and reuse_conn
        if this_reuse_conn:
            sid = self.__lastSessionId
        else:
            sid = Database.newSessionId()

        if self.__compress:
            execute_api = "/restsql/execute_compress"
            cmd_bytes = bytes(cmd, 'utf8')
            cmd = zlib.compress(cmd_bytes)
            cmd = str(base64.encodebytes(cmd), 'utf8')
        else:
            execute_api = "/restsql/execute"

        if self.__core_url is None:
            # 首次建立连接
            if self.__session_name is None:
                self.__session_name = self.__get_basic_info()
            self.__core_url = f"{self.__conn.split('//')[1]}/{self.__db}"  # rest ip:port/db
            # 添加安全相关参数
            if self.__auth_type != "ldap":  # ldap连接方式无需往核心url添加信息
                self.__core_url = f"{self.__core_url}{self.__auth_info}"
            # 添加login超时时间设置
            self.__core_url = f"{self.__core_url};loginTimeout={self.__login_timeout}"
            # 添加hive参数
            # 实际效果eg：会执行一条set命令，如 set hive.server2.idle.session.timeout=xxxx;
            hiveSets = [
                f"ngmr.session.name={self.__session_name}",  # 先设置session name
                f"hive.server2.idle.session.timeout={self.__session_timeout}",
            ]

            self.__core_url = f"{self.__core_url};?{';'.join(hiveSets)}"
            getLogger().info(f"Try to build a new session, ac: {self.__auto_close}, "
                             f"sid: {self.__lastSessionId}, sn: {self.__session_name}")

        connection = f"jdbc:hive2://{self.__core_url}"
        if self.__auth_type == "ldap":
            connection = f"{connection} {self.__auth_info}"  # 添加空格分割的参数，不计入核心url
        if self.__auth_type == "guardian":
            auth_type = "guardianToken"
        else:
            auth_type = self.__auth_type
        body = {
            "sid": sid,
            "connection": connection,
            "authenType": auth_type,
            "sql": cmd,
        }
        # print(f"===> connection: {connection}")
        res = requests.post(url="http://" + self.__jdbc_http + execute_api, json=body, timeout=90000.0)
        # http对方返回的数据可能不是utf-8(当前rest-jdbc的确不是)

        # 反解码回bytes
        bb = res.text.encode(res.encoding)
        # 重新编码成utf-8的字符串
        ss = bb.decode("utf-8")
        try:
            data = json.loads(ss)
            if data["ReturnType"] == "Error":
                raise ConnectionError(data["ErrorMsg"])
            return data
        except JSONDecodeError as e:
            raise RuntimeError(f"failed to decode json, error: {e}, raw_string: {ss}")
        except Exception as e:
            raise e

    def __internal_fetch_result(self, execute_data) -> (bool, object):
        if execute_data["ReturnType"] == "UpdateCount":
            return False, list(), 0
        fetchBody = {
            "sid": execute_data["FromSession"],
            "cid": execute_data["ToServer"],
            "handle": execute_data["ResultSetHandle"],
            "isLastFetch": "false",
            "limit": "10000",
        }

        res = requests.post(url="http://" + self.__jdbc_http + "/restsql/fetchResult", json=fetchBody, timeout=90000.0)
        t1 = time.time_ns()
        data = json.loads(res.content)
        t2 = time.time_ns()
        if data["IsFetchSuccess"][0] == "True":
            return bool(data["HasRows"][0].lower() == "true"), data["Rows"], t2 - t1
        else:
            print("Encounter error", data)
            raise ValueError(f"Fetch data error: {data}")

    def __close_session(self, raise_error_if_double_close: bool, force_close=False):
        res = None
        try:
            if self.__core_url is None:
                if raise_error_if_double_close:
                    raise RuntimeError("close session failed due to session not established.")
                else:
                    return
            closeBody = {
                "sid": self.__lastSessionId,
                "cid": self.__core_url,
                "force": force_close,
            }
            # print(f"---> cid: {self.__core_url}")
            res = requests.post(url="http://" + self.__jdbc_http + "/restsql/closeSession", json=closeBody)
            data = json.loads(res.content)
            getLogger().info(
                f"Close session success, ac: {self.__auto_close}, sid: {self.__lastSessionId}, sn: {self.__session_name}")
            self.__core_url = None
            if data["ReturnType"] != "Success":
                raise ConnectionError(data["ErrorMsg"])
        except Exception as e:
            if res is not None:
                raise ConnectionError(
                    f"failed to close session: {self.__session_name}, ac: {self.__auto_close}, request result: {res}, error: {e}")
            else:
                raise ConnectionError(
                    f"failed to close session: {self.__session_name}, ac: {self.__auto_close}, error: {e}")

    def close_session(self, raise_error_if_double_close):
        self.__close_session(raise_error_if_double_close)
        self.__lastSessionId = Database.newSessionId()

    def run_simple_command(self, query: str) -> list:
        # 如果是get conf的命令并且开启了fast meta，可以进行优化
        if self.__fast_meta_mgr is not None and is_get_conf_command(query):
            key = query.replace("set", "").strip()
            value = self.__fast_meta_mgr.get_conf(key)
            return [[f"{key}={value}"]]
        data = self.__internal_execute_command(query)
        ret = list()
        (hasNextBatch, thisBatch, t) = self.__internal_fetch_result(data)
        ret.extend(thisBatch)
        while hasNextBatch:
            (hasNextBatch, thisBatch, t) = self.__internal_fetch_result(data)
            ret.extend(thisBatch)
        return ret

    @DeprecationWarning
    def run_register_command(self, query: str):
        self.__set_mode(CruxMode)
        data = self.__internal_execute_command(query)

    def show_session_state(self):
        """
        获取当前session状态：最大可建立session数，当前已建立session数
        :return: eg: [['maxSessionLimit = 500, currentSessionCount = 102']]
        """
        try:
            res = self.run_simple_command("config global session show-session-state")
        except Exception as e:
            raise e
        return res

    def close_inactive_sessions(self, period: int):
        """
        关闭非活跃时间超过 period 的所有sesison
        :param period: 单位：ms
        :return: eg: [['true']]
        """
        if type(period) != int or period < 0:
            raise RuntimeError(f"invalid period: {period}")
        try:
            res = self.run_simple_command(f"config global session close-inactive-session {period}")
        except Exception as e:
            raise e
        return res

    def show_databases(self) -> list:
        """
        :return: 返回当前所有数据库名，类型为list.
        """
        self.__set_mode(QuarkMode)
        data = self.__internal_execute_command("show databases")
        if data["ReturnType"] == "ResultSet":
            ret = []
            (hasNextBatch, thisBatch, _) = self.__internal_fetch_result(data)
            thisBatch = [item[0] for item in thisBatch]
            ret.extend(thisBatch)
            while hasNextBatch:
                (hasNextBatch, thisBatch, _) = self.__internal_fetch_result(data)
                thisBatch = [item[0] for item in thisBatch]
                ret.extend(thisBatch)
            return ret
        elif data["ReturnType"] == "Error":
            raise ConnectionError(data["ErrorMsg"])
        else:
            raise InterruptedError(f"should not happen, data: {data}")

    @with_database
    def show_tables(self, **kwargs) -> list:
        """
        :return: 返回当前数据库的所有表名,类型为list.
        """
        self.__set_mode(QuarkMode)
        data = self.__internal_execute_command("show tables")
        if data["ReturnType"] == "ResultSet":
            ret = []
            (hasNextBatch, thisBatch, _) = self.__internal_fetch_result(data)
            thisBatch = [item[0] for item in thisBatch]
            ret.extend(thisBatch)
            while hasNextBatch:
                (hasNextBatch, thisBatch, _) = self.__internal_fetch_result(data)
                thisBatch = [item[0] for item in thisBatch]
                ret.extend(thisBatch)
            return ret
        elif data["ReturnType"] == "Error":
            raise ConnectionError(data["ErrorMsg"])
        else:
            raise InterruptedError("should not happen")

    @db_cacheable
    @with_database
    def show_columns(self, tblName: str, **kwargs) -> list:
        """
        :param tblName: 查询的表名
        :return: 返回所有列的列名和类型
        """
        if Database.__check_value_lower(tblName):
            raise ValueError(f"table only support lowercase string, but {tblName}")

        # 先获取mapping表
        mapping_tbl_name = self.get_mapping_table(tblName, **kwargs)  # mapping表名：db.tbl的形式
        # 获得真实的dbName和tblName
        if mapping_tbl_name is not None:
            ss = mapping_tbl_name.replace('`', '').split('.', 1)
            dbName, tblName = ss
        else:
            dbName = kwargs.get('database', self.db())
        # 获取columns
        if self.__fast_meta_mgr is not None:
            result = self.__fast_meta_mgr.get_schema(dbName, tblName)
        else:
            data = self.run_simple_command(f"desc {tblName}")
            result = []
            for x in data:
                if x[0].startswith("# Holodesk"):
                    break
                result.append(x[0:2])
        for i in range(len(result)):
            # holodesk表会返回char(10,ORACLE)，varchar(10,ORACLE)这种结果
            if (result[i][1].startswith('char') or result[i][1].startswith('varchar')) and ',ORACLE' in result[i][1]:
                result[i][1] = result[i][1].replace(",ORACLE", "")
        return result

    @db_cacheable
    @with_database
    # 不进行mapping table的检查，caller自己检查mapping table，传入真实的表名
    def show_properties(self, tblName: str, use_meta_cache: bool = False, **kwargs) -> dict:
        if Database.__check_value_lower(tblName):
            raise ValueError(f"table only support lowercase string, but {tblName}")
        def strip(x):
            return x.strip() if x is not None else None
        if self.__fast_meta_mgr is not None:
            ss = tblName.split('.', 1)
            dbName = kwargs.get('database', self.db())
            if len(ss) == 2:
                # 如果caller提供数据库，就使用提供的数据库名
                dbName, tblName = ss
            data = self.__fast_meta_mgr.get_props(dbName, tblName, use_meta_cache)
            filtered_data = [s for s in data if not s.startswith("#") and not len(s.strip()) == 0]
            split_data = [[xx for xx in x.split("\t")] for x in filtered_data]
            prop = dict([[strip(x[0]), strip(x[1])] for x in split_data])
            return prop
        self.__set_mode(QuarkMode)
        data = self.run_simple_command(f"desc formatted {tblName}")
        prop = dict([[strip(x[0]), strip(x[1])] for x in data])
        return prop

    @with_database
    def show_table_type(self, tblName: str, **kwargs) -> str:
        if Database.__check_value_lower(tblName):
            raise ValueError(f"table only support lowercase string, but {tblName}")
        mapping_tbl_name = self.get_mapping_table(tblName, **kwargs)
        if mapping_tbl_name is not None:
            tblName = mapping_tbl_name
        prop = self.show_properties(tblName, **kwargs)
        input_format = prop.get("InputFormat:")
        if input_format is not None and input_format.find("TimeLyreInputFormat") != -1:
            return "timelyre"
        elif input_format is not None and input_format.find("OrcInputFormat") != -1:
            return "orc"
        elif input_format is not None and input_format.find("TimeLyre2InputFormat") != -1:
            return "timelyre2"
        elif input_format is not None and input_format.find("MemoryTableInputFormat") != -1:
            return "holodesk"
        else:
            return "unknown"

    @with_database
    def get_timelyre_tag_time_col(self, tblName: str, **kwargs) -> (List[str], str):
        prop = self.show_properties(tblName, **kwargs)
        try:
            tag_cols = prop.get('timelyre.tag.cols').split(',')
            time_col = prop.get('timelyre.timestamp.col')
            return tag_cols, time_col
        except Exception as e:
            tbl_type = self.show_table_type(tblName, **kwargs)
            if tbl_type != 'timelyre':
                getLogger().warn(f"only support timelyre table to get tag time col! {tblName} type: {tbl_type}")
            else:
                getLogger().warn(f"failed to get timelyre tag time, prop: {prop}, error: {e}")
            return None, None

    @with_database
    def get_mapping_table(self, tblName: str, use_meta_cache=False, **kwargs) -> str:
        mapping_table = None
        try:
            prop = self.show_properties(tblName, use_meta_cache, **kwargs)
            mapping_table = prop.get("timelyre.merge.columns.mapping", None)
            if mapping_table is not None and mapping_table.strip().find('.') == -1:
                mapping_table = None
        except:
            pass
        return mapping_table

    @with_database
    def get_real_table_name(self, tblName: str, **kwargs) -> str:
        mapping_table_name = self.get_mapping_table(tblName, **kwargs)
        if mapping_table_name is None:
            return tblName
        return mapping_table_name

    @with_database
    def get_quark_schema(self, tblName, **kwargs) -> QuarkSchema:
        cols = self.show_columns(tblName, **kwargs)
        col_names = [item[0] for item in cols]
        col_types = [item[1] for item in cols]
        (tag_cols, ts_col) = self.get_timelyre_tag_time_col(tblName, **kwargs)
        return QuarkSchema(col_names, col_types, tag_cols, ts_col)

    def create_database(self, dbName: str):
        """
        创建一个数据库
        :param dbName: 数据库名
        :return:
        """
        self.__set_mode(QuarkMode)
        data = self.__internal_execute_command(f"create database {dbName}")
        if data["ReturnType"] == "UpdateCount":
            ret = data["UpdateCount"]
            return ret
        elif data["ReturnType"] == "Error":
            raise ConnectionError(data["ErrorMsg"])
        else:
            raise InterruptedError(f"should not happen, data: {data}")

    @with_database
    def create_table(self, tblName: str, tblType: str, schema: list, isSimple: bool = False, isExternal: bool = False,
                     **kwargs):
        """
        创建一张表
        :param tblName: 表名
        :param tblType: 表的类型，当前支持timelyre时序表
        :param schema: 指定表的列名和对应类型
        :param kwargs: 如果创建timelyre时序表, 必须指定timecol的时间戳列，可选指定tags列(1列或多列，多个列名用逗号隔开)
        :return:
        """
        if Database.__check_value_lower(tblName):
            raise ValueError(f"table only support lowercase string, but {tblName}")
        if self.__db == tblName:
            # WARP-85541
            raise ValueError("cannot create table which has identical name as database")
        for x in schema:
            if Database.__check_value_lower(x[0]):
                raise ValueError(f"column name only support lowercase string, but {x[0]}")
            if isinstance(x[1], str) and DataType.has_key(x[1]) == False:
                raise ValueError(f"column type only support {DataType.get_all_type()}, but {x[1]}")
            elif isinstance(x[1], Enum) and DataType.has_key(x[1].value) == False:
                raise ValueError(f"column type only support {DataType.get_all_type()}, but {x[1].value}")
        if tblType == 'orc':
            colWithTypesOrc = [f"`{x[0]}` {x[1]} {Database.get_extra_info(x)} {Database.get_comment_str(x)}" for x in schema]
            schemaSpecOrc = ",".join(colWithTypesOrc)
            bucketCol = None
            bucketQuan = None
            query = ""
            for j in kwargs:
                if j == 'bucketcolumn':
                    bucketCol = kwargs[j]
                if j == 'bucketquantity':
                    bucketQuan = kwargs[j]
            if bucketCol == None and bucketQuan == None:
                query = f'create table {tblName}({schemaSpecOrc}) stored as orc'
            elif bucketCol != None and bucketQuan != None:
                query = f'create table {tblName}({schemaSpecOrc}) clustered by ({bucketCol}) into {bucketQuan} buckets stored as orc tblproperties("transactional"="true")'
            else:
                raise ValueError(f"bucketcolumn and bucketquantity shoule be used at same time")
            self.__set_mode(QuarkMode)
            return self.run_simple_command(query)
        elif tblType == 'timelyre':
            tags = None
            timecol = None
            needUniqCols = False
            tblProps = []
            tblProps.append(f'"epoch.engine.enabled"="true"')
            isShardGroupSet = False
            for k in kwargs:
                if k == 'tags':
                    tags = kwargs[k]
                    tblProps.append(f'"timelyre.tag.cols"="{tags}"')
                if k == 'timecol':
                    timecol = kwargs[k]
                    tblProps.append(f'"timelyre.timestamp.col"="{timecol}"')
                if k == 'uniqcols':
                    uniqCols = kwargs[k]
                    tblProps.append(f'"epoch.row.key.cols"="{uniqCols}"')
                if k == 'shard_group_duration':
                    isShardGroupSet = True
                    shardDurationSec = kwargs[k]
                    tblProps.append(f'"shard.group.duration.seconds"="{shardDurationSec}"')
                if k == 'time_sharding_policy':
                    shard_policy = kwargs[k]
                    tblProps.append(f'"timelyre.time.sharding.policy"="{shard_policy}"')
                if k == 'properties':
                    prop = kwargs[k]
                    tblProps.append(prop)

            if isShardGroupSet is False:
                raise RuntimeError(f"please set shard_group_duration when creating table")
            if isSimple:
                tblProps.append(f'"timelyre.tablet.num"="1"')
            assert tags is not None and timecol is not None, "create timelyre table without time and tag"
            if schema is None or len(schema) <= 0:
                raise RuntimeError(f"create timelyre table without schema")
            if isinstance(schema[0][1], str):
                colWithTypes = [f"`{x[0]}` {x[1]} {Database.get_extra_info(x)} {Database.get_comment_str(x)} " for x in schema]
            elif isinstance(schema[0][1], Enum):
                colWithTypes = [f"`{x[0]}` {x[1].value} {Database.get_extra_info(x)} {Database.get_comment_str(x)}" for x in schema]
            else:
                raise RuntimeError(f"invalid schema type: {type(schema)}, schema: {schema}")
            schemaSpec = ",".join(colWithTypes)

            props = ', '.join(tblProps)
            query = f'create table {tblName}({schemaSpec}) stored as {tblType} tblproperties({props})'
            self.__set_mode(QuarkMode)
            return self.run_simple_command(query)
        elif tblType == 'timelyre2':
            tags = None
            timecol = None
            tblProps = []
            for k in kwargs:
                if k == 'tags':
                    tags = kwargs[k]
                    tblProps.append(f'"timelyre.tag.cols"="{tags}"')
                if k == 'timecol':
                    timecol = kwargs[k]
                    tblProps.append(f'"timelyre.timestamp.col"="{timecol}"')
                if k == 'properties':
                    prop = kwargs[k]
                    tblProps.append(prop)
            if isSimple:
                tblProps.append(f'"timelyre.tablet.num"="1"')
            assert tags is not None and timecol is not None, "create timelyre2 table without time and tag"
            if schema is None or len(schema) <= 0:
                raise RuntimeError(f"create timelyre table without schema")
            if isinstance(schema[0][1], str):
                colWithTypes = [f"`{x[0]}` {x[1]} {Database.get_extra_info(x)} {Database.get_comment_str(x)}" for x in schema]
            elif isinstance(schema[0][1], Enum):
                colWithTypes = [f"`{x[0]}` {x[1].value} {Database.get_extra_info(x)} {Database.get_comment_str(x)}" for x in schema]
            else:
                raise RuntimeError(f"invalid schema type: {type(schema)}, schema: {schema}")
            schemaSpec = ",".join(colWithTypes)

            props = ', '.join(tblProps)
            query = f'create table {tblName}({schemaSpec}) stored as {tblType} tblproperties({props})'
            self.__set_mode(QuarkMode)
            return self.run_simple_command(query)
        elif tblType == 'text':
            external = 'external' if isExternal else ''
            colWithTypes = [f"`{x[0]}` {x[1]}" for x in schema]
            schemaSpec = ",".join(colWithTypes)
            tblProps = []
            if 'col_delimiter' in kwargs.keys():
                delimiter = kwargs['col_delimiter']
                tblProps.append(f"row format delimited fields terminated by '{delimiter}'")
            if isExternal:
                assert 'location' in kwargs.keys(), "must define location to create external table"
                path = kwargs['location']
                tblProps.append(f"location '{path}'")

            props = ' '.join(tblProps)
            query = f'create {external} table {tblName}({schemaSpec}) {props}'
            self.__set_mode(QuarkMode)
            return self.run_simple_command(query)
        elif tblType == "csv":
            colWithTypes = [f"`{x[0]}` {x[1]} {Database.get_extra_info(x)} {Database.get_comment_str(x)}" for x in schema]
            schemaSpec = ",".join(colWithTypes)
            query = f'create table {tblName}({schemaSpec}) stored as csvfile'
            self.__set_mode(QuarkMode)
            return self.run_simple_command(query)
        elif tblType == "parquet":
            colWithTypes = [f"`{x[0]}` {x[1]} {Database.get_extra_info(x)} {Database.get_comment_str(x)}" for x in schema]
            schemaSpec = ",".join(colWithTypes)
            query = f'create table {tblName}({schemaSpec}) stored as parquet'
            self.__set_mode(QuarkMode)
            return self.run_simple_command(query)
        else:
            raise ValueError('tblType can only be orc or timelyre')

    def create_temporary_table(self, tblName: str, schema: list, **kwargs):
        if Database.__check_value_lower(tblName):
            raise ValueError(f"table only support lowercase string, but {tblName}")
        for x in schema:
            if Database.__check_value_lower(x[0]):
                raise ValueError(f"column name only support lowercase string, but {x[0]}")
            if isinstance(x[1], str) and DataType.has_key(x[1]) == False:
                raise ValueError(f"column type only support {DataType.get_all_type()}, but {x[1]}")
            elif isinstance(x[1], Enum) and DataType.has_key(x[1].value) == False:
                raise ValueError(f"column type only support {DataType.get_all_type()}, but {x[1].value}")
        colWithTypesOrc = [f"`{x[0]}` {x[1]}" for x in schema]
        schemaSpec = ",".join(colWithTypesOrc)
        tblProps = []
        tag_col = None
        for k in kwargs:
            if k == 'tags':
                tag_col = kwargs[k]
                tblProps.append(f'"timelyre.tag.cols"="{tag_col}"')
            if k == 'timecol':
                timecol = kwargs[k]
                tblProps.append(f'"timelyre.timestamp.col"="{timecol}"')
        if tag_col is None:
            props = ', '.join(tblProps)
            query = f'create temporary table {self.__db}.{tblName}({schemaSpec}) stored as orc tblproperties({props})'
        else:
            tblProps.append('"transactional"="true"')
            props = ', '.join(tblProps)
            query = f'create temporary table {self.__db}.{tblName}({schemaSpec}) clustered by ({tag_col}) into 10 buckets stored as orc tblproperties({props})'
        self.__set_mode(QuarkMode)
        return self.run_simple_command(query)

    def drop_database(self, dbName: str, forceDrop: bool = False):
        """
        删除一个数据库。仅当库为空时才能成功
        :param dbName: 库名
        :return:
        """
        self.__set_mode(QuarkMode)
        if forceDrop:
            data = self.__internal_execute_command(f"drop database {dbName} cascade")
        else:
            data = self.__internal_execute_command(f"drop database {dbName}")
        if data["ReturnType"] == "UpdateCount":
            ret = data["UpdateCount"]
            return ret
        elif data["ReturnType"] == "Error":
            raise ConnectionError(data["ErrorMsg"])
        else:
            raise InterruptedError(f"should not happen, data: {data}")

    @with_database
    def drop_table(self, tblName: str, **kwargs):
        """
        删除一张表
        :param tblName: 对应的表名
        :return:
        """
        self.__set_mode(QuarkMode)
        if Database.__check_value_lower(tblName):
            raise ValueError(f"table only support lowercase string, but {tblName}")
        mapping_tbl_name = self.get_mapping_table(tblName, **kwargs)
        if mapping_tbl_name is not None:
            # 如果有mapping表, 先删除mapping表
            self.run_simple_command(f"drop table if exists {mapping_tbl_name}")
        if tblName.find(".") != -1:
            return self.run_simple_command(f"drop table {tblName}")
        return self.run_simple_command(f"drop table {tblName}")

    @with_database
    def truncate_table(self, tblName: str, **kwargs):
        """
        清空一张表的数据
        :param tblName: 对应的表名
        :return:
        """
        self.__set_mode(QuarkMode)
        if Database.__check_value_lower(tblName):
            raise ValueError(f"table only support lowercase string, but {tblName}")
        # 先获取mapping_table
        mapping_tbl_name = self.get_mapping_table(tblName, **kwargs)
        if mapping_tbl_name is not None:
            xx = mapping_tbl_name.split(".")
            dbName, tblName = xx
        else:
            dbName = kwargs.get('database', self.db())
        return self.run_simple_command(f"truncate table {dbName}.{tblName}")

    @with_database
    def clear_mapping_table(self, tblName: str, **kwargs):
        mapping_table = self.get_mapping_table(tblName, **kwargs)
        if mapping_table is not None:
            self.internal_set_quark_mode()
            self.drop_table(mapping_table)
            self.run_simple_command(
                f"alter table {tblName} set tblproperties('timelyre.merge.columns.mapping'='none');")

    def clear_tmp_table(self, concurrency, **kwargs):
        tbl_list = self.show_tables(**kwargs)
        mapping_table_list = []
        temp_df_list = []
        valid_mapping_table_list = []
        for tbl in tbl_list:
            if tbl[:13] == "temp_df_table":
                temp_df_list.append(tbl)
            if tbl.find("mapping") != -1:
                mapping_table_list.append(tbl)
            mapped_tbl = self.get_mapping_table(tbl, **kwargs)
            if mapped_tbl is not None:
                xx = mapped_tbl.split(".")[1]
                valid_mapping_table_list.append(xx)
        # 清理mapping table
        for mapping_tbl in mapping_table_list:
            if mapping_tbl not in valid_mapping_table_list:
                self.drop_table(mapping_tbl)

        # 并行清理tmp table和hdfs
        list2 = split_list(temp_df_list, concurrency)
        t1 = time.time()
        results = []
        executor = ThreadPoolExecutor(max_workers=concurrency)
        conns = [self.__make_conn_db() for i in range(0, concurrency)]
        for result in executor.map(clean_tmp_table_internal, conns, list2):
            results.append(result)
        t2 = time.time()
        getLogger().info(f'clean tmp table cost {t2 - t1} s')
        success_count = sum(results)
        all_count = len(temp_df_list)
        return all_count, success_count

    def clear_all_upload_df_tbl(self, concurrency):
        tbl_list = self.show_tables()
        temp_df_list = []
        for tbl in tbl_list:
            if tbl[:13] == "temp_df_table":
                temp_df_list.append(tbl)

        # 并行清理tmp table和hdfs
        list2 = split_list(temp_df_list, concurrency)
        t1 = time.time()
        results = []
        executor = ThreadPoolExecutor(max_workers=concurrency)
        conns = [self.__make_conn_db() for i in range(0, concurrency)]
        for result in executor.map(clean_tmp_table_internal, conns, list2):
            results.append(result)
        t2 = time.time()
        getLogger().info(f'clean tmp table cost {t2 - t1} s')
        success_count = sum(results)
        all_count = len(temp_df_list)
        return all_count, success_count

    def clear_upload_df_tbl(self, table_name: str):
        self.__set_mode(QuarkMode)
        desc_data = self.__quark_query_raw(f'desc formatted {table_name}')
        hdfsloc = None
        for row in desc_data:
            if row[0].startswith('Location:'):
                hdfsloc = row[1]
        if hdfsloc is not None:
            self.run_simple_command(f"dfs -rm -R {hdfsloc}")
        self.drop_table(table_name)

    def __quark_query_raw(self, cmd):
        if cmd is not None:
            data = self.__internal_execute_command(cmd)
        else:
            pass
        hasNextBatch = True
        retData = list()
        if data["ReturnType"] == "UpdateCount":
            hasNextBatch = False
        while hasNextBatch:
            (hasNextBatch, thisBatch, _) = self.__internal_fetch_result(data)
            retData.extend(thisBatch)

        return retData

    def _process_result_df(self, df: pd.DataFrame, db: str, tbl: str):
        # print(f"===> before:\n{df.dtypes}\n{df.values}\n{df}")
        if tbl is None or df is None:
            return
        if db == None:
            schema = self.show_columns(tbl)
        else:
            schema = self.show_columns(tbl, database=db)  # quark的schema类型
        schema_dic = {p[0]: p[1].lower() for p in schema}

        for col in df.columns:
            # print(f'check col: {col}')
            tp = schema_dic.get(col, None)
            if tp is None:
                continue
            if tp == 'float' and df[col].dtype != 'float32':
                df[col] = df[col].astype('float32')  # direct query，从shiva取出来的float列会变成float64类型。此处处理一下
            if tp == 'timestamp' and df[col].dtype != 'datetime64[ns, CST]':
                if df[col].dtype == 'float64' or df[col].dtype == 'int64':  # 如果这一列有空值，这里会是float64类型
                    # direct query，从shiva取出来的非time列的timestamp类型列，类型会不对。此处处理一下
                    df[col] = pd.to_datetime(df[col], unit='ns')
                    if df[col].dt.tz is None:
                        # 如果时间戳列不带时区信息，那么认为这个时间戳是UTC时间，然后将这个时间戳转换成本地时区的时间戳
                        local_time_zone = datetime.datetime.now(datetime.timezone.utc).astimezone().tzinfo
                        df[col] = df[col].dt.tz_localize(datetime.timezone.utc).dt.tz_convert(local_time_zone)

            if self.__convert_decimal_to_float64:
                if 'decimal' in tp and df[col].dtype != 'float64':
                    df[col] = df[col].astype('float64')
            if self.__process_result_null_dtype:
                if tp == 'boolean' and df[col].dtype != 'boolean':
                    # 注意不能是bool，因为会把非True、False的string值和None值转成bool值
                    df[col] = df[col].astype('boolean')
                elif tp == 'tinyint' and df[col].dtype != 'Int8':
                    df[col] = df[col].astype('Int8')
                elif tp == 'smallint' and df[col].dtype != 'Int16':
                    df[col] = df[col].astype('Int16')
                elif tp == 'int' and df[col].dtype != 'Int32':
                    df[col] = df[col].astype('Int32')
                elif tp == 'bigint' and df[col].dtype != 'Int64':
                    df[col] = df[col].astype('Int64')
        # print(f"\n===> after:\n{df.dtypes}\n{df.values}\n========")

    def __post_dataframe_process(self, df):
        """
        对获取到的dataframe进行一些额外的处理，包括：
            1. 把时间列修正为local timezone的表示
        :param df:
        :return:
        """
        df_localize_time(df)

    def query_raw_data(self, table=None, condition=None, sql=None):
        self.__set_mode(QuarkMode)
        if sql is not None:
            data = self.__internal_execute_command(sql)
        else:
            pass
        hasNextBatch = True
        retData = list()
        if data["ReturnType"] == "UpdateCount":
            hasNextBatch = False
        while hasNextBatch:
            (hasNextBatch, thisBatch, _) = self.__internal_fetch_result(data)
            retData.extend(thisBatch)

        # nameWithTypes = data["Columns"].split(",")
        # cols = [x.split(":")[0] for x in nameWithTypes]
        # df = pd.DataFrame(retData, columns=cols)
        return retData

    def get_all_cache_infos(self, with_db_name: bool):
        """
        获取所有数据库cache相关信息
        :with_db_name: 返回的cache信息是否带上db名
        :return: 未过期的cache列表，已过期的cache列表
        """
        res = self.__quark_query_raw("config global timelyre.cache show")
        cacheTables = []
        toDeleteTables = []
        startRecordCache = False
        startRecordDelete = False
        for row in res:
            if row[0].startswith("CacheInfo:"):
                startRecordCache = True
                continue
            if row[0].startswith("ToDeleteTables:"):
                startRecordDelete = True
                startRecordCache = False
                continue
            if startRecordCache:
                tbl = row[0].split("cacheTblName: ")[1].split(",")[0]
                if with_db_name:
                    cacheTables.append(tbl)
                else:
                    cacheTables.append(tbl.split(".")[1])
            if startRecordDelete:
                if with_db_name:
                    cacheTables.append(row[0])
                else:
                    toDeleteTables.append(row[0].split(".")[1])
        return cacheTables, toDeleteTables

    def force_drop_residual_cache_like_tables(self):
        """
        （警告：需充分了解情况后使用）
        清除当前数据库中cache信息丢失而残留的cache表
        cache信息缓存在内存中，如果cache信息丢失，会导致无法通过正常途径清除对应的cache表。
        eg：重启服务会导致内存中的cache信息丢失，那么对应的这部分cache表，不管有没有过期都会被残留下来无法清理
        :return:
        """
        cacheTables, toDeleteTables = self.get_all_cache_infos(with_db_name=False)
        # print(cacheTables)
        # print(toDeleteTables)
        tables = self.show_tables()
        count = 0
        warn_count = 0

        for tbl in tables:
            if not str(tbl).startswith("cache__tmpresult__"):
                continue
            if tbl in cacheTables or tbl in toDeleteTables:
                continue
            res = self.__quark_query_raw(f"drop table {self.__db}.{tbl}")
            if res != []:
                warn_count += 1  # remove过程中出现异常的数量
                getLogger().warn(f"force remove residual cache table: {self.__db}.{tbl}, result: {res}")
            else:
                getLogger().info(f"force remove residual cache table: {self.__db}.{tbl}, result: {res}")
            count += 1
        getLogger().info(
            f"Successfully executed {count} remove cache table operations, including {warn_count} warnings")

    def invalidate_cache_related_to_tbl(self, tblName):
        """
        使当前数据库的指定表相关的cache全部失效
        :param tblName: 表名
        """
        res = self.__quark_query_raw(f"config global timelyre.cache invalidate-query-keyword {tblName}")
        getLogger().info(f"invalidate-cache related to tbl: {self.__db}.{tblName} ret: {res}")

    def invalidate_all_cache(self):
        """
        使所有数据库中所有的cache全部失效
        """
        res = self.__quark_query_raw("config global timelyre.cache invalidate-all")
        if not res[0][0].isdigit():
            getLogger().warn(f"Failed to invalidate all cache, ret: {res}")
        else:
            getLogger().info(f"invalidate-all-cache, count: {res[0][0]}")

    # 为了控制drop时间，默认drop只10个
    def drop_cache_immediately(self, maxDropNum: int = 10):
        self.internal_set_quark_mode()
        res = self.__quark_query_raw("config global timelyre.cache show")
        toDeleteTables = []
        startRecordDelete = False
        for row in res:
            if row[0].startswith("ToDeleteTables:"):
                startRecordDelete = True
                continue
            if startRecordDelete:
                toDeleteTables.append(row[0])

        for x in toDeleteTables[:maxDropNum]:
            try:
                res1 = self.__quark_query_raw(f"drop table {x}")
                res2 = self.__quark_query_raw(f"config global timelyre.cache remove {x}")
                if len(res1) == 0 and str(res2[0][0]).lower() == 'true':
                    getLogger().info(f"remove table cache by api, tbl: {x} result: {res1}, {res2}")
                else:
                    raise RuntimeError("incorrect return")

            except Exception as e:
                getLogger().warn(
                    f"error occurred while removing cache by api, tbl: {x} result: {res1}, {res2}, error: {e}")

    def force_drop_cache_like_tables(self):
        self.internal_set_quark_mode()
        res = self.__quark_query_raw('show tables like "cache__*"')
        for x in res:
            res = self.__quark_query_raw(f"drop table {x[0]}")
            getLogger().info(f"remove table cache by force api {x} result: {res}")

    @post_process_result_df
    @with_database
    def query_as_df(self,
                    tbl: str = None, select_cols: str = None,
                    condition: str = None, query: str = None,
                    order_by_range: str = "",
                    combine_ignore_index: bool = True,
                    adjust_dt_to_lz: bool = True,
                    local_dir: str = None,
                    use_cache: bool = False,
                    cache_ttl: int = 60 * 60 * 1000,
                    use_local_write: bool = False,
                    pq_file_size: int = 2000000,
                    query_timeout: int = 180,
                    cols: List[str] = None,
                    tag_value_list: List[str] = None,
                    time_filter: List[str] = None,
                    direct_query_enabled: bool = True,
                    auto_direct_check: bool = True,
                    use_meta_cache: bool = False,
                    **kwargs
                    ):
        """
        从一张表里按照指定条件查询相应数据
        :param cache_ttl: cache的生命周期，默认1个小时
        :param use_cache: 是否使用查询cache
        :param select_cols:  (可选) 选择的列
        :param order_by_range: （可选）针对orderby timestamp的优化
        :param tbl: 表名
        :param condition: （可选）指定查询的条件，采用SQL where条件里的写法
        :param query: 直接查询的语句
        :param combine_ignore_index: query的结果分为多个文件，该选项决定多个文件的df合并为一个时的选项
        :param adjust_dt_to_lz: 将没有tz信息的时间戳按照utc解析并按照local timezone信息设置
        :param local_dir: 设置查询结果文件在本地存放的目录
        :param direct_query_enabled: 是否启用direct查询
        :param auto_direct_check: 是否识别潜在sql为direct查询
        :return: 将数据读取为一个DataFrame返回
        """
        # 检查是否能优化成direct_query_as_df
        if self.direct_query_enabled and direct_query_enabled:
            table_type = self.show_table_type(tblName=tbl, **kwargs)
            if table_type == "timelyre" or table_type == "timelyre2":
                if query is not None and auto_direct_check:
                    try:
                        tag_cols, time_col = self.get_timelyre_tag_time_col(tblName=tbl, **kwargs)
                        if (tag_cols is not None and time_col is not None) and len(tag_cols) == 1:  # 暂时只支持单tag
                            query_info = DirectQueryUtil.is_direct_query_enabled(query, tag_cols[0], time_col)
                            max_tag_batch = 500
                            # 不能支持tag list太多的场景，因为需要拼接一个url去问shiva web server要到每个tag的位置，而url的长度是有限制的，是8192个byte，url的格式如下，
                            # 大概能支持700个tag_value_list, 保守起见设置成500上限, 每个值会变成一个长度为10的string,（未来优化可以优化成post请求，但是也不建议，
                            # 太多code也会导致shiva web server性能下降）
                            if query_info is not None and query_info.tag_value_list is not None and \
                                    len(query_info.tag_value_list) <= max_tag_batch:
                                if query_info.table_name == tbl and (
                                        query_info.db_name == "" or query_info.db_name == self.__db):
                                    getLogger().info("transfer to direct_query_as_df")
                                    # print("transfer to direct_query_as_df")
                                    return self.direct_query_as_df(table_name=tbl, cols=query_info.cols,
                                                                   tag_value_list=query_info.tag_value_list,
                                                                   time_filter=query_info.time_filter,
                                                                   use_meta_cache=use_meta_cache, **kwargs)
                    except Exception as e:
                        getLogger().warn(f"error occurred when direct_query, fallback. error: {e}")
                        print(f"error occurred when direct_query, fallback. error: {e}")
                        return None

                elif query is None:
                    getLogger().info("use direct_query_as_df")
                    # print("use direct_query_as_df")
                    return self.direct_query_as_df(table_name=tbl,
                                                   cols=cols, tag_value_list=tag_value_list, time_filter=time_filter,
                                                   use_meta_cache=use_meta_cache, **kwargs)
            else:
                getLogger().info("not timelyre table, use query")
                # print("not timelyre table, use query")
                if query is None:
                    query = DirectQueryUtil.paras_to_query(tbl, cols, tag_value_list, time_filter)

        cache_db = f"{self.__default_cache_db}."
        time1 = time.time_ns()
        mapping_tbl_name = self.get_mapping_table(tbl, **kwargs)
        if mapping_tbl_name is not None:
            tbl = mapping_tbl_name

        self.__set_mode(QuarkMode)
        self.run_simple_command("set timelyre.skip.dfs.auth.check=true")
        self.run_simple_command(
            "set hive.optimize.ppd = false;set character.literal.as.string=true;set timelyre.in.expression.optimization.enabled=true;")
        if use_cache:
            self.run_simple_command("set crux.rewriter.enabled=true;")
            self.__quark_query_raw("config global crux.rewriter add io.transwarp.crux.timelyre.CruxCacheRewriter;")
        result_table_name = "tmpresult__" + datetime.datetime.now().strftime(
            "%Y%m%d_%H%M%S%f") + "_" + Database.newSymbolId()
        times = []
        times.append(time.perf_counter())

        order_by_hint = ""
        if order_by_range != "":
            range_list = order_by_range.split(",")
            if len(range_list) == 2:
                order_by_hint = f"/*+ORDERBY_RANGE({range_list[0]},{range_list[1]})*/"

        # 生成核心的查询SQL
        if query is None:
            if condition is None or condition.strip() == "":
                condStr = ""
            else:
                condStr = f"where {condition}"
            if select_cols is None or select_cols.strip() == "":
                selectStr = "*"
            else:
                selectStr = select_cols
            if '.' not in tbl:
                dbName = kwargs.get('database', self.db())
                tbl = f"{dbName}.{tbl}"
            queryCore = f'select {order_by_hint} {selectStr} from {tbl} {condStr}'
        else:
            # try to replace tableName with mapping table name
            if mapping_tbl_name is not None:
                old_tbl_name, l, r = get_tbl_name_from_sql(query)
                query = query[0:l] + mapping_tbl_name + query[r:]

            # add order_by_hint
            if order_by_hint != "":
                index = query.lower().find("select")
                if index >= 0:
                    query = query[0:index + 6] + order_by_hint + query[index + 6:]
            queryCore = query

        # local_write的路会将数据写在存储本地，客户端在写入完成后直接通过http从各个存储节点获取数据，不需要建pq外表的方式来存储文件，这部分暂时不能使用cache
        if use_local_write:
            self.run_simple_command("set timelyre.pq.local.write.enabled=true")
            self.run_simple_command(f"explain {queryCore}")
            res = self.run_simple_command("set timely.pq.local.write.status")
            pq_local_write_stats = bool(res[0][0].split("=")[1])
            if pq_local_write_stats:
                self.run_simple_command(f"set timelyre.pq.chunk.size={pq_file_size}")
                self.run_simple_command(f"set timelyre.query.queue.timeout={query_timeout}")
                finalQuery = queryCore
                getLogger().info(f'final Query {finalQuery}')
            else:
                self.run_simple_command("set timelyre.pq.local.write.enabled=false")
                directQuery = f'create table {result_table_name} stored as parquet as {queryCore}'
                finalQuery = directQuery
                use_local_write = False
                if use_cache:
                    result_table_name = f"{cache_db}cache__{result_table_name}"
                finalQuery = f'create table {result_table_name} stored as parquet as /*USE_TL_CACHE({result_table_name})*/ {queryCore}'
        else:
            # 查询结果的存储方式，使用表作为传输给客户端的媒介，或者直接使用Cache的结果表
            self.run_simple_command("set timelyre.pq.local.write.enabled=false")
            orig_table_name = result_table_name
            directQuery = f'create temporary table {result_table_name} stored as parquet as {queryCore}'
            finalQuery = directQuery
            if use_cache:
                result_table_name = f"{cache_db}cache__{result_table_name}"
                finalQuery = f'create table {result_table_name} stored as parquet as /*USE_TL_CACHE({result_table_name})*/ {queryCore}'

        t1 = time.time()
        finalQueryRes = self.__quark_query_raw(finalQuery)
        t2 = time.time()
        getLogger().info(f'query_as_df final Query {finalQuery}, cost {t2 - t1} s')
        if use_local_write:
            df = self.__get_local_write_info(tbl)
            if adjust_dt_to_lz and local_dir is None and df is not None:
                self.__post_dataframe_process(df)
            return df

        if use_cache:
            result_table_name, hit_cache = do_cache_control(
                finalQueryRes,
                result_table_name,
                self.__quark_query_raw,
                self.getLocation,
                self.drop_cache_immediately,
                ttl=cache_ttl)
            if "." not in result_table_name:
                result_table_name = f"{cache_db}{result_table_name}"
            if not hit_cache:
                self.drop_cache_immediately(3)  # 未命中cache时，也删除部分过期的cache

        # 获取结果表（可能是cache表）的数据位置
        try:
            hdfsloc = self.getLocation(result_table_name)
            # print(f"hdfsloc: {hdfsloc}")
        except ConnectionError as e:
            # 在极端情况下，在上面命中cache后有可能cache已被清空.或者未命中cache，新建cache失败
            if use_cache and (str(e).find(f"Table not found: {result_table_name}") != -1 or
                              str(e).find(f"Table not found: {result_table_name.split('.')[1]}") != -1):
                getLogger().info(f"cache {result_table_name} hit and is removed immediately, do a normal query again")
                self.__quark_query_raw(directQuery)
                hdfsloc = self.getLocation(orig_table_name)
            else:
                raise e

        times.append(time.perf_counter())

        (dirId, dirPath) = self.__tmp_mgr.prepareNewTempDir()

        getLogger().info(f'remote quark tmp dir id {dirId}, path {dirPath}')

        try:
            if hdfsloc.startswith("file:/"):
                hdfsloc = hdfsloc.replace("file:/", "file:////", 1)
                try:
                    self.__quark_query_raw(f"dfs -get {hdfsloc}/* {dirPath}")
                except Exception as e:
                    return pd.DataFrame()
            else:
                self.__quark_query_raw(f"dfs -get {hdfsloc}/* {dirPath}")
            times.append(time.perf_counter())
            df = get_remote_dataframe(self.__rest_host_port, self.__token, dirId, combine_ignore_index, local_dir)
            times.append(time.perf_counter())
        except Exception as e:
            raise e
        finally:
            self.__tmp_mgr.releaseTempDir(dirId)

        # 调整时区逻辑
        # 从parquet读出来的时间是没有时区的（可以认为是GMT），需要调整成本地时区
        # local_dir是把结果存为parquet的逻辑，无需考虑转换时区
        if adjust_dt_to_lz and local_dir is None and df is not None:
            self.__post_dataframe_process(df)
        times.append(time.perf_counter())
        diffs = [str(times[i] - times[i - 1]) for i in range(1, len(times))]
        getLogger().info('time stat:' + ', '.join(diffs))
        time2 = time.time_ns()
        getLogger().info(f'query_as_df costs: {(time2 - time1) / 1000000.0} ms')
        if local_dir is not None:
            return None

        getLogger().info(f"retrieve data with shape {df.shape}")
        return df

    # 获取当前query的queryid和buckct信息
    def __get_local_write_info(self, tbl: str):
        ret = self.run_simple_command("config global previous.queryid")
        query_id = int(ret[0][0])
        table_name = self.__db + "." + tbl
        res = self.run_simple_command(f"config global timelyre show-shards {table_name}")
        base_urls = [f"http://{line[0].split(' ')[3]}/api/timelyre/tables/getpqfile?bucketname={line[0].split(' ')[5]}"
                     for line in res]
        res = get_remote_dataframe_from_storage(bucketUrl=base_urls, queryid=query_id, combine_ignore_index=True)
        return res

    @with_database
    def upload_df(self, df: pd.DataFrame, schema: list, table_type="parquet", table_name=None,
                  batch_size=200000, tag_cols="", ts_col="", max_worker_num=30,
                  use_parallel=True, use_memory_parquet=True, **kwargs):
        external_table_name, hdfs_path = self.__upload_df_internal(df, schema, table_type, batch_size,
                                                                   tag_cols, ts_col, max_worker_num,
                                                                   use_parallel, use_memory_parquet,
                                                                   **kwargs)
        if table_name is not None:
            db = kwargs.get('database', self.db())
            # 如果提供了目标表的表名，就执行一次插入
            mapping_tbl_name = self.get_mapping_table(table_name, **kwargs)
            if mapping_tbl_name is not None:
                table_name = mapping_tbl_name
            else:
                table_name = f"{db}.{table_name}"
            try:
                self.run_simple_command(f"insert into {table_name} select * from {db}.{external_table_name}")
            finally:
                # 清理临时资源
                self.drop_table(external_table_name, **kwargs)
                self.run_simple_command(f"dfs -rm -R {hdfs_path}")
        return external_table_name, hdfs_path

    def __upload_df_internal(self, df: pd.DataFrame, schema: list, table_type,
                             batch_size, tag_cols, ts_col, max_worker_num,
                             use_parallel, use_memory_parquet, **kwargs):
        times = []
        times.append(time.perf_counter())

        # 调整dataframe的格式，主要是时间戳的时区
        normalize_df(df, schema, self.__convert_decimal_to_float64)

        # 向quark申请临时目录
        (dirId, dirPath) = self.__tmp_mgr.prepareNewTempDir()

        getLogger().info(f'remote quark tmp dir id {dirId}, path {dirPath}')
        local_temp_dir = ""
        try:
            uid = str(uuid.uuid1())
            if use_memory_parquet:
                # 使用内存来存放parquet文件
                file_list = parquet_utils.parallel_send_to_remote_server(df, host_port=self.__rest_host_port,
                                                                         token=self.__token, uid=uid,
                                                                         remote_dir_id=dirId,
                                                                         table_type=table_type,
                                                                         batch_size=batch_size,
                                                                         max_worker_num=max_worker_num)
            else:
                # 将df变成本地临时的文件
                if use_parallel:
                    # 并行执行
                    (local_temp_dir, file_list) = parquet_utils.parallel_write_to_parquet(df, uid=uid,
                                                                                          table_type=table_type,
                                                                                          batch_size=batch_size,
                                                                                          max_worker_num=max_worker_num)
                else:
                    # 串行执行
                    (local_temp_dir, file_list) = parquet_utils.df_to_local_file(df, uid=uid, table_type=table_type,
                                                                                 batch_size=batch_size)
                # print(local_temp_dir + "\n")
                # print(",".join(file_list) + "\n")

                times.append(time.perf_counter())

                # 并发上传文件到quark的临时目录
                put_remote_dataframe(self.__rest_host_port, self.__token, dirId, file_list,
                                     max_worker_num=max_worker_num)
                times.append(time.perf_counter())

            # 确认所有文件已经上传
            quark_file_list = self.__tmp_mgr.listFilesInTempDir(dirId)
            if len(quark_file_list) != len(file_list):
                raise RuntimeError(
                    f"some error happen, please retry! quark file list len ({len(quark_file_list)}) != local file list len ({len(file_list)})")

            # 将临时目录里的所有文件put到hdfs上
            ret = self.run_simple_command("set fs.defaultFS")
            default_fs = ret[0][0].split("=")[1]
            hdfs_path = f"{default_fs}/tmp/hdfs-timelyre-py/{uid}"
            self.__quark_query_raw(f"dfs -mkdir -p {hdfs_path}")
            for file in quark_file_list:
                hdfs_put_query = f"dfs -put {dirPath}/{file} {hdfs_path}"
                self.__quark_query_raw(hdfs_put_query)
            times.append(time.perf_counter())
            # 建对应的parquet/csv外表
            external_table_name = self.__create_external_file(uid, table_type, schema, hdfs_path, tag_cols, ts_col,
                                                              **kwargs)
        finally:
            # 释放quark临时目录，删除本地临时的文件
            import shutil
            self.__tmp_mgr.releaseTempDir(dirId)
            if local_temp_dir != "":
                shutil.rmtree(local_temp_dir)

        diffs = [str(times[i] - times[i - 1]) for i in range(1, len(times))]
        getLogger().info('time stat:' + ', '.join(diffs))

        # 返回外表名和hdfs目录，调用者负责清理
        return external_table_name, hdfs_path

    def __create_external_file(self, uid, table_type: str, schema: list, hdfsPath: str, tag_cols="", ts_col: str = "",
                               **kwargs):
        if tag_cols is None:
            tag_cols = []
        for x in schema:
            if Database.__check_value_lower(x[0]):
                raise ValueError(f"column name only support lowercase string, but {x[0]}")
            if table_type == "timelyre":
                if isinstance(x[1], str) and DataType.has_key(x[1]) == False:
                    raise ValueError(f"column type only support {DataType.get_all_type()}, but {x[1]}")
                elif isinstance(x[1], Enum) and DataType.has_key(x[1].value) == False:
                    raise ValueError(f"column type only support {DataType.get_all_type()}, but {x[1].value}")

        tbl_properties = []
        if tag_cols != "":
            tbl_properties.append(f"'timelyre.tag.cols'='{tag_cols}'")
        if ts_col != "":
            tbl_properties.append(f"'timelyre.timestamp.col'='{ts_col}'")
        tbl_prop_str = ""
        if len(tbl_properties) > 0:
            ss = ",".join(tbl_properties)
            tbl_prop_str = f"TBLPROPERTIES({ss})"

        tblName = f"temp_df_table_{uid}".replace("-", "_")
        db = kwargs.get('database', self.db())
        if table_type == "parquet":
            colWithTypes = [f"`{x[0]}` {x[1]}" for x in schema]
            schemaSpec = ",".join(colWithTypes)
            query = f"create external table {db}.{tblName}({schemaSpec}) stored as parquet LOCATION '{hdfsPath}' {tbl_prop_str}"
        elif table_type == "csv":
            colWithTypes = [f"`{x[0]}` string" for x in schema]
            schemaSpec = ",".join(colWithTypes)
            query = f"create external table {db}.{tblName}({schemaSpec}) stored as csvfile LOCATION '{hdfsPath}' {tbl_prop_str}"
        else:
            raise RuntimeError(f"do not support {table_type}")
        self.__set_mode(QuarkMode)
        self.run_simple_command(query)
        return tblName

    def __insert(self, db, table, values):
        if len(values) == 0:
            return
        all_rows = []
        row_len = len(values[0])
        for row in values:
            for i in range(row_len):
                if is_null(row[i]):
                    row[i] = None
            row2 = []
            for x in row:
                if x is None:
                    row2.append("null")
                else:
                    row2.append('\'' + str(x) + '\'')

            row_values = '(' + ','.join(row2) + ')'
            all_rows.append(row_values)
        all_data = ','.join(all_rows)
        q = f'insert into `{db}`.`{table}` values {all_data}'
        return self.run_simple_command(q)

    def __insert2(self, db, table, values):
        if len(values) == 0:
            return
        all_rows = []
        row_len = len(values[0])
        quark_column_types = self.get_quark_schema(table).get_column_types()
        for row in values:
            for i in range(row_len):
                if is_null(row[i]):
                    row[i] = "null"
            row2 = []
            for i in range(row_len):
                if quark_column_types[i] != 'boolean':
                    row2.append('\'' + str(row[i]) + '\'')
                else:
                    row2.append(str(row[i]))
            row_values = 'values(' + ','.join(row2) + ')'
            all_rows.append(row_values)
        all_data = ','.join(all_rows)
        q = f'batchinsert into `{db}`.`{table}` batchvalues ({all_data})'
        self.__set_mode(QuarkMode)
        return self.run_simple_command(q)

    @with_database
    def insert(self, table, values: Union[pd.DataFrame, list], batch: int = 500, parallelism: int = 1,
               run_mode: str = CruxMode, **kwargs):
        """
        向指定表插入数据
        :param table: 表名
        :param values: 插入的数据，支持DataFrame或者list数据的形式
        :param batch: 内部插入数据每批的大小，默认500行一次插入
        :return:
        """
        db = kwargs.get('database', self.db())
        mapping_tbl_name = self.get_mapping_table(table, **kwargs)
        if mapping_tbl_name is not None:
            xx = mapping_tbl_name.split(".")
            if len(xx) == 2:
                table = xx[1]
        if self.show_table_type(tblName=table, **kwargs) == "timelyre2":
            run_mode = QuarkMode
        self.__set_mode(run_mode)
        if parallelism == 1:
            if isinstance(values, list):
                ROW_BATCH: int = batch
                for i in range(0, int(len(values) / ROW_BATCH) + 1):
                    #print(f'batch {i} size {batch}')
                    vv = values[i * ROW_BATCH: (i + 1) * ROW_BATCH]
                    if run_mode is QuarkMode:
                        self.__insert2(db, table, vv)
                    else:
                        self.__insert(db, table, vv)
            elif isinstance(values, pd.DataFrame):
                rowcount = values.shape[0]
                ROW_BATCH: int = batch
                for i in range(0, int(rowcount / ROW_BATCH) + 1):
                    rows = values.iloc[i * ROW_BATCH: (i + 1) * ROW_BATCH].values.tolist()
                    t1 = time.time()
                    if run_mode is QuarkMode:
                        self.__insert2(db, table, rows)
                    else:
                        self.__insert(db, table, rows)
                    t2 = time.time()
                    #print(f'batch {i} size {len(rows)} {t2 - t1} s')
            else:
                raise RuntimeError(f"unsupported values type: {type(values)} in insert condition")
        else:
            if isinstance(values, list):
                rowcount = len(values)
            elif isinstance(values, pd.DataFrame):
                rowcount = values.shape[0]
            else:
                raise RuntimeError(f"unsupported values type: {type(values)} in parallelism insert condition")

            ROW_BATCH: int = batch

            # seg_starts = [i * ROW_BATCH for i in range(0, int(rowcount / ROW_BATCH) + 1)]
            # seg_ends = [(i + 1) * ROW_BATCH - 1 for i in range(0, int(rowcount / ROW_BATCH) + 1)]

            segs = [(i * ROW_BATCH, (i + 1) * ROW_BATCH - 1) for i in range(0, int(rowcount / ROW_BATCH) + 1)]

            thisParallelism = min(10, parallelism)
            segs_splits = np.array_split(segs, thisParallelism)
            conns = [self.__make_conn_db() for i in range(0, thisParallelism)]

            t1 = time.time()
            results = []
            executor = ThreadPoolExecutor(max_workers=thisParallelism)

            # for result in executor.map(self.__do_parallel_insert, itertools.cycle(conns), itertools.repeat(values), itertools.repeat(table), seg_starts, seg_ends):
            #     results.append(result)
            for result in executor.map(Database.__do_parallel_multiple_inserts, conns, itertools.repeat(values),
                                       itertools.repeat(db), itertools.repeat(table), segs_splits,
                                       itertools.repeat(run_mode)):
                results.append(result)

            t2 = time.time()
            # print(f"parallel cost {t2 - t1}")

    def __make_conn_db(self):
        return Database(self.__jdbc_http, self.__conn, self.__db, self.__auth_type, self.__run_mode, **self.__kwargs)

    def db(self):
        return self.__db

    def proxy(self):
        return self.__jdbc_http

    def fetch_hdfs_pq_dir_as_df(self, hdfsloc: str):
        (dirId, dirPath) = self.__tmp_mgr.prepareNewTempDir()

        getLogger().info(f'remote quark tmp dir id {dirId}, path {dirPath}')

        t1 = time.time()
        self.__quark_query_raw(f"dfs -get {refineHdfsLoc(hdfsloc)}/* {dirPath}")
        t2 = time.time()

        df = get_remote_dataframe(self.__rest_host_port, self.__token, dirId, combine_ignore_index=True, local_dir=None)
        t3 = time.time()
        # 调整时区逻辑
        # 从parquet读出来的时间是没有时区的（可以认为是GMT），需要调整成本地时区
        # local_dir是把结果存为parquet的逻辑，无需考虑转换时区
        if df is not None:
            self.__post_dataframe_process(df)

        t4 = time.time()

        self.__tmp_mgr.releaseTempDir(dirId)
        t5 = time.time()
        print(t2 - t1, t3 - t2, t4 - t3, t5 - t4)
        return df

    def asof_join(self, left_table: str, right_table: str,
                  left_select_cols: list, right_select_cols: list,
                  left_join_keys: list, right_join_keys: list,
                  code_filter: list, low_ts_filter: str, high_ts_filter: str):
        real_left_table = self.get_real_table_name(left_table)
        real_right_table = self.get_real_table_name(right_table)
        (left_tag_col, left_ts_col) = self.get_timelyre_tag_time_col(real_left_table)
        (right_tag_col, right_ts_col) = self.get_timelyre_tag_time_col(real_left_table)
        if left_join_keys is None or len(left_join_keys) == 0:
            left_join_keys = [left_tag_col, left_ts_col]
        if right_join_keys is None or len(right_join_keys) == 0:
            right_join_keys = [right_tag_col, right_ts_col]
        sql = generate_asof_join_str(real_left_table, real_right_table, left_select_cols, right_select_cols,
                                     left_join_keys, right_join_keys, code_filter, low_ts_filter, high_ts_filter,
                                     code_col=left_tag_col, ts_col=left_ts_col)
        getLogger().info(f"asof join sql: {sql}")
        command = "set timelyre.join.type=asof;set hive.optimize.ppd=true;"
        df = self.query_data(query=sql, command=command)
        return df

    def window_join(self, window: list,
                    left_table: str, right_table: str,
                    left_select_cols: list, right_select_cols: list,
                    left_join_keys: list, right_join_keys: list,
                    code_filter: list, low_ts_filter: str, high_ts_filter: str,
                    left_aggregation: list, right_aggregation: list):
        real_left_table = self.get_real_table_name(left_table)
        real_right_table = self.get_real_table_name(right_table)
        (left_tag_col, left_ts_col) = self.get_timelyre_tag_time_col(real_left_table)
        (right_tag_col, right_ts_col) = self.get_timelyre_tag_time_col(real_left_table)
        if left_join_keys is None or len(left_join_keys) == 0:
            left_join_keys = [left_tag_col, left_ts_col]
        if right_join_keys is None or len(right_join_keys) == 0:
            right_join_keys = [right_tag_col, right_ts_col]
        sql = generate_window_join_str(real_left_table, real_right_table, left_select_cols, right_select_cols,
                                       left_join_keys, right_join_keys, code_filter, low_ts_filter, high_ts_filter,
                                       code_col=left_tag_col, ts_col=left_ts_col,
                                       left_aggregation=left_aggregation, right_aggregation=right_aggregation)
        if len(window) != 2:
            raise Exception("window should have two integers")
        left = int(window[0])
        right = int(window[1])
        getLogger().info(f"window join sql: {sql}")
        command = f"set timelyre.join.type=window;set hive.optimize.ppd=true;set timelyre.window.join.timestamp.range={left},{right};"
        df = self.query_data(query=sql, command=command)
        return df

    def run(self, sql, use_pq: bool = True):
        self.__set_mode(CruxMode)
        if use_pq:
            res = self.__query_raw_pq(sql)
        else:
            res = self.__query_raw(sql)
        return res

    def __query_raw(self, cmd):
        run_times = []
        run_times.append(time.perf_counter())
        if cmd is not None:
            # print(f"{self.__lastSessionId} do execute", flush=True)
            data = self.__internal_execute_command(cmd)
            # print(f"{self.__lastSessionId} execute finish", flush=True)
        else:
            pass
        run_times.append(time.perf_counter())
        hasNextBatch = True
        retData = list()
        retData.append(data["Columns"])
        if data["ReturnType"] == "UpdateCount":
            hasNextBatch = False
        # print(f"query {cmd[:20]} {hasNextBatch}")
        times_fetch = []
        json_times = 0
        while hasNextBatch:
            # print(f"{self.__lastSessionId} do fetch", flush=True)
            t1 = time.time_ns()
            (hasNextBatch, thisBatch, t) = self.__internal_fetch_result(data)
            t2 = time.time_ns()
            times_fetch.append((t2 - t1) / 1000000.0)
            json_times += t
            # print(f"{self.__lastSessionId} fetch finish", flush=True)
            retData.extend(thisBatch)
        getLogger().info(
            f'fetch data process {len(times_fetch)} times, avg: {sum(times_fetch) / len(times_fetch)} ms, json load costs: {json_times / 1000000.0} ms')
        run_times.append(time.perf_counter())
        diffs = [str(run_times[i] - run_times[i - 1]) for i in range(1, len(run_times))]
        infos = ["__internal_execute_command", "__internal_fetch_result"]
        try:
            assert len(diffs) == len(infos)
            msg = [f"{infos[i]}: {diffs[i]}" for i in range(len(diffs))]
            getLogger().info('dfrun time stat: ' + ', '.join(msg))
        except Exception:
            getLogger().info('dfrun time stat: ' + ', '.join(diffs))

        return retData

    def __query_raw_pq(self, cmd):
        run_times = []
        run_times.append(time.perf_counter())

        # 1. 执行sql，quark获取parquet文件字节流，将parquet文件存到临时目录
        if cmd is not None:
            data = self.__internal_execute_command(cmd)
        else:
            pass
        run_times.append(time.perf_counter())

        # 2. 获取schema信息和临时目录信息
        (dirId, dirPath) = (None, None)
        hasNextBatch = True
        retData = list()
        retData.append(data["Columns"])
        if data["ReturnType"] == "UpdateCount":
            hasNextBatch = False
        times_fetch = []
        json_times = 0
        while hasNextBatch:
            t1 = time.time_ns()
            (hasNextBatch, thisBatch, t) = self.__internal_fetch_result(data)
            t2 = time.time_ns()
            times_fetch.append((t2 - t1) / 1000000.0)
            json_times += t
            retData.extend(thisBatch)

        names = []
        types = []
        for value in retData[0].split(","):
            names.append(value.split(":")[0])
            types.append(value.split(":")[1])

        getLogger().info(f"origin timelyre names: {names}, timelyre types: {retData[1]}")
        timelyre_col_types = [type_value_to_type_int(retData[1][i], types[i]) for i in range(len(retData[1]))]

        getLogger().info(f"fixed timelyre types: {timelyre_col_types}")

        for i in range(len(timelyre_col_types)):
            if timelyre_col_types[i] == TagType:
                (dirId, dirPath) = str(retData[2][i]).split(",")

        getLogger().info(f'get remote quark tmp dir id {dirId}, path {dirPath}')

        run_times.append(time.perf_counter())
        df = pd.DataFrame()
        if dirId is not None:
            combine_ignore_index = True
            adjust_dt_to_lz = True
            local_dir = None
            df = get_remote_dataframe(self.__rest_host_port, self.__token, dirId, combine_ignore_index, local_dir)

            run_times.append(time.perf_counter())
            if not df.empty:
                # 根据schema信息，astype一下时间列
                for i in range(len(timelyre_col_types)):
                    tp = timelyre_col_types[i]
                    if tp in [TimestampType, CastTSType, CastMinuteType, CastDateType]:
                        col = df.columns[i]
                        df[col] = df[col].astype("datetime64[ns]")

            run_times.append(time.perf_counter())

            # 调整时区逻辑
            # 从parquet读出来的时间是没有时区的（可以认为是GMT），需要调整成本地时区
            # local_dir是把结果存为parquet的逻辑，无需考虑转换时区

            if adjust_dt_to_lz and local_dir is None and df is not None:
                self.__post_dataframe_process(df)

            # 释放临时文件夹
            self.__tmp_mgr.releaseTempDir(dirId)
        else:
            run_times.append(time.perf_counter())

        run_times.append(time.perf_counter())

        diffs = [str(run_times[i] - run_times[i - 1]) for i in range(1, len(run_times))]
        infos = ["__internal_execute_command", "get_dir", "get_remote_dataframe_from_pq", "data_process_tscol",
                 "data_process_tz"]
        try:
            assert len(diffs) == len(infos)
            msg = [f"{infos[i]}: {diffs[i]}" for i in range(len(diffs))]
            getLogger().info('dfrun time stat: ' + ', '.join(msg))
        except Exception:
            getLogger().info('dfrun time stat: ' + ', '.join(diffs))

        getLogger().info(f"dfrun retrieve data with shape {df.shape}")
        return df

    @db_cacheable
    def get_shiva_table_name(self, table_name, use_meta_cache: bool = False, **kwargs):
        if Database.__check_value_lower(table_name):
            raise ValueError(f"table only support lowercase string, but {table_name}")
        # meta access
        mapping_tbl_name = self.get_mapping_table(table_name, use_meta_cache, **kwargs)
        if mapping_tbl_name is not None:
            table_name = mapping_tbl_name
        # meta access
        prop = self.show_properties(table_name, use_meta_cache, **kwargs)
        real_name = f"{self.__db}.{table_name}"
        shiva_tablename = prop.get("timelyre.shiva.tablename")
        if shiva_tablename is not None:
            real_name = shiva_tablename
        return real_name

    @with_database
    def get_timelyre_schema(self, table_name, **kwargs):
        real_name = self.get_shiva_table_name(table_name, **kwargs)
        return self.__timelyre_client.get_schema_from_shiva(real_name)

    @with_database
    def get_tag_distribution(self, table_name, tag_value_list, use_meta_cache, is_timelyre2=False, **kwargs):
        real_name = self.get_shiva_table_name(table_name, use_meta_cache, **kwargs)
        if is_timelyre2:
            tag_cols, _ = self.get_timelyre_tag_time_col(table_name, **kwargs)
            return self.__timelyre_client.get_tag_distribution_for_timelyre2(real_name, tag_value_list, tag_cols)
        else:
            return self.__timelyre_client.get_tag_distribution(real_name, tag_value_list)

    def __get_leopard_session(self, use_connector_mode, datasource_version="v2"):
        from .leopard.leopard_session import LeopardSession
        if datasource_version == "v1":
            if self.__leopard_session is None:
                leopard_conf = {}
                for k, v in self.__kwargs.items():
                    if isinstance(k, str) and k.startswith("leopard_"):
                        leopard_conf[k] = v
                self.__leopard_session = LeopardSession(self.__leopard_connector_addr,
                                                        self.__leopard_master_addr,
                                                        self.__shiva_master_addr,
                                                        use_connector_mode,
                                                        leopard_conf)

            return self.__leopard_session
        elif datasource_version == "v2":
            if self.__leopard_session is not None:
                return self.__leopard_session
            leopard_conf = {}
            for k, v in self.__kwargs.items():
                if isinstance(k, str) and k.startswith("leopard_"):
                    leopard_conf[k] = v
            self.__leopard_session = LeopardSession(self.__leopard_connector_addr,
                                                    self.__leopard_master_addr,
                                                    self.__shiva_master_addr,
                                                    use_connector_mode,
                                                    leopard_conf)

            return self.__leopard_session
        else:
            raise ValueError(f"unsupported datasource version {datasource_version}")

    @with_database
    def load_df(self, table_name: str, table_type: str, use_connector_mode=True, datasource_version="v2", file_path="",
                tag_list=None, ts_min=None, ts_max=None, opts_map=None, **kwargs):
        from .leopard import leopard_utils
        prop = self.show_properties(table_name, use_cacheable=True, **kwargs)
        quark_schema = self.show_columns(table_name, use_cacheable=True, **kwargs)
        schema = leopard_utils.quark_schema_to_leopard_schema(table_type, quark_schema, prop)
        session = self.__get_leopard_session(use_connector_mode, datasource_version)
        if table_type == "timelyre":
            real_name = self.get_shiva_table_name(table_name, use_cacheable=True, **kwargs)
            return session.load_df(real_name, schema, "timelyre", datasource_version, file_path,
                                   tag_list, ts_min, ts_max, prop, opts_map)
        else:
            file_location = self.getLocation(table_name)
            return session.load_df(table_name=table_name, schema=schema, table_type=table_type, file_path=file_location,
                                   tag_list=tag_list, ts_min=ts_min, ts_max=ts_max, opts_map=opts_map)

    def load_file(self, file_path: str, file_type: str, schema: list, use_connector_mode=False):
        session = self.__get_leopard_session(use_connector_mode)
        return session.load_file_df(file_path, file_type, schema)

    @with_database
    def save_df_as_table(self, df, table_name: str, table_type: str, mode: str, tags: str, timecol: str, **kwargs):
        import transwarp_df
        from .leopard import leopard_utils
        def create_df_like_table(table_schema):
            if table_type == "timelyre":
                self.create_table(table_name, "timelyre", table_schema, tags=tags, timecol=timecol,
                                  shard_group_duration="5184000")
            elif table_type == "orc":
                self.create_table(table_name, "orc", table_schema)
            elif table_type == "csv":
                self.create_table(table_name, "csv", table_schema)
            elif table_type == "parquet":
                self.create_table(table_name, "parquet", table_schema)
            else:
                raise TypeError(f"unsupported table type: {table_type}")
            return

        def parameter_check():
            if table_type == "timelyre":
                if tags is None or len(tags) == 0:
                    raise ValueError(f"save as timelyre table must specify tag columns, please add 'tags' parameter")
                if timecol is None or len(timecol) == 0:
                    raise ValueError(
                        f"save as timelyre table must specify timestamp columns, please add 'timecol' parameter")
            elif table_type == "orc":
                pass
            elif table_type == "csv":
                pass
            elif table_type == "parquet":
                pass
            else:
                raise TypeError(f"unsupported table type {table_type}, only support timelyre/orc/csv/parquet")

        assert isinstance(df,
                          transwarp_df.pandas.frame.DataFrame), "df is not a transwarp_df.pandas.frame.DataFrame instance"
        parameter_check()
        table_exists = True
        need_drop_old_table = False
        need_created_new_table = False
        schema = []
        try:
            schema = self.show_columns(table_name)
        except Exception as e:  # 开启fast_meta_manager与否，返回的错误类型不一致
            if str(e).count("Table not found") > 0:
                table_exists = False
            else:
                raise e

        if mode == "error" or mode == "errorifexists":
            if table_exists:
                raise ValueError(f"table {table_name} already exists, if you still want to save, "
                                 f"change save mode to 'append' or 'overwrite'")
            else:
                need_created_new_table = True
        elif mode == "append":
            if not table_exists:
                need_created_new_table = True
        elif mode == "overwrite":
            if table_exists:
                need_drop_old_table = True
            need_created_new_table = True
        elif mode == "ignore":
            if not table_exists:
                need_created_new_table = True
            else:
                print(f"table {table_name} already exists and save mode is ignore, so ignore this save operation")
                return
        else:
            raise TypeError(f"unsupported mode {mode}, only support error/append/overwrite/ignore")

        try:
            # 检查表的schema是否和dataframe的match
            if need_created_new_table:
                schema = leopard_utils.get_quark_schema_from_df(df)
            leopard_utils.check_quark_schema_match(df, schema)

            # 通过校验之后才进行表的删除和创建
            if need_drop_old_table:
                self.drop_table(table_name)
            if need_created_new_table:
                create_df_like_table(schema)

            # save数据到表
            if table_type == "timelyre":
                real_name = self.get_shiva_table_name(table_name, **kwargs)
                (df.to_spark().write.mode("append").format("io.transwarp.timelyre")
                 .option("dbtablename", real_name)
                 .option("shivaAddress", self.__shiva_master_addr)
                 .save())
            elif table_type == "orc":
                location = self.getLocation(table_name)
                (df.to_spark().write.mode("append").format("orc")
                 .option("path", location)
                 .save())
            elif table_type == "csv":
                location = self.getLocation(table_name)
                (df.to_spark().write.mode("append").format("csv")
                 .option("path", location)
                 .option("timestampFormat", "yyyy-MM-dd HH:mm:ss")
                 .save())
            elif table_type == "parquet":
                location = self.getLocation(table_name)
                (df.to_spark().write.mode("append").format("parquet")
                 .option("path", location)
                 .save())
        except Exception as e:
            if need_created_new_table:
                self.drop_table(table_name)
            raise e

    def stop_leopard_session(self):
        if self.__leopard_session is not None:
            self.__leopard_session.stop()

    @post_process_result_df
    def direct_query_as_df(self,
                           table_name: str,
                           cols: List[str] = None,
                           tag_value_list: List[str] = None,
                           time_filter: List[str] = None,
                           threads=-1,
                           local_dir: str = None,
                           use_meta_cache: bool = False,
                           **kwargs):
        if self.direct_query_enabled is False:
            raise RuntimeError(f"direct query is not supported, please offer real_ui_host_port when "
                               f"initializing DatabaseConn")
        tableType = self.show_table_type(tblName=table_name, **kwargs)
        if tableType == "timelyre2":
            return self.timelyre2_direct_query_as_df(table_name=table_name, cols=cols, tag_value_list=tag_value_list,
                                                     time_filter=time_filter, threads=threads, local_dir=local_dir,
                                                     use_meta_cache=use_meta_cache, **kwargs)
        tag_cols, _ = self.get_timelyre_tag_time_col(table_name, **kwargs)
        if len(tag_cols) > 1 and tag_value_list is not None:
            # 多tag表暂时只支持提供所有tag列的direct读
            for idx, l in enumerate(tag_value_list):
                if len(l) != len(tag_cols):
                    raise RuntimeError(f"all tag_cols must be provided! current: {l}")
                tag_value_list[idx] = tuple(l)

        request_list = []
        col_mapping_property = self.__get_col_mapping(table_name, use_meta_cache, **kwargs)
        try:
            col_mapping = json.loads(col_mapping_property) if col_mapping_property != '' else {}
        except Exception as e:
            raise RuntimeError(f'failed to decode property, value: {col_mapping_property}, error: {e}')
        df_col_mapping = {}
        for k, v in col_mapping.items():
            if k != v:
                df_col_mapping[v] = k
        # map the new col names to col names in storage
        if cols is not None:
            cols = [col_mapping.get(col, col) for col in cols]
        # 获得真实的shiva table name
        if tag_value_list is None or len(tag_value_list) == 0:
            # 如果tag value list为空， 构造向所有tablet发送的广播请求
            real_name = self.get_shiva_table_name(table_name, use_meta_cache, **kwargs)
            table_distribution = self.__timelyre_client.get_table_distribution(real_name)
            schema = self.__timelyre_client.get_schema_from_shiva(real_name)
            tablets = table_distribution.get_all_tablets()
            for tablet in tablets:
                bucket_info = tablet.get_bucket_info()
                request = (ReadRequestBuilder(bucket_info, tablet)
                           .with_schema(schema)
                           .with_time_filter(time_filter)
                           .with_cols(cols)
                           .build())
                request_list.append(request)
        else:
            # 获得数据分布
            # 每次不能支持tag list太多的场景，因为需要拼接一个url去问shiva web server要到每个tag的位置，而url的长度是有限制的，是8192个byte，url的格式如下，
            # 大概能支持700个tag_value_list, 保守起见设置成500上限, 每个值会变成一个长度为10的string,（未来优化可以优化成post请求，但是也不建议，
            # 太多code也会导致shiva web server性能下降）
            max_tag_batch = 500
            split_tags = [tag_value_list[i:i + max_tag_batch] for i in range(0, len(tag_value_list), max_tag_batch)]
            tags1 = [tag for tags in split_tags for tag in tags]
            assert set(tags1) == set(tag_value_list)
            for tags in split_tags:
                distribution = self.get_tag_distribution(table_name, tags, use_meta_cache)
                request_map = distribution.get_host_read_request_map(timestamp_filter=time_filter, cols=cols)
                # 构造请求列表
                for host, r_list in request_map.items():
                    for r in r_list:
                        request_list.append(r)
        # 多线程取数据
        if threads <= 0:
            threads = os.cpu_count()
        df_array = []
        executor = ThreadPoolExecutor(max_workers=threads)
        for df in executor.map(TimeLyreTransporter.read_dataframe, request_list):
            if len(df_col_mapping) > 0:
                df.rename(columns=df_col_mapping, inplace=True)
            df_array.append(df)
        if local_dir is not None:
            idx = 0
            for df in df_array:
                if df.empty:
                    continue
                fn = f'{local_dir}/{idx}.par'
                df.to_parquet(fn, engine='pyarrow', index=False, use_deprecated_int96_timestamps=True)
                idx += 1
            return None
        else:
            final_df = pd.concat(df_array, ignore_index=True)
            return final_df

    def check_direct_query_enabled(self):
        if self.__fast_meta_mgr is None:
            return False
        try:
            self.__fast_meta_mgr.get_conf("transwarp.docker.inceptor")  # 仅判断请求是否能通。使用的参数无特殊意义
        except Exception:
            return False
        return True

    def get_quark_version(self):
        res = self.run_simple_command("select jar_info()")
        return res[0][3]

    '''返回指定quark表的tag列表和tag值,允许输入时间范围进行过滤
        参数:
        table_name: quark表名
        time_filter: 时间范围，比如['2020-01-01 08:00:00', '2020-01-02 08:00:00']，没有就填None
        
        返回格式: (keys, values)
        比如:    keys: (['key1', 'key2'])
                values: 一个二维数组，每一行组成一个series，
                        (['a1', 'b1'], ['a2', 'b2'], ['a3', 'b3'])
    '''

    @with_database
    def get_tag_value_list(self, table_name: str, time_filter: List[str] = None, **kwargs):
        def generate_sql():
            ts_filter = ""
            if time_filter is not None and len(time_filter) > 0:
                if time_filter[0] is not None and time_filter[0] != "":
                    ts_filter += f"{time_col} >= '{time_filter[0]}'"
                if len(time_filter) > 1 and time_filter[1] is not None and time_filter[1] != "":
                    if ts_filter != "":
                        ts_filter += " and "
                    ts_filter += f"{time_col} <= '{time_filter[1]}'"
            final_sql = f"select distinct {','.join(tag_cols)} from {table_name}"
            if len(ts_filter) > 0:
                final_sql += f" where {ts_filter}"
            final_sql += f" order by {','.join(tag_cols)}"
            return final_sql

        self.internal_set_quark_mode()
        self.run_simple_command("set timelyre.query.squash.optimize=true;")
        tag_cols, time_col = self.get_timelyre_tag_time_col(tblName=table_name, **kwargs)
        sql = generate_sql()
        res = self.__quark_query_raw(sql)
        return tag_cols, res

    def get_timelyre2_password(self):
        try:
            return self.__fast_meta_mgr.get_conf("timelyre2.password")
        except Exception as e:
            return ""

    @with_database
    def timelyre2_direct_query_as_df(self,
                                     table_name: str,
                                     query: Optional[str] = None,
                                     cols: Optional[List[str]] = None,
                                     tag_value_list: Optional[List[str]] = None,
                                     time_filter: Optional[List[str]] = None,
                                     limit: Optional[int] = None,
                                     threads=-1,
                                     local_dir: str = None,
                                     use_meta_cache: bool = False,
                                     **kwargs):
        t1 = time.time_ns()
        request_list = []
        real_name = self.get_shiva_table_name(table_name, use_meta_cache, **kwargs)
        quark_schema = self.get_quark_schema(tblName=table_name, **kwargs)

        tag_cols = quark_schema.get_tag_cols()
        tag_key = ','.join(tag_cols)

        if len(tag_cols) > 1 and tag_value_list is not None:
            # 多tag表暂时只支持提供所有tag列的direct读
            for idx, l in enumerate(tag_value_list):
                if len(l) != len(tag_cols):
                    raise RuntimeError(f"all tag_cols must be provided! current: {l}")
                tag_value_list[idx] = tuple(l)

        password = self.get_timelyre2_password()
        if cols is None or len(cols) == 0:
            cols = quark_schema.get_column_names()
        from transwarp.timelyre.timelyre2 import timelyre2_helper
        if (tag_value_list is None or len(tag_value_list) == 0 or
                timelyre2_helper.task_prune_enabled(self, table_name) is False):
            table_distribution = self.__timelyre_client.get_table_distribution(real_name, is_timelyre2=True)
            tablets = table_distribution.get_all_tablets()
            for tablet in tablets:
                bucket_info = tablet.get_bucket_info()
                from transwarp.timelyre.transport.timelyre2_read_request_builder import TimeLyre2ReadRequestBuilder
                request = (TimeLyre2ReadRequestBuilder(bucket_info, tablet)
                           .with_query(query)
                           .with_tag_key(tag_key)
                           .with_tag_value_list(tag_value_list)
                           .with_ts_col(quark_schema.get_timestamp_col())
                           .with_time_filter(time_filter)
                           .with_cols(cols)
                           .with_limit(limit)
                           .with_fmt(kwargs.get("fmt", "parquet"))
                           .with_compression(kwargs.get("compression", "none"))
                           .with_use_final(kwargs.get("use_final", True))
                           .with_password(password)
                           .build())
                request_list.append(request)
        else:
            max_tag_batch = 500
            split_tags = [tag_value_list[i:i + max_tag_batch] for i in range(0, len(tag_value_list), max_tag_batch)]
            tags1 = [tag for tags in split_tags for tag in tags]
            assert set(tags1) == set(tag_value_list)
            for tags in split_tags:
                distribution = self.get_tag_distribution(table_name, tags, use_meta_cache, is_timelyre2=True)
                request_map = distribution.get_host_read_request_map(password=password,
                                                                     tag_key=tag_key,
                                                                     ts_col=quark_schema.get_timestamp_col(),
                                                                     timestamp_filter=time_filter, cols=cols,
                                                                     limit=limit)
                # 构造请求列表
                for host, r_list in request_map.items():
                    for r in r_list:
                        request_list.append(r)
        # 多线程取数据
        if threads <= 0:
            threads = os.cpu_count()
        df_array = []
        executor = ThreadPoolExecutor(max_workers=threads)
        getLogger().info(f"execute timelyre2_direct_query_as_df, threads: {threads}, requests: {len(request_list)}")
        from transwarp.timelyre.transport.timelyre2_transport import TimeLyre2Transporter
        for df in executor.map(TimeLyre2Transporter.read_dataframe, request_list):
            df_array.append(df)
        if local_dir is not None:
            idx = 0
            for df in df_array:
                if df.empty:
                    continue
                fn = f'{local_dir}/{idx}.par'
                df.to_parquet(fn, engine='pyarrow', index=False, use_deprecated_int96_timestamps=True)
                idx += 1
            return None
        else:
            tt1 = time.time_ns()
            if len(df_array) == 1:
                final_df = df_array[0]
            else:
                final_df = pd.concat(df_array, ignore_index=True)
            tt2 = time.time_ns()
        t2 = time.time_ns()
        getLogger().info(f"finish timelyre2_direct_query_as_df, total_cost {(t2-t1)/1000000} ms, "
                         f"concat_cost {(tt2-tt1)/1000000} ms, df size: {len(final_df)}")
        return final_df

    def __get_col_mapping(self, table_name:str, use_meta_cache:bool, **kwargs):
        props = self.show_properties(table_name, use_meta_cache, **kwargs)
        return props.get('timelyre.columns.mapping', '')

# 单线程进行删除temp_df表和对应hdfs数据的操作，每次需要新开一个session
def clean_tmp_table_internal(conn, tmp_tbl_list):
    if len(tmp_tbl_list) == 0:
        return 0
    count = 0
    for tmp_tbl in tmp_tbl_list:
        desc_data = conn.run_simple_command(f'desc formatted {tmp_tbl}')
        hdfs_loc = None
        for row in desc_data:
            if row[0].startswith('Location:'):
                hdfs_loc = row[1]
        if hdfs_loc is not None:
            try:
                conn.run_simple_command(f"dfs -rm -R {hdfs_loc}")
            except Exception as e:
                # 如果dfs失败，可以跳过
                getLogger().warn(f"dfs rm got exception: {e}")
                pass
        try:
            conn.drop_table(tmp_tbl)
            count += 1
        except Exception as e:
            getLogger().warn(f"drop tmp table got exception: {e}")
    return count
