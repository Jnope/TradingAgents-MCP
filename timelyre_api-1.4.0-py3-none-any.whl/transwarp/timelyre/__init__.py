from transwarp.timelyre.timelyre_public import DatabaseConn
if False:
    from transwarp.timelyre.timelyre_funcs import *
    from transwarp.timelyre.dataframe import RollingColEval, DataFrame, DataType, DatabaseConn
    RollingColEval.method_init()
