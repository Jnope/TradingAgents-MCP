import os

from dfs.DFSClient import DFSClient

def create_dir(c):
    c.rmdir("/lty", recursive=True)
    assert "lty" not in c.list("/")
    c.mkdir("/lty")
    assert "lty" in c.list("/")
    c.rmdir("/lty", recursive=True)
    assert "lty" not in c.list("/")

def put_data(c):
    c.mkdir("/lty")
    with open("./test.data", "wb") as f:
        f.write(b'abcde')
    c.put("/lty/xxx.data", "./test.data")
    assert "xxx.data" in c.list("/lty")
    print(c.list("/lty"))

def get_data_check_same(c):
    os.remove("./test2.data")
    c.get("/lty/xxx.data", "./test2.data")
    data1 = open("./test.data").read()
    data2 = open("./test2.data").read()
    assert data1 == data2

if __name__ == "__main__":
    c = DFSClient(nn_web_addrs="crux-49:50070;crux-50:50070", use_krb=False, non_krb_default_user="hdfs")
    create_dir(c)
    put_data(c)
    get_data_check_same(c)
