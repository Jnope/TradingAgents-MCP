import time

from transwarp.timelyre.timelyre_logger import getLogger


def log_method_time(func):
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        elapsed_time = end_time - start_time
        # 记录方法的执行时间，并且打印日志
        getLogger().info("Method '%s'(%s, %s) executed in %.2f seconds", func.__name__, args[1:], kwargs, elapsed_time)

        return result

    return wrapper


class BaseDBClass(type):
    def __new__(cls, clsname, bases, attrs):
        # 遍历类的所有方法，为每个方法添加装饰器
        for name, val in attrs.items():
            if (callable(val) and not name.startswith('__') and not name.startswith('_')) or (name == "__init__"):
                attrs[name] = log_method_time(val)

        return super().__new__(cls, clsname, bases, attrs)
