import uuid

from transwarp_df.conf import SparkConf
from transwarp_df.context import SparkContext
from transwarp_df.sql.session import SparkSession
import transwarp_df.pandas as ps
from transwarp.timelyre.leopard.leopard_dataframe import LeopardDataframe


class LeopardSession:
    def __init__(self, connector_addr: str, master_addr: str, shiva_addr: str, use_connector_mode: bool,
                 conf_map: dict = None, data_source_version="v2"):
        self.connector_addr = f"sc://{connector_addr}"
        self.shiva_addr = shiva_addr
        self.session_id = f"leopard-api-{uuid.uuid4()}"
        # 配置一些默认参数
        conf_map['compute.ops_on_diff_frames'] = 'True'
        ps.set_option("compute.ops_on_diff_frames", True)
        if use_connector_mode:
            conf = SparkConf().setAppName(f"timelyre_api_connector_{self.session_id}")
            if data_source_version == "v2":
                (conf.set("spark.sql.catalog.timelyre", "io.transwarp.timelyre.v2.TimeLyreTableCatalog")
                 .set("spark.sql.autoBroadcastJoinThreshold", "-1")
                 .set("spark.sql.catalog.timelyre.shivaAddress", shiva_addr))
            if conf_map is not None:
                for key, value in conf_map.items():
                    conf.set(key, value)
            self.spark_session = SparkSession.builder.remote(f"sc://{connector_addr}").config(conf=conf).getOrCreate()
        else:
            conf = SparkConf().setMaster(f"spark://{master_addr}").setAppName(f"timelyre_api_{self.session_id}")
            if conf_map is not None:
                for key, value in conf_map.items():
                    conf.set(key, value)
            sc = SparkContext(conf=conf)
            self.spark_session = SparkSession.builder.getOrCreate()
        for k, v in conf.getAll():
            self.spark_session.local_conf[k] = v

    def load_df(self, table_name: str, schema=None, table_type="timelyre", data_source_version="v2", file_path="",
                tag_list=None, ts_min=None, ts_max=None, prop=None, opts_map=None) -> LeopardDataframe:
        if table_type == "timelyre":
            if data_source_version == "v1":
                df = (self.spark_session.read.format("io.transwarp.timelyre")
                      .option("dbtablename", table_name)
                      .option("shivaAddress", self.shiva_addr)
                      .schema(schema)
                      .load())
            elif data_source_version == "v2":
                reader = self.spark_session.read
                reader = reader.option("tableSchema", schema.json())
                if opts_map is not None and isinstance(opts_map, dict):
                    for k, v in opts_map.items():
                        reader.option(k, v)
                df = (reader.table("timelyre." + table_name))
        elif table_type == "orc":
            df = self.load_file_raw_df(file_path, "orc", schema)
        elif table_type == "parquet":
            df = self.load_file_raw_df(file_path, "parquet", schema)
        elif table_type == "csv":
            df = self.load_file_raw_df(file_path, "csv", schema)
        else:
            raise TypeError(f"unsupported table type: {table_type}")

        # 如果有tag_list
        if tag_list is not None and len(tag_list) > 0:
            if table_type == "timelyre":
                # 如果是timelyre表，那么从table properties中获取tag列和timestamp列名
                tag = prop['timelyre.tag.cols']
            else:
                # 如果不是timelyre表，那么从opts_map中尝试获取
                try:
                    tag = opts_map['tag.cols']
                except Exception:
                    raise ValueError(f"please provide 'tag.cols' in opts_map")
            if tag is not None and tag.count(",") == 0:
                tag_list2 = [f'"{tag}"' for tag in tag_list]
                tag_filter_sql = f'{tag} in ({",".join(tag_list2)})'
                df = df.where(tag_filter_sql)

        if ts_min is not None or ts_max is not None:
            if table_type == "timelyre":
                timecol = prop['timelyre.timestamp.col']
            else:
                try:
                    timecol = opts_map['timestamp.col']
                except Exception:
                    raise ValueError(f"please provide 'timestamp.col' in opts_map")

        # 如果有ts_min
        if ts_min is not None:
            ts_filter_sql = f"{timecol} >= '{ts_min}'"
            df = df.where(ts_filter_sql)

        # 如果有ts_max
        if ts_max is not None:
            ts_filter_sql = f"{timecol} <= '{ts_max}'"
            df = df.where(ts_filter_sql)
        pdf = LeopardDataframe(df.pandas_api())
        return pdf

    def load_file_df(self, file_path: str, file_type: str, schema) -> LeopardDataframe:
        df = self.load_file_raw_df(file_path, file_type, schema)
        return LeopardDataframe(df)

    def load_file_raw_df(self, file_path: str, file_type: str, schema):
        if file_type == "orc":
            f = self.spark_session.read.format("orc")
            if schema is None:
                f.option("inferSchema", "true")
            else:
                f.schema(schema)
            df = f.load(file_path)
        elif file_type == "parquet":
            f = self.spark_session.read.format("parquet")
            if schema is None:
                f.option("inferSchema", "true")
            else:
                f.schema(schema)
            df = f.load(file_path)
        elif file_type == "csv":
            f = self.spark_session.read.format("csv")
            if schema is None:
                f.option("inferSchema", "true")
            else:
                f.schema(schema)
            df = f.load(file_path)
        else:
            raise TypeError(f"do not support file type: {file_type}")
        return df

    def createDataFrame(self, pdf):
        return self.spark_session.createDataFrame(pdf)

    def show_user(self):
        return self.spark_session.sparkContext

    def stop(self):
        self.spark_session.interruptAll()
        self.spark_session.stop()
