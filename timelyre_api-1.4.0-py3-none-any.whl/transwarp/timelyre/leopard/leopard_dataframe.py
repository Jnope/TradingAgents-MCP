from transwarp_df.pandas import DataFrame


class LeopardDataframe(DataFrame):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
