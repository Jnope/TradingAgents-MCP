
def quark_schema_to_leopard_schema(table_type: str, quark_schema, prop):
    from transwarp_df.sql.types import StructType, StructField, BooleanType, TimestampType, DoubleType, \
        LongType, \
        StringType, ShortType, ByteType, IntegerType
    tags = []
    if table_type == "timelyre":
        tags = str.split(prop['timelyre.tag.cols'], ",")
    def quark_type_to_leopard_type(col: list):
        col_name = col[0]
        quark_type = col[1]
        if col_name in tags:
            # 如果是tag列，直接用string类型去读取
            return StructField(col_name, StringType(), False)
        if any(substr in quark_type for substr in ["string", "char", "varchar", "varchar2"]):
            return StructField(col_name, StringType(), True)
        elif quark_type == "tinyint":
            return StructField(col_name, ByteType(), True)
        elif quark_type == "smallint":
            return StructField(col_name, ShortType(), True)
        elif quark_type in "int":
            return StructField(col_name, IntegerType(), True)
        elif quark_type == "bigint":
            return StructField(col_name, LongType(), True)
        elif quark_type == "double":
            return StructField(col_name, DoubleType(), True)
        elif quark_type == "float":
            return StructField(col_name, DoubleType(), True)
        elif quark_type == "timestamp":
            return StructField(col_name, TimestampType(), True)
        elif quark_type in ["boolean", "bool"]:
            return StructField(col_name, BooleanType(), True)
        elif quark_type == "date":
            return StructField(col_name, TimestampType(), True)
        else:
            raise TypeError(f"invalid type: {quark_type}")

    fields = []
    for quark_col in quark_schema:
        spark_col = quark_type_to_leopard_type(quark_col)
        fields.append(spark_col)
    return StructType(fields)


def pandas_type_to_quark_type(dtype_str):
    if dtype_str == 'object':
        return 'string'
    elif dtype_str == 'float64':
        return 'double'
    elif dtype_str == 'datetime64[ns]':
        return 'timestamp'
    elif dtype_str == 'int64':
        return 'bigint'
    elif dtype_str == 'bool':
        return 'boolean'
    elif dtype_str == 'tag':
        return 'string'
    elif dtype_str == 'int32':
        return 'int'
    else:
        raise ValueError(f"unsupported dtype:{dtype_str}")


def get_quark_schema_from_df(df):
    columns = df.columns.values
    dtypes = df.dtypes.values
    schema = []
    for index, col in enumerate(columns):
        dtype_str = str(dtypes[index])
        quark_type = pandas_type_to_quark_type(dtype_str)
        schema.append([col, quark_type])
    return schema


def check_quark_schema_match(df, quark_schema):
    columns = df.columns.values
    dtypes = df.dtypes.values
    quark_names = [a[0] for a in quark_schema]
    quark_types = [a[1] for a in quark_schema]
    if len(columns) != len(quark_names):
        raise ValueError(f"column length mismatch, df: {len(columns)}, table: {len(quark_names)}")
    for index, col in enumerate(columns):
        if col != quark_names[index]:
            raise ValueError(f"column names mismatch, df column name: {col}, table column name: {quark_names[index]}")
        dtype_str = str(dtypes[index])
        typ = pandas_type_to_quark_type(dtype_str)
        if typ != quark_types[index]:
            raise ValueError(
                f"column type mismatch, column name: {col}, df column type: {dtype_str}, table column type: {quark_types[index]}")
