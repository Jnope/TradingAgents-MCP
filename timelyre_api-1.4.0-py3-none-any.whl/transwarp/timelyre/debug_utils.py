from transwarp.timelyre.database import Database


def __local_leopard_func(o):
    return "localhost:15002"

def setup_local_leopard():
    Database._Database__get_leopard_connector_addr = __local_leopard_func
