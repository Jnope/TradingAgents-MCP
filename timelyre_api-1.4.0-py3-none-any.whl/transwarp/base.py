class Processor:

    def __init__(self, config):
        self

    def add_strategy(self, strategy):
        self.strategy = strategy

    def init_strategy(self):
        pass

    def run(self):
        # todo 写运行逻辑
        pass

class Strategy:
    pass


class AccountConfig:
    pass
