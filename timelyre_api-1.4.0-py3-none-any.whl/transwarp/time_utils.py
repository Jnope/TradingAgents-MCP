from datetime import datetime, timedelta

timestamp_formats = ["%Y-%m-%d %H:%M:%S.%f", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%b %d %H:%M:%S %Y", "%m/%d/%y %H:%M:%S"]


def ToTimeLyreHour(n):
    return n - 8


def str_to_datetime(timestamp_str):
    for format in timestamp_formats:
        try:
            datetime_obj = datetime.strptime(timestamp_str, format)
            return datetime_obj
        except ValueError:
            pass
    raise ValueError(f"no format found for datetime: {timestamp_str}")


def str_to_nano(timestamp_str, adjust_time_zone=True):
    dt = str_to_datetime(timestamp_str)
    if adjust_time_zone:
        dt = dt - timedelta(hours=8)
    nanoseconds = (dt - datetime(1970, 1, 1)) // timedelta(microseconds=1) * 1000
    return nanoseconds


def test():
    s1 = "2020-01-01 08:30:00.12345"
    print(str_to_nano(s1))
